﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BASportSAthletics
{
    public class Academic_Baseball
    {
        private string _name;
        private string _class;
        private string _time;
        private string _days;

        public Academic_Baseball() { }
        public Academic_Baseball(string _name, string _class, string _time, string _days)
        {
            this.Name = _name;
            this.Class = _class;
            this.Time = _time;
            this.Days = _days;
        }

        public string Days
        {
            get { return _days; }
            set { _days = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Class
        {
            get { return _class; }
            set { _class = value; }
        }
        public string Time
        {
            get { return _time; }
            set { _time = value; }
        }
    }
}
