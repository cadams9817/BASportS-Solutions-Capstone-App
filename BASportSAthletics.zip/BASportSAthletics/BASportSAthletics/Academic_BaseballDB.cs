﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BASportSAthletics
{
    public class AcademicBaseballDB
    {
            public static Academic_Baseball GetAcademic(string name)
            {
                SqlConnection connection = Connection.GetConnection();
                string selectStatement = "Select Name, Class, Time, Days " +
                            "From Academic_Baseball Where Name = @Name";
                SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
                selectCommand.Parameters.AddWithValue("@Name", name);

                try
                {
                    connection.Open();
                    SqlDataReader academic_baseballReader =
                            selectCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                    if (academic_baseballReader.Read())
                    {
                        Academic_Baseball ac_baseball = new Academic_Baseball();
                        ac_baseball.Name = academic_baseballReader["Name"].ToString();
                        ac_baseball.Days = academic_baseballReader["Days"].ToString();
                        ac_baseball.Class = academic_baseballReader["Class"].ToString();
                        ac_baseball.Time = academic_baseballReader["Time"].ToString();
                        return ac_baseball;
                    }
                    else
                    {
                        return null;
                    }
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }

            }


            public static bool AddAcademic( Academic_Baseball ac_baseball)
            {
                SqlConnection connection = Connection.GetConnection();
                string insertStatement = "Insert Academic_Baseball " +
                    "(Name, Class, Time, Days) " +
                    "Values (@Name, @Class, @Time, @Days)";
                SqlCommand insertCommand = new SqlCommand(insertStatement, connection);
                insertCommand.Parameters.AddWithValue("@Days", ac_baseball.Days);
                insertCommand.Parameters.AddWithValue("@Name", ac_baseball.Name);
                insertCommand.Parameters.AddWithValue("@Class", ac_baseball.Class);
                insertCommand.Parameters.AddWithValue("@Time", ac_baseball.Time);
                try
                {
                    connection.Open();
                    int count = insertCommand.ExecuteNonQuery();
                    if (count > 0)
                        return true;
                    else
                        return false;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }
            }


            public static bool UpdateAcademic(Academic_Baseball old_ac_baseball, Academic_Baseball new_ac_baseball)
            {
                SqlConnection connection = Connection.GetConnection();
                string updateStatement =
                    "UPDATE Academic_Baseball SET " +
                    "Days = @NewDays, " +
                    "Class = @NewClass, " +
                    "Time = @NewTime " +
                    "WHERE Name = @OldName ";
                SqlCommand updateCommand =
                    new SqlCommand(updateStatement, connection);
                updateCommand.Parameters.AddWithValue(
                    "@NewDays", new_ac_baseball.Days);
                updateCommand.Parameters.AddWithValue(
                    "@NewClass", new_ac_baseball.Class);
                updateCommand.Parameters.AddWithValue(
                "@NewTime", new_ac_baseball.Time);
                updateCommand.Parameters.AddWithValue(
                    "@OldName", old_ac_baseball.Name);
                try
                {
                    connection.Open();
                    int count = updateCommand.ExecuteNonQuery();
                    if (count > 0)
                        return true;
                    else
                        return false;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }
            }

            public static bool DeleteOneAcademic(Academic_Baseball ac_baseball)
            {
                SqlConnection connection = Connection.GetConnection();
                string deleteStatement =
                    "DELETE FROM Academic_Baseball " +
                    "WHERE Name = @Name && Class = @Class";
                SqlCommand deleteCommand =
                    new SqlCommand(deleteStatement, connection);
                deleteCommand.Parameters.AddWithValue("@Class", ac_baseball.Class);
                try
                {
                    connection.Open();
                    int count = deleteCommand.ExecuteNonQuery();
                    if (count > 0)
                        return true;
                    else
                        return false;
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }
            }

        public static bool DeleteAllAcademic(Academic_Baseball ac_baseball)
        {
            SqlConnection connection = Connection.GetConnection();
            string deleteStatement =
                "DELETE FROM Academic_Baseball " +
                "WHERE Name = @Name";
            SqlCommand deleteCommand = new SqlCommand(deleteStatement, connection);
            deleteCommand.Parameters.AddWithValue("@Name", ac_baseball.Name);
            try
            {
                connection.Open();
                int count = deleteCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

    }
}
