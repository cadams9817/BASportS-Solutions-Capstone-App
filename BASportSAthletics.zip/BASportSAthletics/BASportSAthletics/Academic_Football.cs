﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BASportSAthletics
{
    public class Academic_Football
    {
        private int _id;
        private string _name;
        private string _class;
        private DateTime _time;

        public Academic_Football() { }

        public Academic_Football(string _name, string _class, DateTime _time)
        {
            this.Id = _id;
            this.Name = _name;
            this.Class = _class;
            this.Time = _time;
        }

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Class
        {
            get { return _class; }
            set { _class = value; }
        }
        public DateTime Time
        {
            get { return _time; }
            set { _time = value; }
        }
    }
}
