﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BASportSAthletics
{
    public class AcademicFootballDB
    {
        public static Academic_Football GetAcademic(string id)
        {
            SqlConnection connection = Connection.GetConnection();
            string selectStatement = "Select Id, Name, Class, Time " +
                        "From Academic_Football Where Id = @Id";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@Id", id);

            try
            {
                connection.Open();
                SqlDataReader academic_footballReader =
                        selectCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                if (academic_footballReader.Read())
                {
                    Academic_Football ac_football = new Academic_Football();
                    ac_football.Id = Convert.ToInt32(academic_footballReader["Id"]);
                    ac_football.Name = academic_footballReader["Name"].ToString();
                    ac_football.Class = academic_footballReader["Class"].ToString();
                    ac_football.Time = Convert.ToDateTime(academic_footballReader["Time"].ToString());
                    return ac_football;
                }
                else
                {
                    return null;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

        }


        public static bool AddAcademic(Academic_Football ac_football)
        {
            SqlConnection connection = Connection.GetConnection();
            string insertStatement = "Insert Academic_Football " +
                "(Id, Name, Class, Time) " +
                "Values (@Id, @Name, @Class, @Time)";
            SqlCommand insertCommand = new SqlCommand(insertStatement, connection);
            insertCommand.Parameters.AddWithValue("@Id", ac_football.Id);
            insertCommand.Parameters.AddWithValue("@Name", ac_football.Name);
            insertCommand.Parameters.AddWithValue("@Class", ac_football.Class);
            insertCommand.Parameters.AddWithValue("@Time", ac_football.Time);
            try
            {
                connection.Open();
                int count = insertCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }


        public static bool UpdateAcademic(Academic_Football old_ac_football, Academic_Football new_ac_football)
        {
            SqlConnection connection = Connection.GetConnection();
            string updateStatement =
                "UPDATE Academic_Football SET " +
                "Name = @NewName, " +
                "Class = @NewClass, " +
                "Time = @NewTime " +
                "WHERE Id = @OldId ";
            SqlCommand updateCommand =
                new SqlCommand(updateStatement, connection);
            updateCommand.Parameters.AddWithValue(
                "@NewName", new_ac_football.Name);
            updateCommand.Parameters.AddWithValue(
                "@NewClass", new_ac_football.Class);
            updateCommand.Parameters.AddWithValue(
            "@NewTime", new_ac_football.Time);
            updateCommand.Parameters.AddWithValue(
                "@OldId", old_ac_football.Id);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool DeleteAcademic(Academic_Football ac_football)
        {
            SqlConnection connection = Connection.GetConnection();
            string deleteStatement =
                "DELETE FROM Academic_Football " +
                "WHERE Id = @Id ";
            SqlCommand deleteCommand =
                new SqlCommand(deleteStatement, connection);
            deleteCommand.Parameters.AddWithValue("@Id", ac_football.Id);
            try
            {
                connection.Open();
                int count = deleteCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

    }
}
