﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BASportSAthletics
{
    public class Academic_Mens_BasketballDB
    {
        public static Academic_Mens_Basketball GetAcademic(string id)
        {
            SqlConnection connection = Connection.GetConnection();
            string selectStatement = "Select Id, Name, Class, Time " +
                        "From Academic_Men's_Basketball Where Id = @Id";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@Id", id);

            try
            {
                connection.Open();
                SqlDataReader academic_mens_basketballReader =
                        selectCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                if (academic_mens_basketballReader.Read())
                {
                    Academic_Mens_Basketball ac_mens_basketball = new Academic_Mens_Basketball();
                    ac_mens_basketball.Id = Convert.ToInt32(academic_mens_basketballReader["Id"]);
                    ac_mens_basketball.Name = academic_mens_basketballReader["Name"].ToString();
                    ac_mens_basketball.Class = academic_mens_basketballReader["Class"].ToString();
                    ac_mens_basketball.Time = Convert.ToDateTime(academic_mens_basketballReader["Time"].ToString());
                    return ac_mens_basketball;
                }
                else
                {
                    return null;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

        }


        public static bool AddAcademic(Academic_Mens_Basketball ac_mens_basketball)
        {
            SqlConnection connection = Connection.GetConnection();
            string insertStatement = "Insert Academic_Men's_Basketball " +
                "(Id, Name, Class, Time) " +
                "Values (@Id, @Name, @Class, @Time)";
            SqlCommand insertCommand = new SqlCommand(insertStatement, connection);
            insertCommand.Parameters.AddWithValue("@Id", ac_mens_basketball.Id);
            insertCommand.Parameters.AddWithValue("@Name", ac_mens_basketball.Name);
            insertCommand.Parameters.AddWithValue("@Class", ac_mens_basketball.Class);
            insertCommand.Parameters.AddWithValue("@Time", ac_mens_basketball.Time);
            try
            {
                connection.Open();
                int count = insertCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }


        public static bool UpdateAcademic(Academic_Mens_Basketball old_ac_mens_basketball, Academic_Mens_Basketball new_ac_mens_basketball)
        {
            SqlConnection connection = Connection.GetConnection();
            string updateStatement =
                "UPDATE Academic_Men's_Basketball SET " +
                "Name = @NewName, " +
                "Class = @NewClass, " +
                "Time = @NewTime " +
                "WHERE Id = @OldId ";
            SqlCommand updateCommand =
                new SqlCommand(updateStatement, connection);
            updateCommand.Parameters.AddWithValue(
                "@NewName", new_ac_mens_basketball.Name);
            updateCommand.Parameters.AddWithValue(
                "@NewClass", new_ac_mens_basketball.Class);
            updateCommand.Parameters.AddWithValue(
            "@NewTime", new_ac_mens_basketball.Time);
            updateCommand.Parameters.AddWithValue(
                "@OldId", old_ac_mens_basketball.Id);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool DeleteAcademic(Academic_Mens_Basketball ac_mens_basketball)
        {
            SqlConnection connection = Connection.GetConnection();
            string deleteStatement =
                "DELETE FROM Academic_Men's_Basketball " +
                "WHERE Id = @Id ";
            SqlCommand deleteCommand =
                new SqlCommand(deleteStatement, connection);
            deleteCommand.Parameters.AddWithValue("@Id", ac_mens_basketball.Id);
            try
            {
                connection.Open();
                int count = deleteCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

    }
}
