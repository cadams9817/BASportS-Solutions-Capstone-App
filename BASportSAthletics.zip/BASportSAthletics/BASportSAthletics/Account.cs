﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BASportSAthletics
{
    public class Account
    {
        private string _username;
        private string _pass;
        private string _sport;
        private bool _admin;

        public Account() { }
        public Account(string _username, string _pass, string _sport, bool _admin)
        {
            this.Username = _username;
            this.Pass = _pass;
            this.Sport = _sport;
            this.Admin = _admin;
        }

        public string Username
        {
            get { return _username; }
            set { _username = value; }
        }

        public string Pass
        {
            get { return _pass; }
            set { _pass = value; }
        }
        public string Sport
        {
            get { return _sport; }
            set { _sport = value; }
        }
        public bool Admin
        {
            get { return _admin; }
            set { _admin = value; }
        }
    }
}
