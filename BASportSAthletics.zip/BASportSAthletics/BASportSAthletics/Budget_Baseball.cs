﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BASportSAthletics
{
    public class Budget_Baseball
    {
        private string _desc;
        private int _cost;
        private string _date;
        private int _totalba;

        public Budget_Baseball() { }
        public Budget_Baseball(string _desc, int _cost, string _date, int _totalba)
        {
            this.Description = _desc;
            this.Cost = _cost;
            this.Date = _date;
            this.TotalBudgetAmount = _totalba;
        }

        public string Description
        {
            get { return _desc; }
            set { _desc = value; }
        }

        public int Cost
        {
            get { return _cost; }
            set { _cost = value; }
        }
        public string Date
        {
            get { return _date; }
            set { _date = value; }
        }
        public int TotalBudgetAmount
        {
            get { return _totalba; }
            set { _totalba = value; }
        }
    }
}
