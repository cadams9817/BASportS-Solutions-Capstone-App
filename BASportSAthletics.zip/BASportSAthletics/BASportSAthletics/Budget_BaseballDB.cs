﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BASportSAthletics
{
    public class BudgetBaseballDB
    {
        public static Budget_Baseball GetBudget(string date)
        {
            SqlConnection connection = Connection.GetConnection();
            string selectStatement = "Select Description, Cost, Date, TotalBudgetAmount " +
                        "From Budget_Baseball Where Date = @Date";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@Date", date);

            try
            {
                connection.Open();
                SqlDataReader budget_baseballReader =
                        selectCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                if (budget_baseballReader.Read())
                {
                    Budget_Baseball b_baseball = new Budget_Baseball();
                    b_baseball.Description = budget_baseballReader["Description"].ToString();
                    b_baseball.Cost = Convert.ToInt32(budget_baseballReader["Cost"]);
                    b_baseball.Date = budget_baseballReader["Date"].ToString();
                    b_baseball.TotalBudgetAmount = Convert.ToInt32(budget_baseballReader["TotalBudgetAmount"]);
                    return b_baseball;
                }
                else
                {
                    return null;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

        }


        public static bool AddBudget(Budget_Baseball b_baseball)
        {
            SqlConnection connection = Connection.GetConnection();
            string insertStatement = "Insert Budget_Baseball " +
                "(Description, Cost, Date, TotalBudgetAmount) " +
                "Values (@Description, @Cost, @Date, @TotalBudgetAmount)";
            SqlCommand insertCommand = new SqlCommand(insertStatement, connection);
            insertCommand.Parameters.AddWithValue("@Description", b_baseball.Description);
            insertCommand.Parameters.AddWithValue("@Cost", b_baseball.Cost);
            insertCommand.Parameters.AddWithValue("@Date", b_baseball.Date);
            insertCommand.Parameters.AddWithValue("@TotalBudgetAmount", b_baseball.TotalBudgetAmount);
            try
            {
                connection.Open();
                int count = insertCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }


        public static bool UpdateBudget(Budget_Baseball old_b_baseball, Budget_Baseball new_b_baseball)
        {
            SqlConnection connection = Connection.GetConnection();
            string updateStatement =
                "UPDATE Budget_Baseball SET " +
                "Description = @NewDescription, " +
                "Cost = @NewCost, " +
                "TotalBudgetAmount = @NewTotalBudgetAmount " +
                "WHERE Date = @OldDate ";
            SqlCommand updateCommand =
                new SqlCommand(updateStatement, connection);
            updateCommand.Parameters.AddWithValue(
                "@NewDescription", new_b_baseball.Description);
            updateCommand.Parameters.AddWithValue(
                "@NewCost", new_b_baseball.Cost);
            updateCommand.Parameters.AddWithValue(
            "@NewTotalBudgetAmount", new_b_baseball.TotalBudgetAmount);
            updateCommand.Parameters.AddWithValue(
                "@OldDate", old_b_baseball.Date);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool DeleteBudget(Budget_Baseball b_baseball)
        {
            SqlConnection connection = Connection.GetConnection();
            string deleteStatement =
                "DELETE FROM Budget_Baseball " +
                "WHERE Date = @Date";
            SqlCommand deleteCommand =
                new SqlCommand(deleteStatement, connection);
            deleteCommand.Parameters.AddWithValue("@Date", b_baseball.Date);
            try
            {
                connection.Open();
                int count = deleteCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

    }
}
