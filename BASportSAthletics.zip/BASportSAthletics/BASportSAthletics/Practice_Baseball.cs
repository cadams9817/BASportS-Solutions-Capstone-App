﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BASportSAthletics
{
    public class Practice_Baseball
    {
        private string _date;
        private string _hrs;
        private string _loc;

        public Practice_Baseball() { }
        public Practice_Baseball(string _date, string _hrs, string _loc)
        {
            this.Date = _date;
            this.Hours = _hrs;
            this.Where = _loc;
        }

        public  string Date
        {
            get { return _date; }
            set { _date = value; }
        }

        public string Hours
        {
            get { return _hrs; }
            set { _hrs = value; }
        }

        public string Where
        {
            get { return _loc; }
            set { _loc = value; }
        }
    }
}
