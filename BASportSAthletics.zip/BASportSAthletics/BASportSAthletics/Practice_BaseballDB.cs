﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BASportSAthletics
{
    class Practice_BaseballDB
    {
        public static Practice_Baseball GetPractice(string date)
        {
            SqlConnection connection = Connection.GetConnection();
            string selectStatement = "Select Date, Hours, Where " +
                        "From Practice_Baseball Where Date = @Date";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@Date", date);

            try
            {
                connection.Open();
                SqlDataReader practice_baseballReader =
                        selectCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                if (practice_baseballReader.Read())
                {
                    Practice_Baseball prac_baseball = new Practice_Baseball();
                    prac_baseball.Date = practice_baseballReader["Date"].ToString();
                    prac_baseball.Hours = practice_baseballReader["Hours"].ToString();
                    prac_baseball.Where = practice_baseballReader["Where"].ToString();
                    return prac_baseball;
                }
                else
                {
                    return null;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

        }


        public static bool AddPractice(Practice_Baseball prac_baseball)
        {
            SqlConnection connection = Connection.GetConnection();
            string insertStatement = "Insert Practice_Baseball " +
                "(Date, Hours, Where) " +
                "Values (@Date, @Hours, @Where)";
            SqlCommand insertCommand = new SqlCommand(insertStatement, connection);
            insertCommand.Parameters.AddWithValue("@Date", prac_baseball.Date);
            insertCommand.Parameters.AddWithValue("@Hours", prac_baseball.Hours);
            insertCommand.Parameters.AddWithValue("@Where", prac_baseball.Where);
            try
            {
                connection.Open();
                int count = insertCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }


        public static bool UpdatePractice(Practice_Baseball old_prac_baseball, Practice_Baseball new_prac_baseball)
        {
            SqlConnection connection = Connection.GetConnection();
            string updateStatement =
                "UPDATE Practice_Baseball SET " +
                "Hours = @NewHours, " +
                "Where = @NewWhere, " +
                "WHERE Date = @OldDate ";
            SqlCommand updateCommand =
                new SqlCommand(updateStatement, connection);
            updateCommand.Parameters.AddWithValue(
                "@NewHours", new_prac_baseball.Hours);
            updateCommand.Parameters.AddWithValue(
                "@NewWhere", new_prac_baseball.Where);
            updateCommand.Parameters.AddWithValue(
                "@OldDate", old_prac_baseball.Date);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool DeletePractice(Practice_Baseball prac_baseball)
        {
            SqlConnection connection = Connection.GetConnection();
            string deleteStatement =
                "DELETE FROM Practice_Baseball " +
                "WHERE Date = @Date";
            SqlCommand deleteCommand = new SqlCommand(deleteStatement, connection);
            deleteCommand.Parameters.AddWithValue("@Date", prac_baseball.Date);
            try
            {
                connection.Open();
                int count = deleteCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
