﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Win32.SafeHandles;
using System.Configuration;
using System.Security;

namespace BASportSAthletics
{
    public partial class frmAcademicInfoBaseball : Form
    {
        SqlConnection con = new SqlConnection("Data Source = (LocalDB)\\MSSQLLocalDB; " +
              "AttachDbFilename=|DataDirectory|\\BASportSDB.mdf;" +
                "Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapt;

        public frmAcademicInfoBaseball()
        {
            InitializeComponent();
            DisplayData();
        }
        

        private void frmAcademicInfoBaseball_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Academic_Baseball' table. You can move, or remove it, as needed.
            this.academic_BaseballTableAdapter.Fill(this.bASportSDBDataSet.Academic_Baseball);
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Player_Information_Baseball' table. You can move, or remove it, as needed.
            this.player_Information_BaseballTableAdapter.Fill(this.bASportSDBDataSet.Player_Information_Baseball);
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Player_Information_Baseball' table. You can move, or remove it, as needed.
            this.player_Information_BaseballTableAdapter.Fill(this.bASportSDBDataSet.Player_Information_Baseball);
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Player_Information_Baseball' table. You can move, or remove it, as needed.
            this.player_Information_BaseballTableAdapter.Fill(this.bASportSDBDataSet.Player_Information_Baseball);

        }

        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("Select Class, Time, Days from Academic_Baseball", con);
            adapt.Fill(dt);
            dgvPlayerInfo.DataSource = dt;
            con.Close();
        }

        private void DisplayName()
        {
            con.Open();
            DataTable da = new DataTable();
            adapt = new SqlDataAdapter("Select Name from Player_Information_Baseball", con);
            adapt.Fill(da);
            cmbPlayerName.DataSource = da;
            con.Close();
        }

        private void cmbPlayerName_SelectedIndexChanged(object sender, EventArgs e)
        {

            //SqlConnection conn = new SqlConnection(connstr);
            //string cmdstr = "Select GPA, Credits FROM Player_Information_Baseball Where Name like '" + cmbPlayerName.Text + "%'");

            //SqlCommand comm = new SqlCommand(cmdstr, conn);
            //conn.Open();
            //comm.Parameters.AddWithValue("GPA", txtGPA.Text);
            //comm.Parameters.AddWithValue("Credits", txtCreditsTaken.Text);
            //comm.ExecuteNonQuery();
            //conn.Close();


            SqlDataAdapter sda = new SqlDataAdapter("SELECT Class, Time, Days FROM Academic_Baseball WHERE Name like '" + cmbPlayerName.Text + "%'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dgvPlayerInfo.DataSource = dt;      
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to Log Out?", "Confirm", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                frmLogin FormLogin = new frmLogin();
                FormLogin.Show();
                this.Close();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            {
                frmTeamPageBaseball FormTeamPageBaseball = new frmTeamPageBaseball();
                FormTeamPageBaseball.Show();
                this.Close();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtGPA.ReadOnly = false;
            }
            else
            {
                txtGPA.ReadOnly = true;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                txtCreditsTaken.ReadOnly = false;
            }
            else
            {
                txtCreditsTaken.ReadOnly = true;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtClass.Text != "" && txtTime.Text != "" && txtDays.Text != "" && cmbPlayerName.Text != "")
            {
                cmd = new SqlCommand("INSERT INTO Academic_Baseball " +
                "(Name, Class, Time, Days) " +
                "VALUES (@Name, @Class, @Time, @Days)", con);
                con.Open();
                cmd.Parameters.AddWithValue("Name", cmbPlayerName.Text);
                cmd.Parameters.AddWithValue("Class", txtClass.Text);
                cmd.Parameters.AddWithValue("Time", txtTime.Text);
                cmd.Parameters.AddWithValue("Days", txtDays.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Class added successfully");
                DisplayData();
                ClearData();
                DisplayName();
            }
            else
            {
                MessageBox.Show("Please fill in all fields");
            }
        }

        private void ClearData()
        {
            dgvPlayerInfo.ClearSelection();

            txtClass.ResetText();
            txtTime.ResetText();
            txtDays.ResetText();
            cmbPlayerName.ResetText();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtClass.Text != "" && txtTime.Text != "" && txtDays.Text != "" && cmbPlayerName.Text != "")
            {
                cmd = new SqlCommand("UPDATE Academic_Baseball SET Class = @Class, Time = @Time, Days = @Days WHERE Name = @Name", con);
                con.Open();
                cmd.Parameters.AddWithValue("Class", txtClass.Text);
                cmd.Parameters.AddWithValue("Time", txtTime.Text);
                cmd.Parameters.AddWithValue("Days", txtDays.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Class updated successfully");
                con.Close();
                DisplayData();
                ClearData();
                DisplayName();
            }
            else
            {
                MessageBox.Show("Please select class to edit.");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtClass.Text != "" && txtTime.Text != "" && txtDays.Text != "" && cmbPlayerName.Text != "")
            {
                DialogResult res = MessageBox.Show("Are you sure you want to delete this class entry?", "Confirm Deletion", MessageBoxButtons.YesNo);
                if (res == DialogResult.Yes)
                {
                    cmd = new SqlCommand("DELETE FROM Academic_Baseball WHERE Name = @Name AND Class = @Class AND Time = @Time AND Days = @Days", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("Name", cmbPlayerName.Text);
                    cmd.Parameters.AddWithValue("Class", txtClass.Text);
                    cmd.Parameters.AddWithValue("Time", txtTime.Text);
                    cmd.Parameters.AddWithValue("Days", txtDays.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Class deleted successfully");
                    DisplayData();
                    ClearData();
                    DisplayName();
                }
                else
                {
                    MessageBox.Show("Please select class to delete");
                }
            }
            else
            {
                MessageBox.Show("Please enter all information for deleting a class.");
            }
                
        }

        private void dgvPlayerInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                //gets a collection that contains all the rows
                DataGridViewRow row = this.dgvPlayerInfo.Rows[e.RowIndex];
                //populate the textbox from specific value of the coordinates of column and row.
                txtClass.Text = row.Cells[0].Value.ToString();
                txtTime.Text = row.Cells[1].Value.ToString();
                txtDays.Text = row.Cells[2].Value.ToString();
            }
        }
    }
}
