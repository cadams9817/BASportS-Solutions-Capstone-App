﻿namespace BASportSAthletics
{
    partial class frmAcademicInfoFootball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAcademicInfoFootball));
            this.dgvPlayerInfo = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.academicFootballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bASportSDBDataSet = new BASportSAthletics.BASportSDBDataSet();
            this.btnSaveCredits = new System.Windows.Forms.Button();
            this.btnSaveGPA = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.txtDays = new System.Windows.Forms.TextBox();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtClass = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lvlClassSchedule = new System.Windows.Forms.Label();
            this.txtCreditsTaken = new System.Windows.Forms.TextBox();
            this.txtGPA = new System.Windows.Forms.TextBox();
            this.lblCreditsTaken = new System.Windows.Forms.Label();
            this.lblGPA = new System.Windows.Forms.Label();
            this.lblPlayerName = new System.Windows.Forms.Label();
            this.cmbPlayerName = new System.Windows.Forms.ComboBox();
            this.playerInformationFootballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lblAcademics = new System.Windows.Forms.Label();
            this.player_Information_FootballTableAdapter = new BASportSAthletics.BASportSDBDataSetTableAdapters.Player_Information_FootballTableAdapter();
            this.academic_FootballTableAdapter = new BASportSAthletics.BASportSDBDataSetTableAdapters.Academic_FootballTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlayerInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.academicFootballBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationFootballBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvPlayerInfo
            // 
            this.dgvPlayerInfo.AutoGenerateColumns = false;
            this.dgvPlayerInfo.BackgroundColor = System.Drawing.Color.White;
            this.dgvPlayerInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPlayerInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.dgvPlayerInfo.DataSource = this.academicFootballBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPlayerInfo.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvPlayerInfo.GridColor = System.Drawing.SystemColors.Control;
            this.dgvPlayerInfo.Location = new System.Drawing.Point(27, 450);
            this.dgvPlayerInfo.Name = "dgvPlayerInfo";
            this.dgvPlayerInfo.RowHeadersWidth = 51;
            this.dgvPlayerInfo.RowTemplate.Height = 24;
            this.dgvPlayerInfo.Size = new System.Drawing.Size(601, 222);
            this.dgvPlayerInfo.TabIndex = 113;
            this.dgvPlayerInfo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPlayerInfo_CellClick);
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Class";
            this.dataGridViewTextBoxColumn2.HeaderText = "Class";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Time";
            this.dataGridViewTextBoxColumn3.HeaderText = "Time";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Days";
            this.dataGridViewTextBoxColumn4.HeaderText = "Days";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // academicFootballBindingSource
            // 
            this.academicFootballBindingSource.DataMember = "Academic_Football";
            this.academicFootballBindingSource.DataSource = this.bASportSDBDataSet;
            // 
            // bASportSDBDataSet
            // 
            this.bASportSDBDataSet.DataSetName = "BASportSDBDataSet";
            this.bASportSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnSaveCredits
            // 
            this.btnSaveCredits.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSaveCredits.BackgroundImage")));
            this.btnSaveCredits.ForeColor = System.Drawing.Color.Black;
            this.btnSaveCredits.Location = new System.Drawing.Point(340, 272);
            this.btnSaveCredits.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveCredits.Name = "btnSaveCredits";
            this.btnSaveCredits.Size = new System.Drawing.Size(91, 25);
            this.btnSaveCredits.TabIndex = 112;
            this.btnSaveCredits.Text = "Save";
            this.btnSaveCredits.UseVisualStyleBackColor = true;
            // 
            // btnSaveGPA
            // 
            this.btnSaveGPA.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSaveGPA.BackgroundImage")));
            this.btnSaveGPA.ForeColor = System.Drawing.Color.Black;
            this.btnSaveGPA.Location = new System.Drawing.Point(340, 202);
            this.btnSaveGPA.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveGPA.Name = "btnSaveGPA";
            this.btnSaveGPA.Size = new System.Drawing.Size(91, 25);
            this.btnSaveGPA.TabIndex = 111;
            this.btnSaveGPA.Text = "Save";
            this.btnSaveGPA.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClear.BackgroundImage")));
            this.btnClear.ForeColor = System.Drawing.Color.Black;
            this.btnClear.Location = new System.Drawing.Point(675, 618);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(152, 58);
            this.btnClear.TabIndex = 110;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDelete.BackgroundImage")));
            this.btnDelete.ForeColor = System.Drawing.Color.Black;
            this.btnDelete.Location = new System.Drawing.Point(885, 618);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(152, 58);
            this.btnDelete.TabIndex = 109;
            this.btnDelete.Text = "Delete Practice";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEdit.BackgroundImage")));
            this.btnEdit.ForeColor = System.Drawing.Color.Black;
            this.btnEdit.Location = new System.Drawing.Point(885, 519);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(152, 58);
            this.btnEdit.TabIndex = 108;
            this.btnEdit.Text = "Edit Practice";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.ForeColor = System.Drawing.Color.Black;
            this.btnAdd.Location = new System.Drawing.Point(675, 519);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(152, 58);
            this.btnAdd.TabIndex = 107;
            this.btnAdd.Text = "Add Practice";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.BackColor = System.Drawing.Color.Transparent;
            this.checkBox2.Location = new System.Drawing.Point(257, 276);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(76, 21);
            this.checkBox2.TabIndex = 106;
            this.checkBox2.Text = "Update";
            this.checkBox2.UseVisualStyleBackColor = false;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.Location = new System.Drawing.Point(257, 206);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(76, 21);
            this.checkBox1.TabIndex = 105;
            this.checkBox1.Text = "Update";
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // txtDays
            // 
            this.txtDays.Location = new System.Drawing.Point(812, 464);
            this.txtDays.Name = "txtDays";
            this.txtDays.Size = new System.Drawing.Size(183, 22);
            this.txtDays.TabIndex = 104;
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(812, 398);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(183, 22);
            this.txtTime.TabIndex = 103;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(669, 261);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(368, 36);
            this.label4.TabIndex = 102;
            this.label4.Text = "Add/Edit Class Schedule";
            // 
            // txtClass
            // 
            this.txtClass.Location = new System.Drawing.Point(812, 333);
            this.txtClass.Name = "txtClass";
            this.txtClass.Size = new System.Drawing.Size(183, 22);
            this.txtClass.TabIndex = 101;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(719, 464);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 20);
            this.label3.TabIndex = 100;
            this.label3.Text = "Days:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(723, 398);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 99;
            this.label2.Text = "Time:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(713, 333);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 20);
            this.label1.TabIndex = 98;
            this.label1.Text = "Class:";
            // 
            // btnBack
            // 
            this.btnBack.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnBack.ForeColor = System.Drawing.Color.Black;
            this.btnBack.Location = new System.Drawing.Point(765, 20);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(118, 37);
            this.btnBack.TabIndex = 97;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnLogout.ForeColor = System.Drawing.Color.Black;
            this.btnLogout.Location = new System.Drawing.Point(919, 20);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(118, 37);
            this.btnLogout.TabIndex = 96;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lvlClassSchedule
            // 
            this.lvlClassSchedule.AutoSize = true;
            this.lvlClassSchedule.BackColor = System.Drawing.Color.Transparent;
            this.lvlClassSchedule.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlClassSchedule.ForeColor = System.Drawing.Color.White;
            this.lvlClassSchedule.Location = new System.Drawing.Point(21, 398);
            this.lvlClassSchedule.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lvlClassSchedule.Name = "lvlClassSchedule";
            this.lvlClassSchedule.Size = new System.Drawing.Size(226, 31);
            this.lvlClassSchedule.TabIndex = 95;
            this.lvlClassSchedule.Text = "Class Schedule:";
            // 
            // txtCreditsTaken
            // 
            this.txtCreditsTaken.Location = new System.Drawing.Point(118, 274);
            this.txtCreditsTaken.Margin = new System.Windows.Forms.Padding(4);
            this.txtCreditsTaken.Name = "txtCreditsTaken";
            this.txtCreditsTaken.ReadOnly = true;
            this.txtCreditsTaken.Size = new System.Drawing.Size(132, 22);
            this.txtCreditsTaken.TabIndex = 94;
            // 
            // txtGPA
            // 
            this.txtGPA.Location = new System.Drawing.Point(118, 204);
            this.txtGPA.Margin = new System.Windows.Forms.Padding(4);
            this.txtGPA.Name = "txtGPA";
            this.txtGPA.ReadOnly = true;
            this.txtGPA.Size = new System.Drawing.Size(132, 22);
            this.txtGPA.TabIndex = 93;
            // 
            // lblCreditsTaken
            // 
            this.lblCreditsTaken.AutoSize = true;
            this.lblCreditsTaken.BackColor = System.Drawing.Color.Transparent;
            this.lblCreditsTaken.ForeColor = System.Drawing.Color.White;
            this.lblCreditsTaken.Location = new System.Drawing.Point(10, 277);
            this.lblCreditsTaken.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCreditsTaken.Name = "lblCreditsTaken";
            this.lblCreditsTaken.Size = new System.Drawing.Size(100, 17);
            this.lblCreditsTaken.TabIndex = 92;
            this.lblCreditsTaken.Text = "Credits Taken:";
            // 
            // lblGPA
            // 
            this.lblGPA.AutoSize = true;
            this.lblGPA.BackColor = System.Drawing.Color.Transparent;
            this.lblGPA.ForeColor = System.Drawing.Color.White;
            this.lblGPA.Location = new System.Drawing.Point(69, 207);
            this.lblGPA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGPA.Name = "lblGPA";
            this.lblGPA.Size = new System.Drawing.Size(41, 17);
            this.lblGPA.TabIndex = 91;
            this.lblGPA.Text = "GPA:";
            // 
            // lblPlayerName
            // 
            this.lblPlayerName.AutoSize = true;
            this.lblPlayerName.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayerName.ForeColor = System.Drawing.Color.White;
            this.lblPlayerName.Location = new System.Drawing.Point(24, 104);
            this.lblPlayerName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPlayerName.Name = "lblPlayerName";
            this.lblPlayerName.Size = new System.Drawing.Size(93, 17);
            this.lblPlayerName.TabIndex = 90;
            this.lblPlayerName.Text = "Player Name:";
            // 
            // cmbPlayerName
            // 
            this.cmbPlayerName.DataSource = this.playerInformationFootballBindingSource;
            this.cmbPlayerName.DisplayMember = "Name";
            this.cmbPlayerName.FormattingEnabled = true;
            this.cmbPlayerName.Location = new System.Drawing.Point(147, 100);
            this.cmbPlayerName.Margin = new System.Windows.Forms.Padding(4);
            this.cmbPlayerName.Name = "cmbPlayerName";
            this.cmbPlayerName.Size = new System.Drawing.Size(268, 24);
            this.cmbPlayerName.TabIndex = 89;
            this.cmbPlayerName.ValueMember = "Name";
            this.cmbPlayerName.SelectedIndexChanged += new System.EventHandler(this.cmbPlayerName_SelectedIndexChanged);
            // 
            // playerInformationFootballBindingSource
            // 
            this.playerInformationFootballBindingSource.DataMember = "Player_Information_Football";
            this.playerInformationFootballBindingSource.DataSource = this.bASportSDBDataSet;
            // 
            // lblAcademics
            // 
            this.lblAcademics.AutoSize = true;
            this.lblAcademics.BackColor = System.Drawing.Color.Transparent;
            this.lblAcademics.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAcademics.ForeColor = System.Drawing.Color.Transparent;
            this.lblAcademics.Location = new System.Drawing.Point(13, 9);
            this.lblAcademics.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAcademics.Name = "lblAcademics";
            this.lblAcademics.Size = new System.Drawing.Size(193, 39);
            this.lblAcademics.TabIndex = 88;
            this.lblAcademics.Text = "Academics";
            // 
            // player_Information_FootballTableAdapter
            // 
            this.player_Information_FootballTableAdapter.ClearBeforeFill = true;
            // 
            // academic_FootballTableAdapter
            // 
            this.academic_FootballTableAdapter.ClearBeforeFill = true;
            // 
            // frmAcademicInfoFootball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.ClientSize = new System.Drawing.Size(1067, 709);
            this.Controls.Add(this.dgvPlayerInfo);
            this.Controls.Add(this.btnSaveCredits);
            this.Controls.Add(this.btnSaveGPA);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.txtDays);
            this.Controls.Add(this.txtTime);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtClass);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lvlClassSchedule);
            this.Controls.Add(this.txtCreditsTaken);
            this.Controls.Add(this.txtGPA);
            this.Controls.Add(this.lblCreditsTaken);
            this.Controls.Add(this.lblGPA);
            this.Controls.Add(this.lblPlayerName);
            this.Controls.Add(this.cmbPlayerName);
            this.Controls.Add(this.lblAcademics);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmAcademicInfoFootball";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAcademicInfoFootball";
            this.Load += new System.EventHandler(this.frmAcademicInfoFootball_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPlayerInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.academicFootballBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationFootballBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn classDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn daysDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dgvPlayerInfo;
        private System.Windows.Forms.Button btnSaveCredits;
        private System.Windows.Forms.Button btnSaveGPA;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txtDays;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtClass;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lvlClassSchedule;
        private System.Windows.Forms.TextBox txtCreditsTaken;
        private System.Windows.Forms.TextBox txtGPA;
        private System.Windows.Forms.Label lblCreditsTaken;
        private System.Windows.Forms.Label lblGPA;
        private System.Windows.Forms.Label lblPlayerName;
        private System.Windows.Forms.ComboBox cmbPlayerName;
        private System.Windows.Forms.Label lblAcademics;
        private BASportSDBDataSet bASportSDBDataSet;
        private System.Windows.Forms.BindingSource playerInformationFootballBindingSource;
        private BASportSDBDataSetTableAdapters.Player_Information_FootballTableAdapter player_Information_FootballTableAdapter;
        private System.Windows.Forms.BindingSource academicFootballBindingSource;
        private BASportSDBDataSetTableAdapters.Academic_FootballTableAdapter academic_FootballTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}