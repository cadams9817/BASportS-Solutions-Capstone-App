﻿namespace BASportSAthletics
{
    partial class frmAcademicInfoWomensGolf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnAddDelete = new System.Windows.Forms.Button();
            this.lvlClassSchedule = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtCreditsTaken = new System.Windows.Forms.TextBox();
            this.txtGPA = new System.Windows.Forms.TextBox();
            this.lblCreditsTaken = new System.Windows.Forms.Label();
            this.lblGPA = new System.Windows.Forms.Label();
            this.lblPlayerName = new System.Windows.Forms.Label();
            this.cmbPlayerName = new System.Windows.Forms.ComboBox();
            this.lblAcademics = new System.Windows.Forms.Label();
            this.academicWomensGolfBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.daysDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.academicWomensGolfBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(184, 602);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(137, 50);
            this.btnUpdate.TabIndex = 37;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(357, 602);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(137, 50);
            this.btnBack.TabIndex = 36;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // btnAddDelete
            // 
            this.btnAddDelete.Location = new System.Drawing.Point(12, 602);
            this.btnAddDelete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddDelete.Name = "btnAddDelete";
            this.btnAddDelete.Size = new System.Drawing.Size(137, 50);
            this.btnAddDelete.TabIndex = 35;
            this.btnAddDelete.Text = "Add or Delete";
            this.btnAddDelete.UseVisualStyleBackColor = true;
            // 
            // lvlClassSchedule
            // 
            this.lvlClassSchedule.AutoSize = true;
            this.lvlClassSchedule.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlClassSchedule.Location = new System.Drawing.Point(5, 306);
            this.lvlClassSchedule.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lvlClassSchedule.Name = "lvlClassSchedule";
            this.lvlClassSchedule.Size = new System.Drawing.Size(226, 31);
            this.lvlClassSchedule.TabIndex = 34;
            this.lvlClassSchedule.Text = "Class Schedule:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.classDataGridViewTextBoxColumn,
            this.timeDataGridViewTextBoxColumn,
            this.daysDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.academicWomensGolfBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 357);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(801, 210);
            this.dataGridView1.TabIndex = 33;
            // 
            // txtCreditsTaken
            // 
            this.txtCreditsTaken.Location = new System.Drawing.Point(117, 229);
            this.txtCreditsTaken.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCreditsTaken.Name = "txtCreditsTaken";
            this.txtCreditsTaken.Size = new System.Drawing.Size(132, 22);
            this.txtCreditsTaken.TabIndex = 32;
            // 
            // txtGPA
            // 
            this.txtGPA.Location = new System.Drawing.Point(117, 182);
            this.txtGPA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtGPA.Name = "txtGPA";
            this.txtGPA.Size = new System.Drawing.Size(132, 22);
            this.txtGPA.TabIndex = 31;
            // 
            // lblCreditsTaken
            // 
            this.lblCreditsTaken.AutoSize = true;
            this.lblCreditsTaken.Location = new System.Drawing.Point(8, 233);
            this.lblCreditsTaken.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCreditsTaken.Name = "lblCreditsTaken";
            this.lblCreditsTaken.Size = new System.Drawing.Size(100, 17);
            this.lblCreditsTaken.TabIndex = 30;
            this.lblCreditsTaken.Text = "Credits Taken:";
            // 
            // lblGPA
            // 
            this.lblGPA.AutoSize = true;
            this.lblGPA.Location = new System.Drawing.Point(67, 186);
            this.lblGPA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGPA.Name = "lblGPA";
            this.lblGPA.Size = new System.Drawing.Size(41, 17);
            this.lblGPA.TabIndex = 29;
            this.lblGPA.Text = "GPA:";
            // 
            // lblPlayerName
            // 
            this.lblPlayerName.AutoSize = true;
            this.lblPlayerName.Location = new System.Drawing.Point(16, 90);
            this.lblPlayerName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPlayerName.Name = "lblPlayerName";
            this.lblPlayerName.Size = new System.Drawing.Size(93, 17);
            this.lblPlayerName.TabIndex = 28;
            this.lblPlayerName.Text = "Player Name:";
            // 
            // cmbPlayerName
            // 
            this.cmbPlayerName.FormattingEnabled = true;
            this.cmbPlayerName.Location = new System.Drawing.Point(117, 86);
            this.cmbPlayerName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbPlayerName.Name = "cmbPlayerName";
            this.cmbPlayerName.Size = new System.Drawing.Size(160, 24);
            this.cmbPlayerName.TabIndex = 27;
            // 
            // lblAcademics
            // 
            this.lblAcademics.AutoSize = true;
            this.lblAcademics.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAcademics.Location = new System.Drawing.Point(16, 11);
            this.lblAcademics.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAcademics.Name = "lblAcademics";
            this.lblAcademics.Size = new System.Drawing.Size(193, 39);
            this.lblAcademics.TabIndex = 26;
            this.lblAcademics.Text = "Academics";
            // 
            // bASportSDBDataSetUpdated
            // 
            // 
            // academicWomensGolfBindingSource
            // 
            this.academicWomensGolfBindingSource.DataMember = "Academic_Women\'s_Golf";
            // 
            // academic_Women_s_GolfTableAdapter
            // 
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 125;
            // 
            // classDataGridViewTextBoxColumn
            // 
            this.classDataGridViewTextBoxColumn.DataPropertyName = "Class";
            this.classDataGridViewTextBoxColumn.HeaderText = "Class";
            this.classDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.classDataGridViewTextBoxColumn.Name = "classDataGridViewTextBoxColumn";
            this.classDataGridViewTextBoxColumn.Width = 125;
            // 
            // timeDataGridViewTextBoxColumn
            // 
            this.timeDataGridViewTextBoxColumn.DataPropertyName = "Time";
            this.timeDataGridViewTextBoxColumn.HeaderText = "Time";
            this.timeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.timeDataGridViewTextBoxColumn.Name = "timeDataGridViewTextBoxColumn";
            this.timeDataGridViewTextBoxColumn.Width = 125;
            // 
            // daysDataGridViewTextBoxColumn
            // 
            this.daysDataGridViewTextBoxColumn.DataPropertyName = "Days";
            this.daysDataGridViewTextBoxColumn.HeaderText = "Days";
            this.daysDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.daysDataGridViewTextBoxColumn.Name = "daysDataGridViewTextBoxColumn";
            this.daysDataGridViewTextBoxColumn.Width = 125;
            // 
            // frmAcademicInfoWomensGolf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 709);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnAddDelete);
            this.Controls.Add(this.lvlClassSchedule);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtCreditsTaken);
            this.Controls.Add(this.txtGPA);
            this.Controls.Add(this.lblCreditsTaken);
            this.Controls.Add(this.lblGPA);
            this.Controls.Add(this.lblPlayerName);
            this.Controls.Add(this.cmbPlayerName);
            this.Controls.Add(this.lblAcademics);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmAcademicInfoWomensGolf";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAcademicInfoWomensGolf";
            this.Load += new System.EventHandler(this.frmAcademicInfoWomensGolf_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.academicWomensGolfBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnAddDelete;
        private System.Windows.Forms.Label lvlClassSchedule;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtCreditsTaken;
        private System.Windows.Forms.TextBox txtGPA;
        private System.Windows.Forms.Label lblCreditsTaken;
        private System.Windows.Forms.Label lblGPA;
        private System.Windows.Forms.Label lblPlayerName;
        private System.Windows.Forms.ComboBox cmbPlayerName;
        private System.Windows.Forms.Label lblAcademics;
        private System.Windows.Forms.BindingSource academicWomensGolfBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn classDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn daysDataGridViewTextBoxColumn;
    }
}