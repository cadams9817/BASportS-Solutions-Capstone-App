﻿namespace BASportSAthletics
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblChooseTeam = new System.Windows.Forms.Label();
            this.btnBaseball = new System.Windows.Forms.Button();
            this.btnMenBasketball = new System.Windows.Forms.Button();
            this.btnWomenBasketball = new System.Windows.Forms.Button();
            this.btnMenCrossCountry = new System.Windows.Forms.Button();
            this.btnWomenCrossCountry = new System.Windows.Forms.Button();
            this.btnMenGolf = new System.Windows.Forms.Button();
            this.btnWomenGolf = new System.Windows.Forms.Button();
            this.btnFootball = new System.Windows.Forms.Button();
            this.btnSoccer = new System.Windows.Forms.Button();
            this.btnSoftball = new System.Windows.Forms.Button();
            this.btnTennis = new System.Windows.Forms.Button();
            this.btnTrack = new System.Windows.Forms.Button();
            this.btnVolleyball = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblChooseTeam
            // 
            this.lblChooseTeam.AutoSize = true;
            this.lblChooseTeam.BackColor = System.Drawing.Color.Transparent;
            this.lblChooseTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChooseTeam.ForeColor = System.Drawing.Color.White;
            this.lblChooseTeam.Location = new System.Drawing.Point(307, 25);
            this.lblChooseTeam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblChooseTeam.Name = "lblChooseTeam";
            this.lblChooseTeam.Size = new System.Drawing.Size(328, 54);
            this.lblChooseTeam.TabIndex = 0;
            this.lblChooseTeam.Text = "Choose Team";
            // 
            // btnBaseball
            // 
            this.btnBaseball.BackColor = System.Drawing.Color.Transparent;
            this.btnBaseball.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBaseball.FlatAppearance.BorderSize = 0;
            this.btnBaseball.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnBaseball.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnBaseball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBaseball.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBaseball.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnBaseball.Location = new System.Drawing.Point(51, 118);
            this.btnBaseball.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBaseball.Name = "btnBaseball";
            this.btnBaseball.Size = new System.Drawing.Size(200, 92);
            this.btnBaseball.TabIndex = 1;
            this.btnBaseball.Text = "Baseball";
            this.btnBaseball.UseVisualStyleBackColor = false;
            this.btnBaseball.Click += new System.EventHandler(this.btnBaseball_Click);
            // 
            // btnMenBasketball
            // 
            this.btnMenBasketball.BackColor = System.Drawing.Color.Transparent;
            this.btnMenBasketball.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenBasketball.FlatAppearance.BorderSize = 0;
            this.btnMenBasketball.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMenBasketball.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMenBasketball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenBasketball.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenBasketball.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnMenBasketball.Location = new System.Drawing.Point(267, 118);
            this.btnMenBasketball.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenBasketball.Name = "btnMenBasketball";
            this.btnMenBasketball.Size = new System.Drawing.Size(200, 92);
            this.btnMenBasketball.TabIndex = 2;
            this.btnMenBasketball.Text = "Men\'s Basketball";
            this.btnMenBasketball.UseVisualStyleBackColor = false;
            this.btnMenBasketball.Click += new System.EventHandler(this.btnMenBasketball_Click);
            // 
            // btnWomenBasketball
            // 
            this.btnWomenBasketball.BackColor = System.Drawing.Color.Transparent;
            this.btnWomenBasketball.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWomenBasketball.FlatAppearance.BorderSize = 0;
            this.btnWomenBasketball.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnWomenBasketball.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnWomenBasketball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWomenBasketball.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWomenBasketball.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnWomenBasketball.Location = new System.Drawing.Point(492, 118);
            this.btnWomenBasketball.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnWomenBasketball.Name = "btnWomenBasketball";
            this.btnWomenBasketball.Size = new System.Drawing.Size(200, 92);
            this.btnWomenBasketball.TabIndex = 3;
            this.btnWomenBasketball.Text = "Women\'s Basketball";
            this.btnWomenBasketball.UseVisualStyleBackColor = false;
            this.btnWomenBasketball.Click += new System.EventHandler(this.btnWomenBasketball_Click);
            // 
            // btnMenCrossCountry
            // 
            this.btnMenCrossCountry.BackColor = System.Drawing.Color.Transparent;
            this.btnMenCrossCountry.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenCrossCountry.FlatAppearance.BorderSize = 0;
            this.btnMenCrossCountry.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMenCrossCountry.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMenCrossCountry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenCrossCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenCrossCountry.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnMenCrossCountry.Location = new System.Drawing.Point(715, 118);
            this.btnMenCrossCountry.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenCrossCountry.Name = "btnMenCrossCountry";
            this.btnMenCrossCountry.Size = new System.Drawing.Size(200, 92);
            this.btnMenCrossCountry.TabIndex = 4;
            this.btnMenCrossCountry.Text = "Men\'s Cross Country";
            this.btnMenCrossCountry.UseVisualStyleBackColor = false;
            this.btnMenCrossCountry.Click += new System.EventHandler(this.btnMenCrossCountry_Click);
            // 
            // btnWomenCrossCountry
            // 
            this.btnWomenCrossCountry.BackColor = System.Drawing.Color.Transparent;
            this.btnWomenCrossCountry.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWomenCrossCountry.FlatAppearance.BorderSize = 0;
            this.btnWomenCrossCountry.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnWomenCrossCountry.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnWomenCrossCountry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWomenCrossCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWomenCrossCountry.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnWomenCrossCountry.Location = new System.Drawing.Point(51, 277);
            this.btnWomenCrossCountry.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnWomenCrossCountry.Name = "btnWomenCrossCountry";
            this.btnWomenCrossCountry.Size = new System.Drawing.Size(200, 92);
            this.btnWomenCrossCountry.TabIndex = 5;
            this.btnWomenCrossCountry.Text = "Women\'s Cross Country";
            this.btnWomenCrossCountry.UseVisualStyleBackColor = false;
            this.btnWomenCrossCountry.Click += new System.EventHandler(this.btnWomenCrossCountry_Click);
            // 
            // btnMenGolf
            // 
            this.btnMenGolf.BackColor = System.Drawing.Color.Transparent;
            this.btnMenGolf.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenGolf.FlatAppearance.BorderSize = 0;
            this.btnMenGolf.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnMenGolf.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnMenGolf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenGolf.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenGolf.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnMenGolf.Location = new System.Drawing.Point(492, 277);
            this.btnMenGolf.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMenGolf.Name = "btnMenGolf";
            this.btnMenGolf.Size = new System.Drawing.Size(200, 92);
            this.btnMenGolf.TabIndex = 6;
            this.btnMenGolf.Text = "Men\'s Golf";
            this.btnMenGolf.UseVisualStyleBackColor = false;
            this.btnMenGolf.Click += new System.EventHandler(this.btnMenGolf_Click);
            // 
            // btnWomenGolf
            // 
            this.btnWomenGolf.BackColor = System.Drawing.Color.Transparent;
            this.btnWomenGolf.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWomenGolf.FlatAppearance.BorderSize = 0;
            this.btnWomenGolf.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnWomenGolf.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnWomenGolf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWomenGolf.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWomenGolf.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnWomenGolf.Location = new System.Drawing.Point(715, 277);
            this.btnWomenGolf.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnWomenGolf.Name = "btnWomenGolf";
            this.btnWomenGolf.Size = new System.Drawing.Size(200, 92);
            this.btnWomenGolf.TabIndex = 7;
            this.btnWomenGolf.Text = "Women\'s Golf";
            this.btnWomenGolf.UseVisualStyleBackColor = false;
            this.btnWomenGolf.Click += new System.EventHandler(this.btnWomenGolf_Click);
            // 
            // btnFootball
            // 
            this.btnFootball.BackColor = System.Drawing.Color.Transparent;
            this.btnFootball.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFootball.FlatAppearance.BorderSize = 0;
            this.btnFootball.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnFootball.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnFootball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFootball.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFootball.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnFootball.Location = new System.Drawing.Point(267, 277);
            this.btnFootball.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFootball.Name = "btnFootball";
            this.btnFootball.Size = new System.Drawing.Size(200, 92);
            this.btnFootball.TabIndex = 8;
            this.btnFootball.Text = "Football";
            this.btnFootball.UseVisualStyleBackColor = false;
            this.btnFootball.Click += new System.EventHandler(this.btnFootball_Click);
            // 
            // btnSoccer
            // 
            this.btnSoccer.BackColor = System.Drawing.Color.Transparent;
            this.btnSoccer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSoccer.FlatAppearance.BorderSize = 0;
            this.btnSoccer.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSoccer.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSoccer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSoccer.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoccer.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSoccer.Location = new System.Drawing.Point(51, 443);
            this.btnSoccer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSoccer.Name = "btnSoccer";
            this.btnSoccer.Size = new System.Drawing.Size(200, 92);
            this.btnSoccer.TabIndex = 9;
            this.btnSoccer.Text = "Soccer";
            this.btnSoccer.UseVisualStyleBackColor = false;
            this.btnSoccer.Click += new System.EventHandler(this.btnSoccer_Click);
            // 
            // btnSoftball
            // 
            this.btnSoftball.BackColor = System.Drawing.Color.Transparent;
            this.btnSoftball.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSoftball.FlatAppearance.BorderSize = 0;
            this.btnSoftball.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSoftball.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSoftball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSoftball.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoftball.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSoftball.Location = new System.Drawing.Point(267, 443);
            this.btnSoftball.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSoftball.Name = "btnSoftball";
            this.btnSoftball.Size = new System.Drawing.Size(200, 92);
            this.btnSoftball.TabIndex = 10;
            this.btnSoftball.Text = "Softball";
            this.btnSoftball.UseVisualStyleBackColor = false;
            this.btnSoftball.Click += new System.EventHandler(this.btnSoftball_Click);
            // 
            // btnTennis
            // 
            this.btnTennis.BackColor = System.Drawing.Color.Transparent;
            this.btnTennis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTennis.FlatAppearance.BorderSize = 0;
            this.btnTennis.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTennis.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTennis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTennis.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTennis.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnTennis.Location = new System.Drawing.Point(492, 443);
            this.btnTennis.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTennis.Name = "btnTennis";
            this.btnTennis.Size = new System.Drawing.Size(200, 92);
            this.btnTennis.TabIndex = 11;
            this.btnTennis.Text = "Tennis";
            this.btnTennis.UseVisualStyleBackColor = false;
            this.btnTennis.Click += new System.EventHandler(this.btnTennis_Click);
            // 
            // btnTrack
            // 
            this.btnTrack.BackColor = System.Drawing.Color.Transparent;
            this.btnTrack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTrack.FlatAppearance.BorderSize = 0;
            this.btnTrack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTrack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTrack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTrack.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrack.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnTrack.Location = new System.Drawing.Point(715, 443);
            this.btnTrack.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTrack.Name = "btnTrack";
            this.btnTrack.Size = new System.Drawing.Size(200, 92);
            this.btnTrack.TabIndex = 12;
            this.btnTrack.Text = "Track and Field";
            this.btnTrack.UseVisualStyleBackColor = false;
            this.btnTrack.Click += new System.EventHandler(this.btnTrack_Click);
            // 
            // btnVolleyball
            // 
            this.btnVolleyball.BackColor = System.Drawing.Color.Transparent;
            this.btnVolleyball.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolleyball.FlatAppearance.BorderSize = 0;
            this.btnVolleyball.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnVolleyball.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnVolleyball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolleyball.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolleyball.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnVolleyball.Location = new System.Drawing.Point(373, 594);
            this.btnVolleyball.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnVolleyball.Name = "btnVolleyball";
            this.btnVolleyball.Size = new System.Drawing.Size(200, 92);
            this.btnVolleyball.TabIndex = 13;
            this.btnVolleyball.Text = "Volleyball";
            this.btnVolleyball.UseVisualStyleBackColor = false;
            this.btnVolleyball.Click += new System.EventHandler(this.btnVolleyball_Click);
            // 
            // frmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::BASportSAthletics.Properties.Resources.purplegoldgradient1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(967, 745);
            this.Controls.Add(this.btnVolleyball);
            this.Controls.Add(this.btnTrack);
            this.Controls.Add(this.btnTennis);
            this.Controls.Add(this.btnSoftball);
            this.Controls.Add(this.btnSoccer);
            this.Controls.Add(this.btnFootball);
            this.Controls.Add(this.btnWomenGolf);
            this.Controls.Add(this.btnMenGolf);
            this.Controls.Add(this.btnWomenCrossCountry);
            this.Controls.Add(this.btnMenCrossCountry);
            this.Controls.Add(this.btnWomenBasketball);
            this.Controls.Add(this.btnMenBasketball);
            this.Controls.Add(this.btnBaseball);
            this.Controls.Add(this.lblChooseTeam);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAdmin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblChooseTeam;
        private System.Windows.Forms.Button btnBaseball;
        private System.Windows.Forms.Button btnMenBasketball;
        private System.Windows.Forms.Button btnWomenBasketball;
        private System.Windows.Forms.Button btnMenCrossCountry;
        private System.Windows.Forms.Button btnWomenCrossCountry;
        private System.Windows.Forms.Button btnMenGolf;
        private System.Windows.Forms.Button btnWomenGolf;
        private System.Windows.Forms.Button btnFootball;
        private System.Windows.Forms.Button btnSoccer;
        private System.Windows.Forms.Button btnSoftball;
        private System.Windows.Forms.Button btnTennis;
        private System.Windows.Forms.Button btnTrack;
        private System.Windows.Forms.Button btnVolleyball;
    }
}