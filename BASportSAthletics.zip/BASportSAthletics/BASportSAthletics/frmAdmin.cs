﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }

        private void btnBaseball_Click(object sender, EventArgs e)
        {
            frmTeamPageBaseball FormTeamPageBaseball = new frmTeamPageBaseball();
            FormTeamPageBaseball.Show();
        }

        private void btnMenBasketball_Click(object sender, EventArgs e)
        {
            frmTeamPageMensBasketball FormTeamPageMensBasketball = new frmTeamPageMensBasketball();
            FormTeamPageMensBasketball.Show();
        }

        private void btnWomenBasketball_Click(object sender, EventArgs e)
        {
            frmTeamPageWomensBasketball FormTeamPageWomensBasketball = new frmTeamPageWomensBasketball();
            FormTeamPageWomensBasketball.Show();
        }

        private void btnMenCrossCountry_Click(object sender, EventArgs e)
        {
            frmTeamPageMensCrossCountry FormTeamPageMensCrossCountry = new frmTeamPageMensCrossCountry();
            FormTeamPageMensCrossCountry.Show();
        }

        private void btnWomenCrossCountry_Click(object sender, EventArgs e)
        {
            frmTeamPageWomensCrossCountry FormTeamPageWomensCrossCountry = new frmTeamPageWomensCrossCountry();
            FormTeamPageWomensCrossCountry.Show();
        }

        private void btnFootball_Click(object sender, EventArgs e)
        {
            frmTeamPage FormTeamPageFootball = new frmTeamPage();
            FormTeamPageFootball.Show();
        }

        private void btnWomenGolf_Click(object sender, EventArgs e)
        {
            frmTeamPageWomensGolf FormTeamPageWomensGolf = new frmTeamPageWomensGolf();
            FormTeamPageWomensGolf.Show();
        }

        private void btnSoccer_Click(object sender, EventArgs e)
        {
            frmTeamPageSoccer FormTeamPageSoccer = new frmTeamPageSoccer();
            FormTeamPageSoccer.Show();
        }

        private void btnSoftball_Click(object sender, EventArgs e)
        {
            frmTeamPageSoftball FormTeamPageSoftball = new frmTeamPageSoftball();
            FormTeamPageSoftball.Show();
        }

        private void btnTennis_Click(object sender, EventArgs e)
        {
            frmTeamPageTennis FormTeamPageTennis = new frmTeamPageTennis();
            FormTeamPageTennis.Show();
        }

        private void btnTrack_Click(object sender, EventArgs e)
        {
            frmTeamPageTrackField FormTeamPageTrackField = new frmTeamPageTrackField();
            FormTeamPageTrackField.Show();
        }

        private void btnVolleyball_Click(object sender, EventArgs e)
        {
            frmTeamPageVolleyball FormTeamPageVolleyball = new frmTeamPageVolleyball();
            FormTeamPageVolleyball.Show();
        }

        private void btnMenGolf_Click(object sender, EventArgs e)
        {
            frmTeamPageMensGolf FormTeamPageMensGolf = new frmTeamPageMensGolf();
            FormTeamPageMensGolf.Show();
        }
    }
}
