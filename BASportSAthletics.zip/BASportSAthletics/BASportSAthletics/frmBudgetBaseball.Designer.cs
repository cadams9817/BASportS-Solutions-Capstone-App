﻿namespace BASportSAthletics
{
    partial class frmBudgetBaseball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBudgetBaseball));
            this.lblBudget = new System.Windows.Forms.Label();
            this.dgvBudget = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.grpBoxScholarship = new System.Windows.Forms.GroupBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.lblTotalBudgetLeft = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtTotalBudget = new System.Windows.Forms.TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.bASportSDBDataSet = new BASportSAthletics.BASportSDBDataSet();
            this.budgetBaseballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.budget_BaseballTableAdapter = new BASportSAthletics.BASportSDBDataSetTableAdapters.Budget_BaseballTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBudget)).BeginInit();
            this.grpBoxScholarship.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.budgetBaseballBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBudget
            // 
            this.lblBudget.AutoSize = true;
            this.lblBudget.BackColor = System.Drawing.Color.Transparent;
            this.lblBudget.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBudget.ForeColor = System.Drawing.Color.White;
            this.lblBudget.Location = new System.Drawing.Point(25, 28);
            this.lblBudget.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBudget.Name = "lblBudget";
            this.lblBudget.Size = new System.Drawing.Size(115, 31);
            this.lblBudget.TabIndex = 0;
            this.lblBudget.Text = "Budget:";
            // 
            // dgvBudget
            // 
            this.dgvBudget.AllowUserToAddRows = false;
            this.dgvBudget.AllowUserToDeleteRows = false;
            this.dgvBudget.BackgroundColor = System.Drawing.Color.White;
            this.dgvBudget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBudget.Location = new System.Drawing.Point(31, 138);
            this.dgvBudget.Margin = new System.Windows.Forms.Padding(4);
            this.dgvBudget.Name = "dgvBudget";
            this.dgvBudget.ReadOnly = true;
            this.dgvBudget.RowHeadersWidth = 51;
            this.dgvBudget.Size = new System.Drawing.Size(500, 500);
            this.dgvBudget.TabIndex = 1;
            this.dgvBudget.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBudget_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(29, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Select Date:";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.budgetBaseballBindingSource;
            this.comboBox1.DisplayMember = "Date";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(132, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.ValueMember = "Date";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // grpBoxScholarship
            // 
            this.grpBoxScholarship.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.grpBoxScholarship.Controls.Add(this.lblDate);
            this.grpBoxScholarship.Controls.Add(this.txtTotalBudget);
            this.grpBoxScholarship.Controls.Add(this.txtDescription);
            this.grpBoxScholarship.Controls.Add(this.txtDate);
            this.grpBoxScholarship.Controls.Add(this.txtCost);
            this.grpBoxScholarship.Controls.Add(this.lblTotalBudgetLeft);
            this.grpBoxScholarship.Controls.Add(this.lblYear);
            this.grpBoxScholarship.Controls.Add(this.lblName);
            this.grpBoxScholarship.Location = new System.Drawing.Point(542, 134);
            this.grpBoxScholarship.Margin = new System.Windows.Forms.Padding(2);
            this.grpBoxScholarship.Name = "grpBoxScholarship";
            this.grpBoxScholarship.Padding = new System.Windows.Forms.Padding(2);
            this.grpBoxScholarship.Size = new System.Drawing.Size(399, 504);
            this.grpBoxScholarship.TabIndex = 19;
            this.grpBoxScholarship.TabStop = false;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(165, 104);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(217, 22);
            this.txtDescription.TabIndex = 12;
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(165, 230);
            this.txtDate.Margin = new System.Windows.Forms.Padding(4);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(217, 22);
            this.txtDate.TabIndex = 11;
            // 
            // txtCost
            // 
            this.txtCost.Location = new System.Drawing.Point(165, 164);
            this.txtCost.Margin = new System.Windows.Forms.Padding(4);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(217, 22);
            this.txtCost.TabIndex = 10;
            // 
            // lblTotalBudgetLeft
            // 
            this.lblTotalBudgetLeft.AutoSize = true;
            this.lblTotalBudgetLeft.BackColor = System.Drawing.Color.Transparent;
            this.lblTotalBudgetLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalBudgetLeft.ForeColor = System.Drawing.Color.White;
            this.lblTotalBudgetLeft.Location = new System.Drawing.Point(36, 295);
            this.lblTotalBudgetLeft.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalBudgetLeft.Name = "lblTotalBudgetLeft";
            this.lblTotalBudgetLeft.Size = new System.Drawing.Size(121, 17);
            this.lblTotalBudgetLeft.TabIndex = 9;
            this.lblTotalBudgetLeft.Text = "Total Budget Left:";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.BackColor = System.Drawing.Color.Transparent;
            this.lblYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYear.ForeColor = System.Drawing.Color.White;
            this.lblYear.Location = new System.Drawing.Point(119, 167);
            this.lblYear.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(40, 17);
            this.lblYear.TabIndex = 8;
            this.lblYear.Text = "Cost:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.White;
            this.lblName.Location = new System.Drawing.Point(76, 107);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 17);
            this.lblName.TabIndex = 7;
            this.lblName.Text = "Description:";
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnReturn.Location = new System.Drawing.Point(627, 13);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(152, 38);
            this.btnReturn.TabIndex = 25;
            this.btnReturn.Text = "Back";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Transparent;
            this.btnLogout.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnLogout.Location = new System.Drawing.Point(787, 13);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(152, 38);
            this.btnLogout.TabIndex = 26;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEdit.BackgroundImage")));
            this.btnEdit.Location = new System.Drawing.Point(625, 644);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(100, 47);
            this.btnEdit.TabIndex = 27;
            this.btnEdit.Text = "Edit Entry";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.Location = new System.Drawing.Point(517, 644);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 46);
            this.btnAdd.TabIndex = 28;
            this.btnAdd.Text = "Add Entry";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClear.BackgroundImage")));
            this.btnClear.Location = new System.Drawing.Point(733, 644);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 47);
            this.btnClear.TabIndex = 29;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDelete.BackgroundImage")));
            this.btnDelete.Location = new System.Drawing.Point(841, 644);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 47);
            this.btnDelete.TabIndex = 30;
            this.btnDelete.Text = "Delete Entry";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtTotalBudget
            // 
            this.txtTotalBudget.Location = new System.Drawing.Point(165, 292);
            this.txtTotalBudget.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalBudget.Name = "txtTotalBudget";
            this.txtTotalBudget.Size = new System.Drawing.Size(217, 22);
            this.txtTotalBudget.TabIndex = 13;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.Color.White;
            this.lblDate.Location = new System.Drawing.Point(115, 233);
            this.lblDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(42, 17);
            this.lblDate.TabIndex = 14;
            this.lblDate.Text = "Date:";
            // 
            // bASportSDBDataSet
            // 
            this.bASportSDBDataSet.DataSetName = "BASportSDBDataSet";
            this.bASportSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // budgetBaseballBindingSource
            // 
            this.budgetBaseballBindingSource.DataMember = "Budget_Baseball";
            this.budgetBaseballBindingSource.DataSource = this.bASportSDBDataSet;
            // 
            // budget_BaseballTableAdapter
            // 
            this.budget_BaseballTableAdapter.ClearBeforeFill = true;
            // 
            // frmBudgetBaseball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.ClientSize = new System.Drawing.Size(965, 709);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.grpBoxScholarship);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvBudget);
            this.Controls.Add(this.lblBudget);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmBudgetBaseball";
            this.Text = "frmBudgetBaseball";
            this.Load += new System.EventHandler(this.frmBudgetBaseball_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBudget)).EndInit();
            this.grpBoxScholarship.ResumeLayout(false);
            this.grpBoxScholarship.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.budgetBaseballBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBudget;
        private System.Windows.Forms.DataGridView dgvBudget;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalBudgetAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox grpBoxScholarship;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.Label lblTotalBudgetLeft;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtTotalBudget;
        private System.Windows.Forms.Label lblDate;
        private BASportSDBDataSet bASportSDBDataSet;
        private System.Windows.Forms.BindingSource budgetBaseballBindingSource;
        private BASportSDBDataSetTableAdapters.Budget_BaseballTableAdapter budget_BaseballTableAdapter;
    }
}