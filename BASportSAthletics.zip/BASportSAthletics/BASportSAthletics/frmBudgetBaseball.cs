﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Security;

namespace BASportSAthletics
{
    public partial class frmBudgetBaseball : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;" +
                "AttachDbFilename=|DataDirectory|\\BASportSDB.mdf;" +
                  "Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapt;

        public frmBudgetBaseball()
        {
            InitializeComponent();
            DisplayData();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtDescription.Text != "" && txtCost.Text != "" && txtDate.Text != "" && txtTotalBudget.Text != "")
            {
                cmd = new SqlCommand("INSERT INTO Budget_Baseball " +
                "(Description, Cost, Date, TotalBudgetAmount) " +
                "VALUES (@Description, @Cost, @Date, @TotalBudgetAmount)", con);
                con.Open();
                cmd.Parameters.AddWithValue("Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("Cost", txtCost.Text);
                cmd.Parameters.AddWithValue("Date", txtDate.Text);
                cmd.Parameters.AddWithValue("TotalBudgetAmount", txtTotalBudget.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Entry added successfully");
                DisplayData();
                ClearData();
                DisplayDate();
            }
            else
            {
                MessageBox.Show("Please fill in all fields");
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            {
                frmTeamInfoBaseball FormTeamInfoBaseball = new frmTeamInfoBaseball();
                FormTeamInfoBaseball.Show();
                this.Hide();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to Log Out?", "Confirm", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                frmLogin FormLogin = new frmLogin();
                FormLogin.Show();
                this.Close();
            }
        }

        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("Select * from Budget_Baseball", con);
            adapt.Fill(dt);
            dgvBudget.DataSource = dt;
            con.Close();
        }

        private void DisplayDate()
        {
            con.Open();
            DataTable da = new DataTable();
            adapt = new SqlDataAdapter("Select Date from Budget_Baseball", con);
            adapt.Fill(da);
            comboBox1.DataSource = da;
            con.Close();
        }

        private void ClearData()
        {
            dgvBudget.ClearSelection();

            txtDescription.ResetText();
            txtCost.ResetText();
            txtDate.ResetText();
            txtTotalBudget.ResetText();
        }

        private void frmBudgetBaseball_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Budget_Baseball' table. You can move, or remove it, as needed.
            this.budget_BaseballTableAdapter.Fill(this.bASportSDBDataSet.Budget_Baseball);

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtDescription.Text != "" && txtCost.Text != "" && txtDate.Text != "" && txtTotalBudget.Text != "")
            {
                cmd = new SqlCommand("UPDATE Budget_Baseball SET Description = @Description, Cost = @Cost, Date = @Date, " +
                "TotalBudgetAmount = @TotalBudgetAmount WHERE Description = @Description", con);
                con.Open();
                cmd.Parameters.AddWithValue("Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("Cost", txtCost.Text);
                cmd.Parameters.AddWithValue("Date", txtDate.Text);
                cmd.Parameters.AddWithValue("TotalBudgetAmount", txtTotalBudget.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Entry updated successfully");
                con.Close();
                DisplayData();
                ClearData();
                DisplayDate();
            }
            else
            {
                MessageBox.Show("Please select entry to edit.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure you want to delete " + txtDescription.Text.ToString(), "Confirm Deletion", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                cmd = new SqlCommand("DELETE FROM Budget_Baseball WHERE Description = @Description AND Cost = @Cost AND Date = @Date AND TotalBudgetAmount = @TotalBudgetAmount", con);
                con.Open();
                cmd.Parameters.AddWithValue("Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("Cost", txtCost.Text);
                cmd.Parameters.AddWithValue("Date", txtDate.Text);
                cmd.Parameters.AddWithValue("TotalBudgetAmount", txtTotalBudget.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Entry deleted successfully");
                DisplayData();
                ClearData();
                DisplayDate();
            }
            else
            {
                MessageBox.Show("Please select entry to delete");
            }
        }

        private void dgvBudget_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                //gets a collection that contains all the rows
                DataGridViewRow row = this.dgvBudget.Rows[e.RowIndex];
                //populate the textbox from specific value of the coordinates of column and row.
                txtDescription.Text = row.Cells[0].Value.ToString();
                txtCost.Text = row.Cells[1].Value.ToString();
                txtDate.Text = row.Cells[2].Value.ToString();
                txtTotalBudget.Text = row.Cells[3].Value.ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT Description, Cost, Date, TotalBudgetAmount FROM Budget_Baseball WHERE Date like '" + comboBox1.Text + "%'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvBudget.DataSource = dt;
        }
    }
}
