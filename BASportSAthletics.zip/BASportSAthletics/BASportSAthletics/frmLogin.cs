﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Security;

namespace BASportSAthletics
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string connstr = "Data Source=(LocalDB)\\MSSQLLocalDB;" +
                "AttachDbFilename=|DataDirectory|\\BASportSDB.mdf;" +
                "Integrated Security=True";
            SqlConnection conn = new SqlConnection(connstr);

            string userUsername = txtUsername.Text;
            string userPassword = txtPassword.Text;
            string userTeam = cmbTeam.Text;

            string cmdstr = "Select * From Account Where Username = @Username AND Password = @Password AND Team = @Team";
            SqlCommand comm = new SqlCommand(cmdstr, conn);
            comm.Parameters.AddWithValue("Username", userUsername);
            comm.Parameters.AddWithValue("Password", userPassword);
            comm.Parameters.AddWithValue("Team", userTeam);

            conn.Open();

            SqlDataReader reader = comm.ExecuteReader();
            if (reader.Read())
            {
                userUsername = txtUsername.Text;

                if (cmbTeam.SelectedItem.ToString() == "Baseball")
                {
                    frmTeamPageBaseball FormBaseball = new frmTeamPageBaseball();
                    FormBaseball.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Football")
                {
                    frmTeamPage FormFootball = new frmTeamPage();
                    FormFootball.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Men's Basketball")
                {
                    frmTeamPageMensBasketball FormMensBasketball = new frmTeamPageMensBasketball();
                    FormMensBasketball.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Men's Cross Country")
                {
                    frmTeamPageMensCrossCountry FormMensCrossCountry = new frmTeamPageMensCrossCountry();
                    FormMensCrossCountry.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Men's Golf")
                {
                    frmTeamPageMensGolf FormMensGolf = new frmTeamPageMensGolf();
                    FormMensGolf.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Soccer")
                {
                    frmTeamPageSoccer FormSoccer = new frmTeamPageSoccer();
                    FormSoccer.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Softball")
                {
                    frmTeamPageSoftball FormSoftball = new frmTeamPageSoftball();
                    FormSoftball.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Tennis")
                {
                    frmTeamPageTennis FormTennis = new frmTeamPageTennis();
                    FormTennis.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Track and Field")
                {
                    frmTeamPageTrackField FormTrackField = new frmTeamPageTrackField();
                    FormTrackField.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Volleyball")
                {
                    frmTeamPageVolleyball FormVolleyball = new frmTeamPageVolleyball();
                    FormVolleyball.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Women's Basketball")
                {
                    frmTeamPageWomensBasketball FormWomensBasketball = new frmTeamPageWomensBasketball();
                    FormWomensBasketball.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Women's Cross Country")
                {
                    frmTeamPageWomensCrossCountry FormWomensCrossCountry = new frmTeamPageWomensCrossCountry();
                    FormWomensCrossCountry.Show();
                    this.Hide();
                }
                else if (cmbTeam.SelectedItem.ToString() == "Women's Golf")
                {
                    frmTeamPageWomensGolf FormWomensGolf = new frmTeamPageWomensGolf();
                    FormWomensGolf.Show();
                    this.Hide();
                }
                else
                {
                    frmAdmin FormAdmin = new frmAdmin();
                    FormAdmin.Show();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Problem finding User, or User not allowed to view page.");
            }
            reader.Close();
            conn.Close();

        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            frmNewUser FormNewUser = new frmNewUser();
            FormNewUser.Show();
            this.Hide();
        }
    }
}
