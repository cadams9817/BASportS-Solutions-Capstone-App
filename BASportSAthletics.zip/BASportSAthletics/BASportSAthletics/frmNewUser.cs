﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Security;

namespace BASportSAthletics
{
    public partial class frmNewUser : Form
    {
        public frmNewUser()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            string userUsername = txtUsername.Text;
            string userPassword = txtPassword.Text;
            string userConPassword = txtConfirmPassword.Text;
            string userTeam = cmbTeam.SelectedItem.ToString();
            string adminUsername = txtAdminUser.Text;
            string adminPassword = txtAdminPass.Text;
            string adminTeam = cmbAdminTeam.Text;

            string connStr = "Data Source=(LocalDB)\\MSSQLLocalDB;" +
                "AttachDbFilename=|DataDirectory|\\BASportSDB.mdf;" +
                "Integrated Security=True";
            SqlConnection conn = new SqlConnection(connStr);

            string insertStatement = "INSERT INTO Account (Username, Password, Team)"
                                   + "VALUES (@Username, @Password, @Team)";
            SqlCommand insertCommand = new SqlCommand(insertStatement, conn);

            insertCommand.Parameters.AddWithValue("@Username", userUsername);
            insertCommand.Parameters.AddWithValue("@Password", userPassword);
            insertCommand.Parameters.AddWithValue("@Team", userTeam);

            string searchStatement = "SELECT * FROM Account WHERE Username = @Username AND Password = @Password AND Team = @Team";
            SqlCommand searchCommand = new SqlCommand(searchStatement, conn);
            searchCommand.Parameters.AddWithValue("@Username", adminUsername);
            searchCommand.Parameters.AddWithValue("@Password", adminPassword);
            searchCommand.Parameters.AddWithValue("@Team", adminTeam);

            if (txtConfirmPassword.Text == txtPassword.Text)
            {
                conn.Open();
                SqlDataReader reader = searchCommand.ExecuteReader();
                
                if (reader.Read())
                {
                    adminTeam = cmbAdminTeam.Text;
                    
                    conn.Close();

                        try
                        {
                            conn.Open();
                            int custUpdate = insertCommand.ExecuteNonQuery();
                        }
                        catch (SqlException ex)
                        {
                            MessageBox.Show("Error creating new user." + ex);
                        }
                        finally
                        {
                            conn.Close();
                            txtUsername.Text = "";
                            txtPassword.Text = "";
                            txtConfirmPassword.Text = "";
                            cmbTeam.Text = "";
                        }
                }
                else
                {
                    MessageBox.Show("Incorrect Admin Credentials");
                }
                reader.Close();
                conn.Close();
               
            }
            else
            {
                MessageBox.Show("New user password does not match");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmLogin FormLogin = new frmLogin();
            FormLogin.Show();
            this.Close();
        }
    }
}
