﻿namespace BASportSAthletics
{
    partial class frmPlayerInfoBaseball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPlayerInfoBaseball));
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.schoolAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.graduationYearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eligibleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.heightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shirtSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shortsSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hatSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shoeSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emergencyContactNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emergencyContactNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerInformationBaseballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bASportSDBDataSet = new BASportSAthletics.BASportSDBDataSet();
            this.lblPlayers = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.grpPlayerInformation = new System.Windows.Forms.GroupBox();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.lblNumber = new System.Windows.Forms.Label();
            this.cmbEligible = new System.Windows.Forms.ComboBox();
            this.txtEmergencyContactNumber = new System.Windows.Forms.TextBox();
            this.txtEmergencyContactName = new System.Windows.Forms.TextBox();
            this.txtSchoolAddress = new System.Windows.Forms.TextBox();
            this.lblEligible = new System.Windows.Forms.Label();
            this.lblSchoolAddress = new System.Windows.Forms.Label();
            this.lblEmergencyContactName = new System.Windows.Forms.Label();
            this.lblEmergencyContactNumber = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtHatSize = new System.Windows.Forms.TextBox();
            this.cmbShoeSize = new System.Windows.Forms.ComboBox();
            this.cmbShortsSize = new System.Windows.Forms.ComboBox();
            this.cmbShirtSize = new System.Windows.Forms.ComboBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtTNumber = new System.Windows.Forms.TextBox();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.txtGraduationYear = new System.Windows.Forms.TextBox();
            this.lblShoeSize = new System.Windows.Forms.Label();
            this.lblTNumber = new System.Windows.Forms.Label();
            this.lblShirtSize = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblShortsSize = new System.Windows.Forms.Label();
            this.lblHatSize = new System.Windows.Forms.Label();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.lblHomeAddress = new System.Windows.Forms.Label();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.player_Information_BaseballTableAdapter = new BASportSAthletics.BASportSDBDataSetTableAdapters.Player_Information_BaseballTableAdapter();
            this.btnLogout = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationBaseballBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.grpPlayerInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDelete.BackgroundImage")));
            this.btnDelete.Location = new System.Drawing.Point(1248, 602);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(152, 58);
            this.btnDelete.TabIndex = 15;
            this.btnDelete.Text = "Delete Player";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEdit.BackgroundImage")));
            this.btnEdit.Location = new System.Drawing.Point(928, 602);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(152, 58);
            this.btnEdit.TabIndex = 14;
            this.btnEdit.Text = "Edit Player";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.Location = new System.Drawing.Point(768, 602);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(152, 58);
            this.btnAdd.TabIndex = 13;
            this.btnAdd.Text = "Add Player";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.schoolAddressDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.tNumberDataGridViewTextBoxColumn,
            this.graduationYearDataGridViewTextBoxColumn,
            this.eligibleDataGridViewTextBoxColumn,
            this.numberDataGridViewTextBoxColumn,
            this.heightDataGridViewTextBoxColumn,
            this.weightDataGridViewTextBoxColumn,
            this.positionDataGridViewTextBoxColumn,
            this.shirtSizeDataGridViewTextBoxColumn,
            this.shortsSizeDataGridViewTextBoxColumn,
            this.hatSizeDataGridViewTextBoxColumn,
            this.shoeSizeDataGridViewTextBoxColumn,
            this.emergencyContactNameDataGridViewTextBoxColumn,
            this.emergencyContactNumberDataGridViewTextBoxColumn});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView1.DataSource = this.playerInformationBaseballBindingSource;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(11, 57);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(667, 586);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 74;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.ReadOnly = true;
            this.addressDataGridViewTextBoxColumn.Width = 89;
            // 
            // schoolAddressDataGridViewTextBoxColumn
            // 
            this.schoolAddressDataGridViewTextBoxColumn.DataPropertyName = "SchoolAddress";
            this.schoolAddressDataGridViewTextBoxColumn.HeaderText = "School Address";
            this.schoolAddressDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.schoolAddressDataGridViewTextBoxColumn.Name = "schoolAddressDataGridViewTextBoxColumn";
            this.schoolAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.schoolAddressDataGridViewTextBoxColumn.Width = 125;
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            this.phoneDataGridViewTextBoxColumn.DataPropertyName = "Phone";
            this.phoneDataGridViewTextBoxColumn.HeaderText = "Phone";
            this.phoneDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            this.phoneDataGridViewTextBoxColumn.ReadOnly = true;
            this.phoneDataGridViewTextBoxColumn.Width = 78;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.ReadOnly = true;
            this.emailDataGridViewTextBoxColumn.Width = 71;
            // 
            // tNumberDataGridViewTextBoxColumn
            // 
            this.tNumberDataGridViewTextBoxColumn.DataPropertyName = "TNumber";
            this.tNumberDataGridViewTextBoxColumn.HeaderText = "T Number";
            this.tNumberDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.tNumberDataGridViewTextBoxColumn.Name = "tNumberDataGridViewTextBoxColumn";
            this.tNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.tNumberDataGridViewTextBoxColumn.Width = 92;
            // 
            // graduationYearDataGridViewTextBoxColumn
            // 
            this.graduationYearDataGridViewTextBoxColumn.DataPropertyName = "GraduationYear";
            this.graduationYearDataGridViewTextBoxColumn.HeaderText = "Graduation Year";
            this.graduationYearDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.graduationYearDataGridViewTextBoxColumn.Name = "graduationYearDataGridViewTextBoxColumn";
            this.graduationYearDataGridViewTextBoxColumn.ReadOnly = true;
            this.graduationYearDataGridViewTextBoxColumn.Width = 130;
            // 
            // eligibleDataGridViewTextBoxColumn
            // 
            this.eligibleDataGridViewTextBoxColumn.DataPropertyName = "Eligible";
            this.eligibleDataGridViewTextBoxColumn.HeaderText = "Eligible";
            this.eligibleDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.eligibleDataGridViewTextBoxColumn.Name = "eligibleDataGridViewTextBoxColumn";
            this.eligibleDataGridViewTextBoxColumn.ReadOnly = true;
            this.eligibleDataGridViewTextBoxColumn.Width = 82;
            // 
            // numberDataGridViewTextBoxColumn
            // 
            this.numberDataGridViewTextBoxColumn.DataPropertyName = "Number";
            this.numberDataGridViewTextBoxColumn.HeaderText = "Number";
            this.numberDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.numberDataGridViewTextBoxColumn.Name = "numberDataGridViewTextBoxColumn";
            this.numberDataGridViewTextBoxColumn.ReadOnly = true;
            this.numberDataGridViewTextBoxColumn.Width = 87;
            // 
            // heightDataGridViewTextBoxColumn
            // 
            this.heightDataGridViewTextBoxColumn.DataPropertyName = "Height";
            this.heightDataGridViewTextBoxColumn.HeaderText = "Height";
            this.heightDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.heightDataGridViewTextBoxColumn.Name = "heightDataGridViewTextBoxColumn";
            this.heightDataGridViewTextBoxColumn.ReadOnly = true;
            this.heightDataGridViewTextBoxColumn.Width = 78;
            // 
            // weightDataGridViewTextBoxColumn
            // 
            this.weightDataGridViewTextBoxColumn.DataPropertyName = "Weight";
            this.weightDataGridViewTextBoxColumn.HeaderText = "Weight";
            this.weightDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.weightDataGridViewTextBoxColumn.Name = "weightDataGridViewTextBoxColumn";
            this.weightDataGridViewTextBoxColumn.ReadOnly = true;
            this.weightDataGridViewTextBoxColumn.Width = 81;
            // 
            // positionDataGridViewTextBoxColumn
            // 
            this.positionDataGridViewTextBoxColumn.DataPropertyName = "Position";
            this.positionDataGridViewTextBoxColumn.HeaderText = "Position";
            this.positionDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.positionDataGridViewTextBoxColumn.Name = "positionDataGridViewTextBoxColumn";
            this.positionDataGridViewTextBoxColumn.ReadOnly = true;
            this.positionDataGridViewTextBoxColumn.Width = 87;
            // 
            // shirtSizeDataGridViewTextBoxColumn
            // 
            this.shirtSizeDataGridViewTextBoxColumn.DataPropertyName = "ShirtSize";
            this.shirtSizeDataGridViewTextBoxColumn.HeaderText = "Shirt Size";
            this.shirtSizeDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.shirtSizeDataGridViewTextBoxColumn.Name = "shirtSizeDataGridViewTextBoxColumn";
            this.shirtSizeDataGridViewTextBoxColumn.ReadOnly = true;
            this.shirtSizeDataGridViewTextBoxColumn.Width = 90;
            // 
            // shortsSizeDataGridViewTextBoxColumn
            // 
            this.shortsSizeDataGridViewTextBoxColumn.DataPropertyName = "ShortsSize";
            this.shortsSizeDataGridViewTextBoxColumn.HeaderText = "Shorts Size";
            this.shortsSizeDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.shortsSizeDataGridViewTextBoxColumn.Name = "shortsSizeDataGridViewTextBoxColumn";
            this.shortsSizeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // hatSizeDataGridViewTextBoxColumn
            // 
            this.hatSizeDataGridViewTextBoxColumn.DataPropertyName = "HatSize";
            this.hatSizeDataGridViewTextBoxColumn.HeaderText = "Hat Size";
            this.hatSizeDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.hatSizeDataGridViewTextBoxColumn.Name = "hatSizeDataGridViewTextBoxColumn";
            this.hatSizeDataGridViewTextBoxColumn.ReadOnly = true;
            this.hatSizeDataGridViewTextBoxColumn.Width = 83;
            // 
            // shoeSizeDataGridViewTextBoxColumn
            // 
            this.shoeSizeDataGridViewTextBoxColumn.DataPropertyName = "ShoeSize";
            this.shoeSizeDataGridViewTextBoxColumn.HeaderText = "Shoe Size";
            this.shoeSizeDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.shoeSizeDataGridViewTextBoxColumn.Name = "shoeSizeDataGridViewTextBoxColumn";
            this.shoeSizeDataGridViewTextBoxColumn.ReadOnly = true;
            this.shoeSizeDataGridViewTextBoxColumn.Width = 93;
            // 
            // emergencyContactNameDataGridViewTextBoxColumn
            // 
            this.emergencyContactNameDataGridViewTextBoxColumn.DataPropertyName = "EmergencyContactName";
            this.emergencyContactNameDataGridViewTextBoxColumn.HeaderText = "Emergency Contact Name";
            this.emergencyContactNameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.emergencyContactNameDataGridViewTextBoxColumn.Name = "emergencyContactNameDataGridViewTextBoxColumn";
            this.emergencyContactNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.emergencyContactNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // emergencyContactNumberDataGridViewTextBoxColumn
            // 
            this.emergencyContactNumberDataGridViewTextBoxColumn.DataPropertyName = "EmergencyContactNumber";
            this.emergencyContactNumberDataGridViewTextBoxColumn.HeaderText = "Emergency Contact Number";
            this.emergencyContactNumberDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.emergencyContactNumberDataGridViewTextBoxColumn.Name = "emergencyContactNumberDataGridViewTextBoxColumn";
            this.emergencyContactNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.emergencyContactNumberDataGridViewTextBoxColumn.Width = 150;
            // 
            // playerInformationBaseballBindingSource
            // 
            this.playerInformationBaseballBindingSource.DataMember = "Player_Information_Baseball";
            this.playerInformationBaseballBindingSource.DataSource = this.bASportSDBDataSet;
            // 
            // bASportSDBDataSet
            // 
            this.bASportSDBDataSet.DataSetName = "BASportSDBDataSet";
            this.bASportSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblPlayers
            // 
            this.lblPlayers.AutoSize = true;
            this.lblPlayers.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayers.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayers.ForeColor = System.Drawing.Color.White;
            this.lblPlayers.Location = new System.Drawing.Point(11, 18);
            this.lblPlayers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPlayers.Name = "lblPlayers";
            this.lblPlayers.Size = new System.Drawing.Size(165, 36);
            this.lblPlayers.TabIndex = 11;
            this.lblPlayers.Text = "Player List";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.flowLayoutPanel1.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.flowLayoutPanel1.Controls.Add(this.grpPlayerInformation);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(685, 47);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(789, 538);
            this.flowLayoutPanel1.TabIndex = 18;
            // 
            // grpPlayerInformation
            // 
            this.grpPlayerInformation.AutoSize = true;
            this.grpPlayerInformation.BackColor = System.Drawing.Color.Transparent;
            this.grpPlayerInformation.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.grpPlayerInformation.Controls.Add(this.txtNumber);
            this.grpPlayerInformation.Controls.Add(this.lblNumber);
            this.grpPlayerInformation.Controls.Add(this.cmbEligible);
            this.grpPlayerInformation.Controls.Add(this.txtEmergencyContactNumber);
            this.grpPlayerInformation.Controls.Add(this.txtEmergencyContactName);
            this.grpPlayerInformation.Controls.Add(this.txtSchoolAddress);
            this.grpPlayerInformation.Controls.Add(this.lblEligible);
            this.grpPlayerInformation.Controls.Add(this.lblSchoolAddress);
            this.grpPlayerInformation.Controls.Add(this.lblEmergencyContactName);
            this.grpPlayerInformation.Controls.Add(this.lblEmergencyContactNumber);
            this.grpPlayerInformation.Controls.Add(this.txtEmail);
            this.grpPlayerInformation.Controls.Add(this.lblEmail);
            this.grpPlayerInformation.Controls.Add(this.txtHatSize);
            this.grpPlayerInformation.Controls.Add(this.cmbShoeSize);
            this.grpPlayerInformation.Controls.Add(this.cmbShortsSize);
            this.grpPlayerInformation.Controls.Add(this.cmbShirtSize);
            this.grpPlayerInformation.Controls.Add(this.txtPhone);
            this.grpPlayerInformation.Controls.Add(this.txtAddress);
            this.grpPlayerInformation.Controls.Add(this.txtTNumber);
            this.grpPlayerInformation.Controls.Add(this.txtPosition);
            this.grpPlayerInformation.Controls.Add(this.txtGraduationYear);
            this.grpPlayerInformation.Controls.Add(this.lblShoeSize);
            this.grpPlayerInformation.Controls.Add(this.lblTNumber);
            this.grpPlayerInformation.Controls.Add(this.lblShirtSize);
            this.grpPlayerInformation.Controls.Add(this.lblYear);
            this.grpPlayerInformation.Controls.Add(this.lblPosition);
            this.grpPlayerInformation.Controls.Add(this.lblShortsSize);
            this.grpPlayerInformation.Controls.Add(this.lblHatSize);
            this.grpPlayerInformation.Controls.Add(this.lblPhoneNumber);
            this.grpPlayerInformation.Controls.Add(this.lblHomeAddress);
            this.grpPlayerInformation.Controls.Add(this.txtWeight);
            this.grpPlayerInformation.Controls.Add(this.txtHeight);
            this.grpPlayerInformation.Controls.Add(this.txtName);
            this.grpPlayerInformation.Controls.Add(this.lblWeight);
            this.grpPlayerInformation.Controls.Add(this.lblHeight);
            this.grpPlayerInformation.Controls.Add(this.lblName);
            this.grpPlayerInformation.Location = new System.Drawing.Point(3, 3);
            this.grpPlayerInformation.Name = "grpPlayerInformation";
            this.grpPlayerInformation.Size = new System.Drawing.Size(738, 680);
            this.grpPlayerInformation.TabIndex = 17;
            this.grpPlayerInformation.TabStop = false;
            // 
            // txtNumber
            // 
            this.txtNumber.Location = new System.Drawing.Point(211, 321);
            this.txtNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(137, 22);
            this.txtNumber.TabIndex = 72;
            // 
            // lblNumber
            // 
            this.lblNumber.AutoSize = true;
            this.lblNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblNumber.ForeColor = System.Drawing.Color.White;
            this.lblNumber.Location = new System.Drawing.Point(145, 325);
            this.lblNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.Size = new System.Drawing.Size(62, 17);
            this.lblNumber.TabIndex = 71;
            this.lblNumber.Text = "Number:";
            // 
            // cmbEligible
            // 
            this.cmbEligible.FormattingEnabled = true;
            this.cmbEligible.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbEligible.Location = new System.Drawing.Point(211, 285);
            this.cmbEligible.Margin = new System.Windows.Forms.Padding(4);
            this.cmbEligible.Name = "cmbEligible";
            this.cmbEligible.Size = new System.Drawing.Size(160, 24);
            this.cmbEligible.TabIndex = 70;
            // 
            // txtEmergencyContactNumber
            // 
            this.txtEmergencyContactNumber.Location = new System.Drawing.Point(211, 636);
            this.txtEmergencyContactNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmergencyContactNumber.Name = "txtEmergencyContactNumber";
            this.txtEmergencyContactNumber.Size = new System.Drawing.Size(179, 22);
            this.txtEmergencyContactNumber.TabIndex = 69;
            // 
            // txtEmergencyContactName
            // 
            this.txtEmergencyContactName.Location = new System.Drawing.Point(211, 602);
            this.txtEmergencyContactName.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmergencyContactName.Name = "txtEmergencyContactName";
            this.txtEmergencyContactName.Size = new System.Drawing.Size(240, 22);
            this.txtEmergencyContactName.TabIndex = 68;
            // 
            // txtSchoolAddress
            // 
            this.txtSchoolAddress.Location = new System.Drawing.Point(211, 112);
            this.txtSchoolAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtSchoolAddress.Name = "txtSchoolAddress";
            this.txtSchoolAddress.Size = new System.Drawing.Size(520, 22);
            this.txtSchoolAddress.TabIndex = 67;
            // 
            // lblEligible
            // 
            this.lblEligible.AutoSize = true;
            this.lblEligible.BackColor = System.Drawing.Color.Transparent;
            this.lblEligible.ForeColor = System.Drawing.Color.White;
            this.lblEligible.Location = new System.Drawing.Point(149, 289);
            this.lblEligible.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEligible.Name = "lblEligible";
            this.lblEligible.Size = new System.Drawing.Size(57, 17);
            this.lblEligible.TabIndex = 66;
            this.lblEligible.Text = "Eligible:";
            // 
            // lblSchoolAddress
            // 
            this.lblSchoolAddress.AutoSize = true;
            this.lblSchoolAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblSchoolAddress.ForeColor = System.Drawing.Color.White;
            this.lblSchoolAddress.Location = new System.Drawing.Point(95, 113);
            this.lblSchoolAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSchoolAddress.Name = "lblSchoolAddress";
            this.lblSchoolAddress.Size = new System.Drawing.Size(111, 17);
            this.lblSchoolAddress.TabIndex = 65;
            this.lblSchoolAddress.Text = "School Address:";
            // 
            // lblEmergencyContactName
            // 
            this.lblEmergencyContactName.AutoSize = true;
            this.lblEmergencyContactName.ForeColor = System.Drawing.Color.White;
            this.lblEmergencyContactName.Location = new System.Drawing.Point(29, 607);
            this.lblEmergencyContactName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmergencyContactName.Name = "lblEmergencyContactName";
            this.lblEmergencyContactName.Size = new System.Drawing.Size(176, 17);
            this.lblEmergencyContactName.TabIndex = 64;
            this.lblEmergencyContactName.Text = "Emergency Contact Name:";
            // 
            // lblEmergencyContactNumber
            // 
            this.lblEmergencyContactNumber.AutoSize = true;
            this.lblEmergencyContactNumber.ForeColor = System.Drawing.Color.White;
            this.lblEmergencyContactNumber.Location = new System.Drawing.Point(16, 641);
            this.lblEmergencyContactNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmergencyContactNumber.Name = "lblEmergencyContactNumber";
            this.lblEmergencyContactNumber.Size = new System.Drawing.Size(189, 17);
            this.lblEmergencyContactNumber.TabIndex = 63;
            this.lblEmergencyContactNumber.Text = "Emergency Contact Number:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(211, 182);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(520, 22);
            this.txtEmail.TabIndex = 62;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.ForeColor = System.Drawing.Color.White;
            this.lblEmail.Location = new System.Drawing.Point(160, 185);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(46, 17);
            this.lblEmail.TabIndex = 61;
            this.lblEmail.Text = "Email:";
            // 
            // txtHatSize
            // 
            this.txtHatSize.Location = new System.Drawing.Point(211, 531);
            this.txtHatSize.Margin = new System.Windows.Forms.Padding(4);
            this.txtHatSize.Name = "txtHatSize";
            this.txtHatSize.Size = new System.Drawing.Size(137, 22);
            this.txtHatSize.TabIndex = 60;
            // 
            // cmbShoeSize
            // 
            this.cmbShoeSize.FormattingEnabled = true;
            this.cmbShoeSize.Items.AddRange(new object[] {
            "4",
            "4.5",
            "5",
            "5.5",
            "6",
            "6.5",
            "7",
            "7.5",
            "8",
            "8.5",
            "9",
            "9.5",
            "10",
            "10.5",
            "11",
            "11.5",
            "12",
            "12.5",
            "13",
            "13.5",
            "14",
            "14.5",
            "15",
            "15.5",
            "16",
            "16.5",
            "17",
            "17.5",
            "18",
            "18.5",
            "19"});
            this.cmbShoeSize.Location = new System.Drawing.Point(211, 566);
            this.cmbShoeSize.Margin = new System.Windows.Forms.Padding(4);
            this.cmbShoeSize.Name = "cmbShoeSize";
            this.cmbShoeSize.Size = new System.Drawing.Size(160, 24);
            this.cmbShoeSize.TabIndex = 59;
            // 
            // cmbShortsSize
            // 
            this.cmbShortsSize.FormattingEnabled = true;
            this.cmbShortsSize.Items.AddRange(new object[] {
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "XXL",
            "XXXL"});
            this.cmbShortsSize.Location = new System.Drawing.Point(211, 495);
            this.cmbShortsSize.Margin = new System.Windows.Forms.Padding(4);
            this.cmbShortsSize.Name = "cmbShortsSize";
            this.cmbShortsSize.Size = new System.Drawing.Size(160, 24);
            this.cmbShortsSize.TabIndex = 58;
            // 
            // cmbShirtSize
            // 
            this.cmbShirtSize.FormattingEnabled = true;
            this.cmbShirtSize.Items.AddRange(new object[] {
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "XXL",
            "XXXL"});
            this.cmbShirtSize.Location = new System.Drawing.Point(211, 460);
            this.cmbShirtSize.Margin = new System.Windows.Forms.Padding(4);
            this.cmbShirtSize.Name = "cmbShirtSize";
            this.cmbShirtSize.Size = new System.Drawing.Size(160, 24);
            this.cmbShirtSize.TabIndex = 57;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(211, 147);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(216, 22);
            this.txtPhone.TabIndex = 56;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(211, 77);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(520, 22);
            this.txtAddress.TabIndex = 55;
            // 
            // txtTNumber
            // 
            this.txtTNumber.Location = new System.Drawing.Point(211, 217);
            this.txtTNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtTNumber.Name = "txtTNumber";
            this.txtTNumber.Size = new System.Drawing.Size(179, 22);
            this.txtTNumber.TabIndex = 53;
            // 
            // txtPosition
            // 
            this.txtPosition.Location = new System.Drawing.Point(211, 425);
            this.txtPosition.Margin = new System.Windows.Forms.Padding(4);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(137, 22);
            this.txtPosition.TabIndex = 52;
            // 
            // txtGraduationYear
            // 
            this.txtGraduationYear.Location = new System.Drawing.Point(211, 252);
            this.txtGraduationYear.Margin = new System.Windows.Forms.Padding(4);
            this.txtGraduationYear.Name = "txtGraduationYear";
            this.txtGraduationYear.Size = new System.Drawing.Size(137, 22);
            this.txtGraduationYear.TabIndex = 51;
            // 
            // lblShoeSize
            // 
            this.lblShoeSize.AutoSize = true;
            this.lblShoeSize.ForeColor = System.Drawing.Color.White;
            this.lblShoeSize.Location = new System.Drawing.Point(131, 572);
            this.lblShoeSize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShoeSize.Name = "lblShoeSize";
            this.lblShoeSize.Size = new System.Drawing.Size(76, 17);
            this.lblShoeSize.TabIndex = 50;
            this.lblShoeSize.Text = "Shoe Size:";
            // 
            // lblTNumber
            // 
            this.lblTNumber.AutoSize = true;
            this.lblTNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblTNumber.ForeColor = System.Drawing.Color.White;
            this.lblTNumber.Location = new System.Drawing.Point(133, 220);
            this.lblTNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTNumber.Name = "lblTNumber";
            this.lblTNumber.Size = new System.Drawing.Size(75, 17);
            this.lblTNumber.TabIndex = 49;
            this.lblTNumber.Text = "T Number:";
            // 
            // lblShirtSize
            // 
            this.lblShirtSize.AutoSize = true;
            this.lblShirtSize.BackColor = System.Drawing.Color.Transparent;
            this.lblShirtSize.ForeColor = System.Drawing.Color.White;
            this.lblShirtSize.Location = new System.Drawing.Point(133, 465);
            this.lblShirtSize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShirtSize.Name = "lblShirtSize";
            this.lblShirtSize.Size = new System.Drawing.Size(72, 17);
            this.lblShirtSize.TabIndex = 48;
            this.lblShirtSize.Text = "Shirt Size:";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.BackColor = System.Drawing.Color.Transparent;
            this.lblYear.ForeColor = System.Drawing.Color.White;
            this.lblYear.Location = new System.Drawing.Point(91, 255);
            this.lblYear.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(117, 17);
            this.lblYear.TabIndex = 47;
            this.lblYear.Text = "Graduation Year:";
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.BackColor = System.Drawing.Color.Transparent;
            this.lblPosition.ForeColor = System.Drawing.Color.White;
            this.lblPosition.Location = new System.Drawing.Point(144, 431);
            this.lblPosition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(62, 17);
            this.lblPosition.TabIndex = 46;
            this.lblPosition.Text = "Position:";
            // 
            // lblShortsSize
            // 
            this.lblShortsSize.AutoSize = true;
            this.lblShortsSize.BackColor = System.Drawing.Color.Transparent;
            this.lblShortsSize.ForeColor = System.Drawing.Color.White;
            this.lblShortsSize.Location = new System.Drawing.Point(123, 501);
            this.lblShortsSize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShortsSize.Name = "lblShortsSize";
            this.lblShortsSize.Size = new System.Drawing.Size(84, 17);
            this.lblShortsSize.TabIndex = 44;
            this.lblShortsSize.Text = "Shorts Size:";
            // 
            // lblHatSize
            // 
            this.lblHatSize.AutoSize = true;
            this.lblHatSize.ForeColor = System.Drawing.Color.White;
            this.lblHatSize.Location = new System.Drawing.Point(141, 537);
            this.lblHatSize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHatSize.Name = "lblHatSize";
            this.lblHatSize.Size = new System.Drawing.Size(65, 17);
            this.lblHatSize.TabIndex = 43;
            this.lblHatSize.Text = "Hat Size:";
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblPhoneNumber.ForeColor = System.Drawing.Color.White;
            this.lblPhoneNumber.Location = new System.Drawing.Point(155, 149);
            this.lblPhoneNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(53, 17);
            this.lblPhoneNumber.TabIndex = 42;
            this.lblPhoneNumber.Text = "Phone:";
            // 
            // lblHomeAddress
            // 
            this.lblHomeAddress.AutoSize = true;
            this.lblHomeAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblHomeAddress.ForeColor = System.Drawing.Color.White;
            this.lblHomeAddress.Location = new System.Drawing.Point(143, 79);
            this.lblHomeAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHomeAddress.Name = "lblHomeAddress";
            this.lblHomeAddress.Size = new System.Drawing.Size(64, 17);
            this.lblHomeAddress.TabIndex = 41;
            this.lblHomeAddress.Text = "Address:";
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(211, 390);
            this.txtWeight.Margin = new System.Windows.Forms.Padding(4);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(137, 22);
            this.txtWeight.TabIndex = 26;
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(211, 356);
            this.txtHeight.Margin = new System.Windows.Forms.Padding(4);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(137, 22);
            this.txtHeight.TabIndex = 25;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(211, 44);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(240, 22);
            this.txtName.TabIndex = 24;
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.BackColor = System.Drawing.Color.Transparent;
            this.lblWeight.ForeColor = System.Drawing.Color.White;
            this.lblWeight.Location = new System.Drawing.Point(151, 396);
            this.lblWeight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(56, 17);
            this.lblWeight.TabIndex = 23;
            this.lblWeight.Text = "Weight:";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.BackColor = System.Drawing.Color.Transparent;
            this.lblHeight.ForeColor = System.Drawing.Color.White;
            this.lblHeight.Location = new System.Drawing.Point(155, 361);
            this.lblHeight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(53, 17);
            this.lblHeight.TabIndex = 22;
            this.lblHeight.Text = "Height:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.White;
            this.lblName.Location = new System.Drawing.Point(157, 44);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(49, 17);
            this.lblName.TabIndex = 21;
            this.lblName.Text = "Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(684, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 36);
            this.label1.TabIndex = 19;
            this.label1.Text = "Add/Edit Player";
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClear.BackgroundImage")));
            this.btnClear.Location = new System.Drawing.Point(1088, 602);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(152, 58);
            this.btnClear.TabIndex = 20;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnReturn.Location = new System.Drawing.Point(1162, 2);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(152, 38);
            this.btnReturn.TabIndex = 21;
            this.btnReturn.Text = "Back";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // player_Information_BaseballTableAdapter
            // 
            this.player_Information_BaseballTableAdapter.ClearBeforeFill = true;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Transparent;
            this.btnLogout.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnLogout.Location = new System.Drawing.Point(1322, 2);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(152, 38);
            this.btnLogout.TabIndex = 22;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // frmPlayerInfoBaseball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.ClientSize = new System.Drawing.Size(1571, 666);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblPlayers);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmPlayerInfoBaseball";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Player Information - Baseball";
            this.Load += new System.EventHandler(this.frmPlayerInfoBaseball_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationBaseballBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.grpPlayerInformation.ResumeLayout(false);
            this.grpPlayerInformation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblPlayers;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox grpPlayerInformation;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.ComboBox cmbEligible;
        private System.Windows.Forms.TextBox txtEmergencyContactNumber;
        private System.Windows.Forms.TextBox txtEmergencyContactName;
        private System.Windows.Forms.TextBox txtSchoolAddress;
        private System.Windows.Forms.Label lblEligible;
        private System.Windows.Forms.Label lblSchoolAddress;
        private System.Windows.Forms.Label lblEmergencyContactName;
        private System.Windows.Forms.Label lblEmergencyContactNumber;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtHatSize;
        private System.Windows.Forms.ComboBox cmbShoeSize;
        private System.Windows.Forms.ComboBox cmbShortsSize;
        private System.Windows.Forms.ComboBox cmbShirtSize;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtTNumber;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.TextBox txtGraduationYear;
        private System.Windows.Forms.Label lblShoeSize;
        private System.Windows.Forms.Label lblTNumber;
        private System.Windows.Forms.Label lblShirtSize;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblShortsSize;
        private System.Windows.Forms.Label lblHatSize;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.Label lblHomeAddress;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnReturn;
        private BASportSDBDataSet bASportSDBDataSet;
        private System.Windows.Forms.BindingSource playerInformationBaseballBindingSource;
        private BASportSDBDataSetTableAdapters.Player_Information_BaseballTableAdapter player_Information_BaseballTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn schoolAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn graduationYearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eligibleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn heightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shirtSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortsSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hatSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shoeSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emergencyContactNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emergencyContactNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnLogout;
    }
}