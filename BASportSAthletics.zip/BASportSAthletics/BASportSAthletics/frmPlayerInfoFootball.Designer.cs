﻿namespace BASportSAthletics
{
    partial class frmPlayerInfoFootball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPlayerInfoFootball));
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.grpPlayerInformation = new System.Windows.Forms.GroupBox();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.lblNumber = new System.Windows.Forms.Label();
            this.cmbEligible = new System.Windows.Forms.ComboBox();
            this.txtEmergencyContactNumber = new System.Windows.Forms.TextBox();
            this.txtEmergencyContactName = new System.Windows.Forms.TextBox();
            this.txtSchoolAddress = new System.Windows.Forms.TextBox();
            this.lblEligible = new System.Windows.Forms.Label();
            this.lblSchoolAddress = new System.Windows.Forms.Label();
            this.lblEmergencyContactName = new System.Windows.Forms.Label();
            this.lblEmergencyContactNumber = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtHatSize = new System.Windows.Forms.TextBox();
            this.cmbShoeSize = new System.Windows.Forms.ComboBox();
            this.cmbShortsSize = new System.Windows.Forms.ComboBox();
            this.cmbShirtSize = new System.Windows.Forms.ComboBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtTNumber = new System.Windows.Forms.TextBox();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.txtGraduationYear = new System.Windows.Forms.TextBox();
            this.lblShoeSize = new System.Windows.Forms.Label();
            this.lblTNumber = new System.Windows.Forms.Label();
            this.lblShirtSize = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblShortsSize = new System.Windows.Forms.Label();
            this.lblHatSize = new System.Windows.Forms.Label();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.lblHomeAddress = new System.Windows.Forms.Label();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblPlayers = new System.Windows.Forms.Label();
            this.bASportSDBDataSet = new BASportSAthletics.BASportSDBDataSet();
            this.playerInformationFootballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.player_Information_FootballTableAdapter = new BASportSAthletics.BASportSDBDataSetTableAdapters.Player_Information_FootballTableAdapter();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flowLayoutPanel1.SuspendLayout();
            this.grpPlayerInformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationFootballBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Transparent;
            this.btnLogout.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnLogout.Location = new System.Drawing.Point(1297, 12);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(152, 38);
            this.btnLogout.TabIndex = 32;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnReturn.Location = new System.Drawing.Point(1137, 12);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(152, 38);
            this.btnReturn.TabIndex = 31;
            this.btnReturn.Text = "Back";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClear.BackgroundImage")));
            this.btnClear.Location = new System.Drawing.Point(1090, 612);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(152, 58);
            this.btnClear.TabIndex = 30;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(686, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 36);
            this.label1.TabIndex = 29;
            this.label1.Text = "Add/Edit Player";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.flowLayoutPanel1.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.flowLayoutPanel1.Controls.Add(this.grpPlayerInformation);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(687, 57);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(789, 538);
            this.flowLayoutPanel1.TabIndex = 28;
            // 
            // grpPlayerInformation
            // 
            this.grpPlayerInformation.AutoSize = true;
            this.grpPlayerInformation.BackColor = System.Drawing.Color.Transparent;
            this.grpPlayerInformation.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.grpPlayerInformation.Controls.Add(this.txtNumber);
            this.grpPlayerInformation.Controls.Add(this.lblNumber);
            this.grpPlayerInformation.Controls.Add(this.cmbEligible);
            this.grpPlayerInformation.Controls.Add(this.txtEmergencyContactNumber);
            this.grpPlayerInformation.Controls.Add(this.txtEmergencyContactName);
            this.grpPlayerInformation.Controls.Add(this.txtSchoolAddress);
            this.grpPlayerInformation.Controls.Add(this.lblEligible);
            this.grpPlayerInformation.Controls.Add(this.lblSchoolAddress);
            this.grpPlayerInformation.Controls.Add(this.lblEmergencyContactName);
            this.grpPlayerInformation.Controls.Add(this.lblEmergencyContactNumber);
            this.grpPlayerInformation.Controls.Add(this.txtEmail);
            this.grpPlayerInformation.Controls.Add(this.lblEmail);
            this.grpPlayerInformation.Controls.Add(this.txtHatSize);
            this.grpPlayerInformation.Controls.Add(this.cmbShoeSize);
            this.grpPlayerInformation.Controls.Add(this.cmbShortsSize);
            this.grpPlayerInformation.Controls.Add(this.cmbShirtSize);
            this.grpPlayerInformation.Controls.Add(this.txtPhone);
            this.grpPlayerInformation.Controls.Add(this.txtAddress);
            this.grpPlayerInformation.Controls.Add(this.txtTNumber);
            this.grpPlayerInformation.Controls.Add(this.txtPosition);
            this.grpPlayerInformation.Controls.Add(this.txtGraduationYear);
            this.grpPlayerInformation.Controls.Add(this.lblShoeSize);
            this.grpPlayerInformation.Controls.Add(this.lblTNumber);
            this.grpPlayerInformation.Controls.Add(this.lblShirtSize);
            this.grpPlayerInformation.Controls.Add(this.lblYear);
            this.grpPlayerInformation.Controls.Add(this.lblPosition);
            this.grpPlayerInformation.Controls.Add(this.lblShortsSize);
            this.grpPlayerInformation.Controls.Add(this.lblHatSize);
            this.grpPlayerInformation.Controls.Add(this.lblPhoneNumber);
            this.grpPlayerInformation.Controls.Add(this.lblHomeAddress);
            this.grpPlayerInformation.Controls.Add(this.txtWeight);
            this.grpPlayerInformation.Controls.Add(this.txtHeight);
            this.grpPlayerInformation.Controls.Add(this.txtName);
            this.grpPlayerInformation.Controls.Add(this.lblWeight);
            this.grpPlayerInformation.Controls.Add(this.lblHeight);
            this.grpPlayerInformation.Controls.Add(this.lblName);
            this.grpPlayerInformation.Location = new System.Drawing.Point(3, 3);
            this.grpPlayerInformation.Name = "grpPlayerInformation";
            this.grpPlayerInformation.Size = new System.Drawing.Size(738, 680);
            this.grpPlayerInformation.TabIndex = 17;
            this.grpPlayerInformation.TabStop = false;
            // 
            // txtNumber
            // 
            this.txtNumber.Location = new System.Drawing.Point(211, 321);
            this.txtNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(137, 22);
            this.txtNumber.TabIndex = 72;
            // 
            // lblNumber
            // 
            this.lblNumber.AutoSize = true;
            this.lblNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblNumber.ForeColor = System.Drawing.Color.White;
            this.lblNumber.Location = new System.Drawing.Point(145, 325);
            this.lblNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.Size = new System.Drawing.Size(62, 17);
            this.lblNumber.TabIndex = 71;
            this.lblNumber.Text = "Number:";
            // 
            // cmbEligible
            // 
            this.cmbEligible.FormattingEnabled = true;
            this.cmbEligible.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbEligible.Location = new System.Drawing.Point(211, 285);
            this.cmbEligible.Margin = new System.Windows.Forms.Padding(4);
            this.cmbEligible.Name = "cmbEligible";
            this.cmbEligible.Size = new System.Drawing.Size(160, 24);
            this.cmbEligible.TabIndex = 70;
            // 
            // txtEmergencyContactNumber
            // 
            this.txtEmergencyContactNumber.Location = new System.Drawing.Point(211, 636);
            this.txtEmergencyContactNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmergencyContactNumber.Name = "txtEmergencyContactNumber";
            this.txtEmergencyContactNumber.Size = new System.Drawing.Size(179, 22);
            this.txtEmergencyContactNumber.TabIndex = 69;
            // 
            // txtEmergencyContactName
            // 
            this.txtEmergencyContactName.Location = new System.Drawing.Point(211, 602);
            this.txtEmergencyContactName.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmergencyContactName.Name = "txtEmergencyContactName";
            this.txtEmergencyContactName.Size = new System.Drawing.Size(240, 22);
            this.txtEmergencyContactName.TabIndex = 68;
            // 
            // txtSchoolAddress
            // 
            this.txtSchoolAddress.Location = new System.Drawing.Point(211, 112);
            this.txtSchoolAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtSchoolAddress.Name = "txtSchoolAddress";
            this.txtSchoolAddress.Size = new System.Drawing.Size(520, 22);
            this.txtSchoolAddress.TabIndex = 67;
            // 
            // lblEligible
            // 
            this.lblEligible.AutoSize = true;
            this.lblEligible.BackColor = System.Drawing.Color.Transparent;
            this.lblEligible.ForeColor = System.Drawing.Color.White;
            this.lblEligible.Location = new System.Drawing.Point(149, 289);
            this.lblEligible.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEligible.Name = "lblEligible";
            this.lblEligible.Size = new System.Drawing.Size(57, 17);
            this.lblEligible.TabIndex = 66;
            this.lblEligible.Text = "Eligible:";
            // 
            // lblSchoolAddress
            // 
            this.lblSchoolAddress.AutoSize = true;
            this.lblSchoolAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblSchoolAddress.ForeColor = System.Drawing.Color.White;
            this.lblSchoolAddress.Location = new System.Drawing.Point(95, 113);
            this.lblSchoolAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSchoolAddress.Name = "lblSchoolAddress";
            this.lblSchoolAddress.Size = new System.Drawing.Size(111, 17);
            this.lblSchoolAddress.TabIndex = 65;
            this.lblSchoolAddress.Text = "School Address:";
            // 
            // lblEmergencyContactName
            // 
            this.lblEmergencyContactName.AutoSize = true;
            this.lblEmergencyContactName.ForeColor = System.Drawing.Color.White;
            this.lblEmergencyContactName.Location = new System.Drawing.Point(29, 607);
            this.lblEmergencyContactName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmergencyContactName.Name = "lblEmergencyContactName";
            this.lblEmergencyContactName.Size = new System.Drawing.Size(176, 17);
            this.lblEmergencyContactName.TabIndex = 64;
            this.lblEmergencyContactName.Text = "Emergency Contact Name:";
            // 
            // lblEmergencyContactNumber
            // 
            this.lblEmergencyContactNumber.AutoSize = true;
            this.lblEmergencyContactNumber.ForeColor = System.Drawing.Color.White;
            this.lblEmergencyContactNumber.Location = new System.Drawing.Point(16, 641);
            this.lblEmergencyContactNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmergencyContactNumber.Name = "lblEmergencyContactNumber";
            this.lblEmergencyContactNumber.Size = new System.Drawing.Size(189, 17);
            this.lblEmergencyContactNumber.TabIndex = 63;
            this.lblEmergencyContactNumber.Text = "Emergency Contact Number:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(211, 182);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(520, 22);
            this.txtEmail.TabIndex = 62;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.ForeColor = System.Drawing.Color.White;
            this.lblEmail.Location = new System.Drawing.Point(160, 185);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(46, 17);
            this.lblEmail.TabIndex = 61;
            this.lblEmail.Text = "Email:";
            // 
            // txtHatSize
            // 
            this.txtHatSize.Location = new System.Drawing.Point(211, 531);
            this.txtHatSize.Margin = new System.Windows.Forms.Padding(4);
            this.txtHatSize.Name = "txtHatSize";
            this.txtHatSize.Size = new System.Drawing.Size(137, 22);
            this.txtHatSize.TabIndex = 60;
            // 
            // cmbShoeSize
            // 
            this.cmbShoeSize.FormattingEnabled = true;
            this.cmbShoeSize.Items.AddRange(new object[] {
            "4",
            "4.5",
            "5",
            "5.5",
            "6",
            "6.5",
            "7",
            "7.5",
            "8",
            "8.5",
            "9",
            "9.5",
            "10",
            "10.5",
            "11",
            "11.5",
            "12",
            "12.5",
            "13",
            "13.5",
            "14",
            "14.5",
            "15",
            "15.5",
            "16",
            "16.5",
            "17",
            "17.5",
            "18",
            "18.5",
            "19"});
            this.cmbShoeSize.Location = new System.Drawing.Point(211, 566);
            this.cmbShoeSize.Margin = new System.Windows.Forms.Padding(4);
            this.cmbShoeSize.Name = "cmbShoeSize";
            this.cmbShoeSize.Size = new System.Drawing.Size(160, 24);
            this.cmbShoeSize.TabIndex = 59;
            // 
            // cmbShortsSize
            // 
            this.cmbShortsSize.FormattingEnabled = true;
            this.cmbShortsSize.Items.AddRange(new object[] {
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "XXL",
            "XXXL"});
            this.cmbShortsSize.Location = new System.Drawing.Point(211, 495);
            this.cmbShortsSize.Margin = new System.Windows.Forms.Padding(4);
            this.cmbShortsSize.Name = "cmbShortsSize";
            this.cmbShortsSize.Size = new System.Drawing.Size(160, 24);
            this.cmbShortsSize.TabIndex = 58;
            // 
            // cmbShirtSize
            // 
            this.cmbShirtSize.FormattingEnabled = true;
            this.cmbShirtSize.Items.AddRange(new object[] {
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "XXL",
            "XXXL"});
            this.cmbShirtSize.Location = new System.Drawing.Point(211, 460);
            this.cmbShirtSize.Margin = new System.Windows.Forms.Padding(4);
            this.cmbShirtSize.Name = "cmbShirtSize";
            this.cmbShirtSize.Size = new System.Drawing.Size(160, 24);
            this.cmbShirtSize.TabIndex = 57;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(211, 147);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(216, 22);
            this.txtPhone.TabIndex = 56;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(211, 77);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(520, 22);
            this.txtAddress.TabIndex = 55;
            // 
            // txtTNumber
            // 
            this.txtTNumber.Location = new System.Drawing.Point(211, 217);
            this.txtTNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtTNumber.Name = "txtTNumber";
            this.txtTNumber.Size = new System.Drawing.Size(179, 22);
            this.txtTNumber.TabIndex = 53;
            // 
            // txtPosition
            // 
            this.txtPosition.Location = new System.Drawing.Point(211, 425);
            this.txtPosition.Margin = new System.Windows.Forms.Padding(4);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(137, 22);
            this.txtPosition.TabIndex = 52;
            // 
            // txtGraduationYear
            // 
            this.txtGraduationYear.Location = new System.Drawing.Point(211, 252);
            this.txtGraduationYear.Margin = new System.Windows.Forms.Padding(4);
            this.txtGraduationYear.Name = "txtGraduationYear";
            this.txtGraduationYear.Size = new System.Drawing.Size(137, 22);
            this.txtGraduationYear.TabIndex = 51;
            // 
            // lblShoeSize
            // 
            this.lblShoeSize.AutoSize = true;
            this.lblShoeSize.ForeColor = System.Drawing.Color.White;
            this.lblShoeSize.Location = new System.Drawing.Point(131, 572);
            this.lblShoeSize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShoeSize.Name = "lblShoeSize";
            this.lblShoeSize.Size = new System.Drawing.Size(76, 17);
            this.lblShoeSize.TabIndex = 50;
            this.lblShoeSize.Text = "Shoe Size:";
            // 
            // lblTNumber
            // 
            this.lblTNumber.AutoSize = true;
            this.lblTNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblTNumber.ForeColor = System.Drawing.Color.White;
            this.lblTNumber.Location = new System.Drawing.Point(133, 220);
            this.lblTNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTNumber.Name = "lblTNumber";
            this.lblTNumber.Size = new System.Drawing.Size(75, 17);
            this.lblTNumber.TabIndex = 49;
            this.lblTNumber.Text = "T Number:";
            // 
            // lblShirtSize
            // 
            this.lblShirtSize.AutoSize = true;
            this.lblShirtSize.BackColor = System.Drawing.Color.Transparent;
            this.lblShirtSize.ForeColor = System.Drawing.Color.White;
            this.lblShirtSize.Location = new System.Drawing.Point(133, 465);
            this.lblShirtSize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShirtSize.Name = "lblShirtSize";
            this.lblShirtSize.Size = new System.Drawing.Size(72, 17);
            this.lblShirtSize.TabIndex = 48;
            this.lblShirtSize.Text = "Shirt Size:";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.BackColor = System.Drawing.Color.Transparent;
            this.lblYear.ForeColor = System.Drawing.Color.White;
            this.lblYear.Location = new System.Drawing.Point(91, 255);
            this.lblYear.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(117, 17);
            this.lblYear.TabIndex = 47;
            this.lblYear.Text = "Graduation Year:";
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.BackColor = System.Drawing.Color.Transparent;
            this.lblPosition.ForeColor = System.Drawing.Color.White;
            this.lblPosition.Location = new System.Drawing.Point(144, 431);
            this.lblPosition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(62, 17);
            this.lblPosition.TabIndex = 46;
            this.lblPosition.Text = "Position:";
            // 
            // lblShortsSize
            // 
            this.lblShortsSize.AutoSize = true;
            this.lblShortsSize.BackColor = System.Drawing.Color.Transparent;
            this.lblShortsSize.ForeColor = System.Drawing.Color.White;
            this.lblShortsSize.Location = new System.Drawing.Point(123, 501);
            this.lblShortsSize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShortsSize.Name = "lblShortsSize";
            this.lblShortsSize.Size = new System.Drawing.Size(84, 17);
            this.lblShortsSize.TabIndex = 44;
            this.lblShortsSize.Text = "Shorts Size:";
            // 
            // lblHatSize
            // 
            this.lblHatSize.AutoSize = true;
            this.lblHatSize.ForeColor = System.Drawing.Color.White;
            this.lblHatSize.Location = new System.Drawing.Point(141, 537);
            this.lblHatSize.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHatSize.Name = "lblHatSize";
            this.lblHatSize.Size = new System.Drawing.Size(65, 17);
            this.lblHatSize.TabIndex = 43;
            this.lblHatSize.Text = "Hat Size:";
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblPhoneNumber.ForeColor = System.Drawing.Color.White;
            this.lblPhoneNumber.Location = new System.Drawing.Point(155, 149);
            this.lblPhoneNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(53, 17);
            this.lblPhoneNumber.TabIndex = 42;
            this.lblPhoneNumber.Text = "Phone:";
            // 
            // lblHomeAddress
            // 
            this.lblHomeAddress.AutoSize = true;
            this.lblHomeAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblHomeAddress.ForeColor = System.Drawing.Color.White;
            this.lblHomeAddress.Location = new System.Drawing.Point(143, 79);
            this.lblHomeAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHomeAddress.Name = "lblHomeAddress";
            this.lblHomeAddress.Size = new System.Drawing.Size(64, 17);
            this.lblHomeAddress.TabIndex = 41;
            this.lblHomeAddress.Text = "Address:";
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(211, 390);
            this.txtWeight.Margin = new System.Windows.Forms.Padding(4);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(137, 22);
            this.txtWeight.TabIndex = 26;
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(211, 356);
            this.txtHeight.Margin = new System.Windows.Forms.Padding(4);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(137, 22);
            this.txtHeight.TabIndex = 25;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(211, 44);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(240, 22);
            this.txtName.TabIndex = 24;
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.BackColor = System.Drawing.Color.Transparent;
            this.lblWeight.ForeColor = System.Drawing.Color.White;
            this.lblWeight.Location = new System.Drawing.Point(151, 396);
            this.lblWeight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(56, 17);
            this.lblWeight.TabIndex = 23;
            this.lblWeight.Text = "Weight:";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.BackColor = System.Drawing.Color.Transparent;
            this.lblHeight.ForeColor = System.Drawing.Color.White;
            this.lblHeight.Location = new System.Drawing.Point(155, 361);
            this.lblHeight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(53, 17);
            this.lblHeight.TabIndex = 22;
            this.lblHeight.Text = "Height:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.White;
            this.lblName.Location = new System.Drawing.Point(157, 44);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(49, 17);
            this.lblName.TabIndex = 21;
            this.lblName.Text = "Name:";
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDelete.BackgroundImage")));
            this.btnDelete.Location = new System.Drawing.Point(1250, 612);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(152, 58);
            this.btnDelete.TabIndex = 27;
            this.btnDelete.Text = "Delete Player";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEdit.BackgroundImage")));
            this.btnEdit.Location = new System.Drawing.Point(930, 612);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(152, 58);
            this.btnEdit.TabIndex = 26;
            this.btnEdit.Text = "Edit Player";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.Location = new System.Drawing.Point(770, 612);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(152, 58);
            this.btnAdd.TabIndex = 25;
            this.btnAdd.Text = "Add Player";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn6});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView1.DataSource = this.playerInformationFootballBindingSource;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(13, 67);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(667, 586);
            this.dataGridView1.TabIndex = 24;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // lblPlayers
            // 
            this.lblPlayers.AutoSize = true;
            this.lblPlayers.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayers.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayers.ForeColor = System.Drawing.Color.White;
            this.lblPlayers.Location = new System.Drawing.Point(13, 28);
            this.lblPlayers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPlayers.Name = "lblPlayers";
            this.lblPlayers.Size = new System.Drawing.Size(165, 36);
            this.lblPlayers.TabIndex = 23;
            this.lblPlayers.Text = "Player List";
            // 
            // bASportSDBDataSet
            // 
            this.bASportSDBDataSet.DataSetName = "BASportSDBDataSet";
            this.bASportSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // playerInformationFootballBindingSource
            // 
            this.playerInformationFootballBindingSource.DataMember = "Player_Information_Football";
            this.playerInformationFootballBindingSource.DataSource = this.bASportSDBDataSet;
            // 
            // player_Information_FootballTableAdapter
            // 
            this.player_Information_FootballTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn1.HeaderText = "Name";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 74;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn2.HeaderText = "Address";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 89;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "SchoolAddress";
            this.dataGridViewTextBoxColumn16.HeaderText = "School Address";
            this.dataGridViewTextBoxColumn16.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Phone";
            this.dataGridViewTextBoxColumn3.HeaderText = "Phone";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 78;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Email";
            this.dataGridViewTextBoxColumn18.HeaderText = "Email";
            this.dataGridViewTextBoxColumn18.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 71;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "TNumber";
            this.dataGridViewTextBoxColumn5.HeaderText = "T Number";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 92;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "GraduationYear";
            this.dataGridViewTextBoxColumn7.HeaderText = "Graduation Year";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 130;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Eligible";
            this.dataGridViewTextBoxColumn17.HeaderText = "Eligible";
            this.dataGridViewTextBoxColumn17.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 82;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Number";
            this.dataGridViewTextBoxColumn8.HeaderText = "Number";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 87;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Height";
            this.dataGridViewTextBoxColumn9.HeaderText = "Height";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 78;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Weight";
            this.dataGridViewTextBoxColumn10.HeaderText = "Weight";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 81;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Position";
            this.dataGridViewTextBoxColumn11.HeaderText = "Position";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 87;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "ShirtSize";
            this.dataGridViewTextBoxColumn12.HeaderText = "Shirt Size";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 90;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "ShortsSize";
            this.dataGridViewTextBoxColumn13.HeaderText = "Shorts Size";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "HatSize";
            this.dataGridViewTextBoxColumn14.HeaderText = "Hat Size";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 83;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "ShoeSize";
            this.dataGridViewTextBoxColumn15.HeaderText = "Shoe Size";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 93;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "EmergencyContactName";
            this.dataGridViewTextBoxColumn4.HeaderText = "Emergency Contact Name";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "EmergencyContactNumber";
            this.dataGridViewTextBoxColumn6.HeaderText = "Emergency Contact Number";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 150;
            // 
            // frmPlayerInfoFootball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.ClientSize = new System.Drawing.Size(1478, 693);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblPlayers);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmPlayerInfoFootball";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmPlayerInfoFootball";
            this.Load += new System.EventHandler(this.frmPlayerInfoFootball_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.grpPlayerInformation.ResumeLayout(false);
            this.grpPlayerInformation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationFootballBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn schoolAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn graduationYearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eligibleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn heightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shirtSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortsSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hatSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shoeSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emergencyContactNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emergencyContactNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox grpPlayerInformation;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.ComboBox cmbEligible;
        private System.Windows.Forms.TextBox txtEmergencyContactNumber;
        private System.Windows.Forms.TextBox txtEmergencyContactName;
        private System.Windows.Forms.TextBox txtSchoolAddress;
        private System.Windows.Forms.Label lblEligible;
        private System.Windows.Forms.Label lblSchoolAddress;
        private System.Windows.Forms.Label lblEmergencyContactName;
        private System.Windows.Forms.Label lblEmergencyContactNumber;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtHatSize;
        private System.Windows.Forms.ComboBox cmbShoeSize;
        private System.Windows.Forms.ComboBox cmbShortsSize;
        private System.Windows.Forms.ComboBox cmbShirtSize;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtTNumber;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.TextBox txtGraduationYear;
        private System.Windows.Forms.Label lblShoeSize;
        private System.Windows.Forms.Label lblTNumber;
        private System.Windows.Forms.Label lblShirtSize;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblShortsSize;
        private System.Windows.Forms.Label lblHatSize;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.Label lblHomeAddress;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblPlayers;
        private BASportSDBDataSet bASportSDBDataSet;
        private System.Windows.Forms.BindingSource playerInformationFootballBindingSource;
        private BASportSDBDataSetTableAdapters.Player_Information_FootballTableAdapter player_Information_FootballTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}