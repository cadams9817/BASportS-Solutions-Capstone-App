﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Win32.SafeHandles;
using System.Configuration;
using System.Security;

namespace BASportSAthletics
{
    public partial class frmPlayerInfoFootball : Form
    {
        SqlConnection con = new SqlConnection("Data Source = (LocalDB)\\MSSQLLocalDB; " +
      "AttachDbFilename=|DataDirectory|\\BASportSDB.mdf;" +
        "Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapt;

        public frmPlayerInfoFootball()
        {
            InitializeComponent();
            DisplayData();
        }

        private void frmPlayerInfoFootball_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Player_Information_Football' table. You can move, or remove it, as needed.
            this.player_Information_FootballTableAdapter.Fill(this.bASportSDBDataSet.Player_Information_Football);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "")
            {
                cmd = new SqlCommand("INSERT INTO Player_Information_Football " +
                "(Name, Address, Phone, EmergencyContactName, TNumber, EmergencyContactNumber, GraduationYear, " +
                "Number, Height, Weight, Position, ShirtSize, ShortsSize, HatSize, ShoeSize, SchoolAddress, " +
                "Eligible, Email) " +
                "VALUES (@Name, @Address, @Phone, @EmergencyContactName, @TNumber, @EmergencyContactNumber, @GraduationYear, " +
                "@Number, @Height, @Weight, @Position, @ShirtSize, @ShortsSize, @HatSize, @ShoeSize, @SchoolAddress, " +
                "@Eligible, @Email)", con);
                con.Open();
                cmd.Parameters.AddWithValue("Name", txtName.Text);
                cmd.Parameters.AddWithValue("Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("Phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("EmergencyContactName", txtEmergencyContactName.Text);
                cmd.Parameters.AddWithValue("EmergencyContactNumber", txtEmergencyContactNumber.Text);
                cmd.Parameters.AddWithValue("TNumber", txtTNumber.Text);
                cmd.Parameters.AddWithValue("Number", txtNumber.Text);
                cmd.Parameters.AddWithValue("SchoolAddress", txtSchoolAddress.Text);
                cmd.Parameters.AddWithValue("GraduationYear", txtGraduationYear.Text);
                cmd.Parameters.AddWithValue("Height", txtHeight.Text);
                cmd.Parameters.AddWithValue("Weight", txtWeight.Text);
                cmd.Parameters.AddWithValue("Position", txtPosition.Text);
                cmd.Parameters.AddWithValue("Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("HatSize", txtHatSize.Text);
                cmd.Parameters.AddWithValue("Eligible", cmbEligible.Text);
                cmd.Parameters.AddWithValue("ShirtSize", cmbShirtSize.Text);
                cmd.Parameters.AddWithValue("ShoeSize", cmbShoeSize.Text);
                cmd.Parameters.AddWithValue("ShortsSize", cmbShortsSize.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Player added successfully");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please provide name!");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "")
            {
                cmd = new SqlCommand("UPDATE Player_Information_Football SET Address = @Address, Phone = @Phone, EmergencyContactName = @EmergencyContactName, " +
                "EmergencyContactNumber = @EmergencyContactNumber, TNumber = @TNumber, Number = @Number, SchoolAddress = @SchoolAddress, " +
                "GraduationYear = @GraduationYear, Height = @Height, Weight = @Weight, Position = @Position, Email = @Email, HatSize = @HatSize, " +
                "Eligible = @Eligible, ShirtSize = @ShirtSize, ShoeSize = @ShoeSize, ShortsSize = @ShortsSize WHERE Name = @Name", con);
                con.Open();
                cmd.Parameters.AddWithValue("Name", txtName.Text);
                cmd.Parameters.AddWithValue("Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("Phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("EmergencyContactName", txtEmergencyContactName.Text);
                cmd.Parameters.AddWithValue("EmergencyContactNumber", txtEmergencyContactNumber.Text);
                cmd.Parameters.AddWithValue("TNumber", txtTNumber.Text);
                cmd.Parameters.AddWithValue("Number", txtNumber.Text);
                cmd.Parameters.AddWithValue("SchoolAddress", txtSchoolAddress.Text);
                cmd.Parameters.AddWithValue("GraduationYear", txtGraduationYear.Text);
                cmd.Parameters.AddWithValue("Height", txtHeight.Text);
                cmd.Parameters.AddWithValue("Weight", txtWeight.Text);
                cmd.Parameters.AddWithValue("Position", txtPosition.Text);
                cmd.Parameters.AddWithValue("Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("HatSize", txtHatSize.Text);
                cmd.Parameters.AddWithValue("Eligible", cmbEligible.Text);
                cmd.Parameters.AddWithValue("ShirtSize", cmbShirtSize.Text);
                cmd.Parameters.AddWithValue("ShoeSize", cmbShoeSize.Text);
                cmd.Parameters.AddWithValue("ShortsSize", cmbShortsSize.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Player updated successfully");
                con.Close();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please select player to edit.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (txtName.Text != "")
            {
                DialogResult res = MessageBox.Show("Are you sure you want to delete " + txtName.Text.ToString(), "Confirm Deletion", MessageBoxButtons.YesNo);
                if (res == DialogResult.Yes)
                {
                    cmd = new SqlCommand("DELETE FROM Player_Information_Football WHERE Name = @Name AND Address = @Address", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@Name", txtName.Text);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Player deleted successfully");
                    DisplayData();
                    ClearData();
                }

            }
            else
            {
                MessageBox.Show("Please select player to delete");
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                //gets a collection that contains all the rows
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                //populate the textbox from specific value of the coordinates of column and row.
                txtName.Text = row.Cells[0].Value.ToString();
                txtAddress.Text = row.Cells[1].Value.ToString();
                txtSchoolAddress.Text = row.Cells[2].Value.ToString();
                txtPhone.Text = row.Cells[3].Value.ToString();
                txtEmail.Text = row.Cells[4].Value.ToString();
                txtTNumber.Text = row.Cells[5].Value.ToString();
                txtGraduationYear.Text = row.Cells[6].Value.ToString();
                cmbEligible.Text = row.Cells[7].Value.ToString();
                txtNumber.Text = row.Cells[8].Value.ToString();
                txtHeight.Text = row.Cells[9].Value.ToString();
                txtWeight.Text = row.Cells[10].Value.ToString();
                txtPosition.Text = row.Cells[11].Value.ToString();
                cmbShirtSize.Text = row.Cells[12].Value.ToString();
                cmbShortsSize.Text = row.Cells[13].Value.ToString();
                txtHatSize.Text = row.Cells[14].Value.ToString();
                cmbShoeSize.Text = row.Cells[15].Value.ToString();
                txtEmergencyContactName.Text = row.Cells[16].Value.ToString();
                txtEmergencyContactNumber.Text = row.Cells[17].Value.ToString();

                txtName.ReadOnly = true;
            }

        }
        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("Select * from Player_Information_Football", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();

            txtName.ReadOnly = false;
        }
        private void ClearData()
        {
            dataGridView1.ClearSelection();

            txtName.ResetText();
            txtAddress.ResetText();
            txtSchoolAddress.ResetText();
            txtPhone.ResetText();
            txtEmail.ResetText();
            txtTNumber.ResetText();
            txtGraduationYear.ResetText();
            cmbEligible.ResetText();
            txtNumber.ResetText();
            txtHeight.ResetText();
            txtWeight.ResetText();
            txtPosition.ResetText();
            cmbShirtSize.ResetText();
            cmbShortsSize.ResetText();
            txtHatSize.ResetText();
            cmbShoeSize.ResetText();
            txtEmergencyContactName.ResetText();
            txtEmergencyContactNumber.ResetText();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            frmTeamPageBaseball FormTeamPageBaseball = new frmTeamPageBaseball();
            FormTeamPageBaseball.Show();
            this.Hide();

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to Log Out?", "Confirm", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                frmLogin FormLogin = new frmLogin();
                FormLogin.Show();
                this.Close();
            }
        }
    }
}
