﻿namespace BASportSAthletics
{
    partial class frmPlayerInfoSoccer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.playerInformationSoccerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lblPlayers = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.playerInformationSoccerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.schoolAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.graduationYearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eligibleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.heightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shirtSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shortsSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hatSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shoeSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emergencyContactNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emergencyContactNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationSoccerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationSoccerBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.schoolAddressDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.tNumberDataGridViewTextBoxColumn,
            this.graduationYearDataGridViewTextBoxColumn,
            this.eligibleDataGridViewTextBoxColumn,
            this.numberDataGridViewTextBoxColumn,
            this.heightDataGridViewTextBoxColumn,
            this.weightDataGridViewTextBoxColumn,
            this.positionDataGridViewTextBoxColumn,
            this.shirtSizeDataGridViewTextBoxColumn,
            this.shortsSizeDataGridViewTextBoxColumn,
            this.hatSizeDataGridViewTextBoxColumn,
            this.shoeSizeDataGridViewTextBoxColumn,
            this.emergencyContactNameDataGridViewTextBoxColumn,
            this.emergencyContactNumberDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.playerInformationSoccerBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(24, 106);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1732, 683);
            this.dataGridView1.TabIndex = 6;
            // 
            // playerInformationSoccerBindingSource
            // 
            this.playerInformationSoccerBindingSource.DataMember = "Player_Information_Soccer";
            // 
            // bASportSDBDataSet
            // 
           
            // 
            // lblPlayers
            // 
            this.lblPlayers.AutoSize = true;
            this.lblPlayers.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayers.Location = new System.Drawing.Point(12, 9);
            this.lblPlayers.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPlayers.Name = "lblPlayers";
            this.lblPlayers.Size = new System.Drawing.Size(229, 67);
            this.lblPlayers.TabIndex = 5;
            this.lblPlayers.Text = "Players";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(934, 831);
            this.btnBack.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(228, 91);
            this.btnBack.TabIndex = 10;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(332, 831);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(228, 91);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "Delete Player";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(638, 831);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(228, 91);
            this.btnUpdate.TabIndex = 8;
            this.btnUpdate.Text = "Update Player";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(24, 831);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(228, 91);
            this.btnAdd.TabIndex = 7;
            this.btnAdd.Text = "Add Player";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // player_Information_SoccerTableAdapter
            // 
            // 
            // playerInformationSoccerBindingSource1
            // 
            this.playerInformationSoccerBindingSource1.DataMember = "Player_Information_Soccer";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 125;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.Width = 125;
            // 
            // schoolAddressDataGridViewTextBoxColumn
            // 
            this.schoolAddressDataGridViewTextBoxColumn.DataPropertyName = "School Address";
            this.schoolAddressDataGridViewTextBoxColumn.HeaderText = "School Address";
            this.schoolAddressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.schoolAddressDataGridViewTextBoxColumn.Name = "schoolAddressDataGridViewTextBoxColumn";
            this.schoolAddressDataGridViewTextBoxColumn.Width = 125;
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            this.phoneDataGridViewTextBoxColumn.DataPropertyName = "Phone";
            this.phoneDataGridViewTextBoxColumn.HeaderText = "Phone";
            this.phoneDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            this.phoneDataGridViewTextBoxColumn.Width = 125;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.Width = 125;
            // 
            // tNumberDataGridViewTextBoxColumn
            // 
            this.tNumberDataGridViewTextBoxColumn.DataPropertyName = "T Number";
            this.tNumberDataGridViewTextBoxColumn.HeaderText = "T Number";
            this.tNumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tNumberDataGridViewTextBoxColumn.Name = "tNumberDataGridViewTextBoxColumn";
            this.tNumberDataGridViewTextBoxColumn.Width = 125;
            // 
            // graduationYearDataGridViewTextBoxColumn
            // 
            this.graduationYearDataGridViewTextBoxColumn.DataPropertyName = "Graduation Year";
            this.graduationYearDataGridViewTextBoxColumn.HeaderText = "Graduation Year";
            this.graduationYearDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.graduationYearDataGridViewTextBoxColumn.Name = "graduationYearDataGridViewTextBoxColumn";
            this.graduationYearDataGridViewTextBoxColumn.Width = 125;
            // 
            // eligibleDataGridViewTextBoxColumn
            // 
            this.eligibleDataGridViewTextBoxColumn.DataPropertyName = "Eligible";
            this.eligibleDataGridViewTextBoxColumn.HeaderText = "Eligible";
            this.eligibleDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.eligibleDataGridViewTextBoxColumn.Name = "eligibleDataGridViewTextBoxColumn";
            this.eligibleDataGridViewTextBoxColumn.Width = 125;
            // 
            // numberDataGridViewTextBoxColumn
            // 
            this.numberDataGridViewTextBoxColumn.DataPropertyName = "Number";
            this.numberDataGridViewTextBoxColumn.HeaderText = "Number";
            this.numberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numberDataGridViewTextBoxColumn.Name = "numberDataGridViewTextBoxColumn";
            this.numberDataGridViewTextBoxColumn.Width = 125;
            // 
            // heightDataGridViewTextBoxColumn
            // 
            this.heightDataGridViewTextBoxColumn.DataPropertyName = "Height";
            this.heightDataGridViewTextBoxColumn.HeaderText = "Height";
            this.heightDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.heightDataGridViewTextBoxColumn.Name = "heightDataGridViewTextBoxColumn";
            this.heightDataGridViewTextBoxColumn.Width = 125;
            // 
            // weightDataGridViewTextBoxColumn
            // 
            this.weightDataGridViewTextBoxColumn.DataPropertyName = "Weight";
            this.weightDataGridViewTextBoxColumn.HeaderText = "Weight";
            this.weightDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.weightDataGridViewTextBoxColumn.Name = "weightDataGridViewTextBoxColumn";
            this.weightDataGridViewTextBoxColumn.Width = 125;
            // 
            // positionDataGridViewTextBoxColumn
            // 
            this.positionDataGridViewTextBoxColumn.DataPropertyName = "Position";
            this.positionDataGridViewTextBoxColumn.HeaderText = "Position";
            this.positionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.positionDataGridViewTextBoxColumn.Name = "positionDataGridViewTextBoxColumn";
            this.positionDataGridViewTextBoxColumn.Width = 125;
            // 
            // shirtSizeDataGridViewTextBoxColumn
            // 
            this.shirtSizeDataGridViewTextBoxColumn.DataPropertyName = "Shirt Size";
            this.shirtSizeDataGridViewTextBoxColumn.HeaderText = "Shirt Size";
            this.shirtSizeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.shirtSizeDataGridViewTextBoxColumn.Name = "shirtSizeDataGridViewTextBoxColumn";
            this.shirtSizeDataGridViewTextBoxColumn.Width = 125;
            // 
            // shortsSizeDataGridViewTextBoxColumn
            // 
            this.shortsSizeDataGridViewTextBoxColumn.DataPropertyName = "Shorts Size";
            this.shortsSizeDataGridViewTextBoxColumn.HeaderText = "Shorts Size";
            this.shortsSizeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.shortsSizeDataGridViewTextBoxColumn.Name = "shortsSizeDataGridViewTextBoxColumn";
            this.shortsSizeDataGridViewTextBoxColumn.Width = 125;
            // 
            // hatSizeDataGridViewTextBoxColumn
            // 
            this.hatSizeDataGridViewTextBoxColumn.DataPropertyName = "Hat Size";
            this.hatSizeDataGridViewTextBoxColumn.HeaderText = "Hat Size";
            this.hatSizeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.hatSizeDataGridViewTextBoxColumn.Name = "hatSizeDataGridViewTextBoxColumn";
            this.hatSizeDataGridViewTextBoxColumn.Width = 125;
            // 
            // shoeSizeDataGridViewTextBoxColumn
            // 
            this.shoeSizeDataGridViewTextBoxColumn.DataPropertyName = "Shoe Size";
            this.shoeSizeDataGridViewTextBoxColumn.HeaderText = "Shoe Size";
            this.shoeSizeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.shoeSizeDataGridViewTextBoxColumn.Name = "shoeSizeDataGridViewTextBoxColumn";
            this.shoeSizeDataGridViewTextBoxColumn.Width = 125;
            // 
            // emergencyContactNameDataGridViewTextBoxColumn
            // 
            this.emergencyContactNameDataGridViewTextBoxColumn.DataPropertyName = "Emergency Contact Name";
            this.emergencyContactNameDataGridViewTextBoxColumn.HeaderText = "Emergency Contact Name";
            this.emergencyContactNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emergencyContactNameDataGridViewTextBoxColumn.Name = "emergencyContactNameDataGridViewTextBoxColumn";
            this.emergencyContactNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // emergencyContactNumberDataGridViewTextBoxColumn
            // 
            this.emergencyContactNumberDataGridViewTextBoxColumn.DataPropertyName = "Emergency Contact Number";
            this.emergencyContactNumberDataGridViewTextBoxColumn.HeaderText = "Emergency Contact Number";
            this.emergencyContactNumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emergencyContactNumberDataGridViewTextBoxColumn.Name = "emergencyContactNumberDataGridViewTextBoxColumn";
            this.emergencyContactNumberDataGridViewTextBoxColumn.Width = 125;
            // 
            // frmPlayerInfoSoccer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1830, 997);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblPlayers);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frmPlayerInfoSoccer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmPlayerInfoSoccer";
            this.Load += new System.EventHandler(this.frmPlayerInfoSoccer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationSoccerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationSoccerBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblPlayers;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.BindingSource playerInformationSoccerBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn scholarshipAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn schoolAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn graduationYearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eligibleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn heightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shirtSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortsSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hatSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shoeSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emergencyContactNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emergencyContactNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource playerInformationSoccerBindingSource1;
    }
}