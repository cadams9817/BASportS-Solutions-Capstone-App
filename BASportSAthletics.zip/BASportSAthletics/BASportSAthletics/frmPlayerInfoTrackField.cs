﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmPlayerInfoTrackField : Form
    {
        public frmPlayerInfoTrackField()
        {
            InitializeComponent();
        }

        private void frmPlayerInfoTrackField_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSetUpdated.Player_Information_TrackField' table. You can move, or remove it, as needed.

        }
    }
}
