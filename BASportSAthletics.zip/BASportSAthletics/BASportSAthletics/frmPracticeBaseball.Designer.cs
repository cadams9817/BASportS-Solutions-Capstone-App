﻿namespace BASportSAthletics
{
    partial class frmPracticeBaseball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPracticeBaseball));
            this.lblPracticeHours = new System.Windows.Forms.Label();
            this.dgvPracticeInfo = new System.Windows.Forms.DataGridView();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.practiceBaseballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bASportSDBDataSet = new BASportSAthletics.BASportSDBDataSet();
            this.label2 = new System.Windows.Forms.Label();
            this.practice_BaseballTableAdapter = new BASportSAthletics.BASportSDBDataSetTableAdapters.Practice_BaseballTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.txtHours = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPracticeInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceBaseballBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPracticeHours
            // 
            this.lblPracticeHours.AutoSize = true;
            this.lblPracticeHours.BackColor = System.Drawing.Color.Transparent;
            this.lblPracticeHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPracticeHours.ForeColor = System.Drawing.Color.White;
            this.lblPracticeHours.Location = new System.Drawing.Point(13, 13);
            this.lblPracticeHours.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPracticeHours.Name = "lblPracticeHours";
            this.lblPracticeHours.Size = new System.Drawing.Size(224, 36);
            this.lblPracticeHours.TabIndex = 21;
            this.lblPracticeHours.Text = "Practice Hours";
            // 
            // dgvPracticeInfo
            // 
            this.dgvPracticeInfo.AllowUserToAddRows = false;
            this.dgvPracticeInfo.AllowUserToDeleteRows = false;
            this.dgvPracticeInfo.BackgroundColor = System.Drawing.Color.White;
            this.dgvPracticeInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPracticeInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvPracticeInfo.Location = new System.Drawing.Point(13, 188);
            this.dgvPracticeInfo.Margin = new System.Windows.Forms.Padding(4);
            this.dgvPracticeInfo.Name = "dgvPracticeInfo";
            this.dgvPracticeInfo.ReadOnly = true;
            this.dgvPracticeInfo.RowHeadersWidth = 51;
            this.dgvPracticeInfo.Size = new System.Drawing.Size(611, 538);
            this.dgvPracticeInfo.TabIndex = 16;
            this.dgvPracticeInfo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPracticeInfo_CellClick);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnReturn.Location = new System.Drawing.Point(669, 18);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(152, 38);
            this.btnReturn.TabIndex = 28;
            this.btnReturn.Text = "Back";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClear.BackgroundImage")));
            this.btnClear.Location = new System.Drawing.Point(669, 474);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(152, 58);
            this.btnClear.TabIndex = 27;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(637, 131);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(356, 36);
            this.label1.TabIndex = 26;
            this.label1.Text = "Add/Edit Practice Hours";
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDelete.BackgroundImage")));
            this.btnDelete.Location = new System.Drawing.Point(841, 474);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(152, 58);
            this.btnDelete.TabIndex = 24;
            this.btnDelete.Text = "Delete Practice";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEdit.BackgroundImage")));
            this.btnEdit.Location = new System.Drawing.Point(841, 379);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(152, 58);
            this.btnEdit.TabIndex = 23;
            this.btnEdit.Text = "Edit Practice";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.Location = new System.Drawing.Point(669, 379);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(152, 58);
            this.btnAdd.TabIndex = 22;
            this.btnAdd.Text = "Add Practice";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Transparent;
            this.btnLogout.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnLogout.Location = new System.Drawing.Point(841, 18);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(152, 38);
            this.btnLogout.TabIndex = 29;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.practiceBaseballBindingSource;
            this.comboBox1.DisplayMember = "Date";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(103, 135);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(151, 24);
            this.comboBox1.TabIndex = 31;
            this.comboBox1.ValueMember = "Date";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // practiceBaseballBindingSource
            // 
            this.practiceBaseballBindingSource.DataMember = "Practice_Baseball";
            this.practiceBaseballBindingSource.DataSource = this.bASportSDBDataSet;
            // 
            // bASportSDBDataSet
            // 
            this.bASportSDBDataSet.DataSetName = "BASportSDBDataSet";
            this.bASportSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 17);
            this.label2.TabIndex = 30;
            this.label2.Text = "Select Date:";
            // 
            // practice_BaseballTableAdapter
            // 
            this.practice_BaseballTableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(738, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 32;
            this.label3.Text = "Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(728, 247);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 33;
            this.label4.Text = "Hours:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(710, 313);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 20);
            this.label5.TabIndex = 34;
            this.label5.Text = "Location:";
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(794, 185);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(199, 22);
            this.txtDate.TabIndex = 35;
            // 
            // txtLocation
            // 
            this.txtLocation.Location = new System.Drawing.Point(794, 313);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(199, 22);
            this.txtLocation.TabIndex = 36;
            // 
            // txtHours
            // 
            this.txtHours.Location = new System.Drawing.Point(794, 247);
            this.txtHours.Name = "txtHours";
            this.txtHours.Size = new System.Drawing.Size(199, 22);
            this.txtHours.TabIndex = 37;
            // 
            // frmPracticeBaseball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.ClientSize = new System.Drawing.Size(1015, 745);
            this.Controls.Add(this.txtHours);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblPracticeHours);
            this.Controls.Add(this.dgvPracticeInfo);
            this.Name = "frmPracticeBaseball";
            this.Text = "frmPracticeBaseball";
            this.Load += new System.EventHandler(this.frmPracticeBaseball_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPracticeInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceBaseballBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPracticeHours;
        private System.Windows.Forms.DataGridView dgvPracticeInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hoursDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private BASportSDBDataSet bASportSDBDataSet;
        private System.Windows.Forms.BindingSource practiceBaseballBindingSource;
        private BASportSDBDataSetTableAdapters.Practice_BaseballTableAdapter practice_BaseballTableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.TextBox txtHours;
    }
}