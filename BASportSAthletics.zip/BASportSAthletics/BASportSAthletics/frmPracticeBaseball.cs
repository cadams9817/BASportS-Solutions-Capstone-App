﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Security;

namespace BASportSAthletics
{
    public partial class frmPracticeBaseball : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;" +
                "AttachDbFilename=|DataDirectory|\\BASportSDB.mdf;" +
                  "Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapt;

        public frmPracticeBaseball()
        {
            InitializeComponent();
            DisplayData();
        }

        private void frmPracticeBaseball_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Practice_Baseball' table. You can move, or remove it, as needed.
            this.practice_BaseballTableAdapter.Fill(this.bASportSDBDataSet.Practice_Baseball);

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            {
                frmTeamInfoBaseball FormTeamInfoBaseball = new frmTeamInfoBaseball();
                FormTeamInfoBaseball.Show();
                this.Hide();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to Log Out?", "Confirm", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                frmLogin FormLogin = new frmLogin();
                FormLogin.Show();
                this.Close();
            }
        }

        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("Select * from Practice_Baseball", con);
            adapt.Fill(dt);
            dgvPracticeInfo.DataSource = dt;
            con.Close();
        }

        private void DisplayDate()
        {
            con.Open();
            DataTable da = new DataTable();
            adapt = new SqlDataAdapter("Select Date from Practice_Baseball", con);
            adapt.Fill(da);
            comboBox1.DataSource = da;
            con.Close();
        }

        private void ClearData()
        {
            dgvPracticeInfo.ClearSelection();

            txtDate.ResetText();
            txtHours.ResetText();
            txtLocation.ResetText();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtDate.Text != "" && txtHours.Text != "" && txtLocation.Text != "")
            {
                cmd = new SqlCommand("INSERT INTO Practice_Baseball " +
                "(Date, Hours, Location) " +
                "VALUES (@Date, @Hours, @Location)", con);
                con.Open();
                cmd.Parameters.AddWithValue("Date", txtDate.Text);
                cmd.Parameters.AddWithValue("Hours", txtHours.Text);
                cmd.Parameters.AddWithValue("Location", txtLocation.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Practice added successfully");
                DisplayData();
                ClearData();
                DisplayDate();
            }
            else
            {
                MessageBox.Show("Please fill in all fields");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtDate.Text != "" && txtHours.Text != "" && txtLocation.Text != "")
            {
                cmd = new SqlCommand("UPDATE Practice_Baseball SET Date = @Date, Hours = @Hours, Location = @Location WHERE Date = @Date", con);
                con.Open();
                cmd.Parameters.AddWithValue("Date", txtDate.Text);
                cmd.Parameters.AddWithValue("Hours", txtHours.Text);
                cmd.Parameters.AddWithValue("Location", txtLocation.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Practice updated successfully");
                con.Close();
                DisplayData();
                ClearData();
                DisplayDate();
            }
            else
            {
                MessageBox.Show("Please select practice to edit.");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure you want to delete this practice entry?", "Confirm Deletion", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                cmd = new SqlCommand("DELETE FROM Practice_Baseball WHERE Date = @Date AND Hours = @Hours AND Location = @Location", con);
                con.Open();
                cmd.Parameters.AddWithValue("Date", txtDate.Text);
                cmd.Parameters.AddWithValue("Hours", txtHours.Text);
                cmd.Parameters.AddWithValue("Location", txtLocation.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Practice deleted successfully");
                DisplayData();
                ClearData();
                DisplayDate();
            }
            else
            {
                MessageBox.Show("Please select practice to delete");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT Date, Hours, Location FROM Practice_Baseball WHERE Date like '" + comboBox1.Text + "%'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvPracticeInfo.DataSource = dt;
        }

        private void dgvPracticeInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                //gets a collection that contains all the rows
                DataGridViewRow row = this.dgvPracticeInfo.Rows[e.RowIndex];
                //populate the textbox from specific value of the coordinates of column and row.
                txtDate.Text = row.Cells[0].Value.ToString();
                txtHours.Text = row.Cells[1].Value.ToString();
                txtLocation.Text = row.Cells[2].Value.ToString();
            }
        }
    }
}
