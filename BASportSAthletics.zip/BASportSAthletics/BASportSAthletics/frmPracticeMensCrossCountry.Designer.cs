﻿namespace BASportSAthletics
{
    partial class frmPracticeMensCrossCountry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPracticeHours = new System.Windows.Forms.Label();
            this.cmbChooseDate = new System.Windows.Forms.ComboBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAddDelete = new System.Windows.Forms.Button();
            this.dgvPracticeInfo = new System.Windows.Forms.DataGridView();
            this.lblChooseDate = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPracticeInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPracticeHours
            // 
            this.lblPracticeHours.AutoSize = true;
            this.lblPracticeHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPracticeHours.Location = new System.Drawing.Point(6, 12);
            this.lblPracticeHours.Name = "lblPracticeHours";
            this.lblPracticeHours.Size = new System.Drawing.Size(221, 33);
            this.lblPracticeHours.TabIndex = 14;
            this.lblPracticeHours.Text = "Practice Hours";
            // 
            // cmbChooseDate
            // 
            this.cmbChooseDate.FormattingEnabled = true;
            this.cmbChooseDate.Location = new System.Drawing.Point(144, 76);
            this.cmbChooseDate.Name = "cmbChooseDate";
            this.cmbChooseDate.Size = new System.Drawing.Size(158, 21);
            this.cmbChooseDate.TabIndex = 13;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(241, 377);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(99, 40);
            this.btnBack.TabIndex = 12;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(127, 377);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(99, 40);
            this.btnUpdate.TabIndex = 11;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnAddDelete
            // 
            this.btnAddDelete.Location = new System.Drawing.Point(12, 377);
            this.btnAddDelete.Name = "btnAddDelete";
            this.btnAddDelete.Size = new System.Drawing.Size(99, 40);
            this.btnAddDelete.TabIndex = 10;
            this.btnAddDelete.Text = "Add/Delete";
            this.btnAddDelete.UseVisualStyleBackColor = true;
            // 
            // dgvPracticeInfo
            // 
            this.dgvPracticeInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPracticeInfo.Location = new System.Drawing.Point(12, 120);
            this.dgvPracticeInfo.Name = "dgvPracticeInfo";
            this.dgvPracticeInfo.Size = new System.Drawing.Size(580, 238);
            this.dgvPracticeInfo.TabIndex = 9;
            // 
            // lblChooseDate
            // 
            this.lblChooseDate.AutoSize = true;
            this.lblChooseDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChooseDate.Location = new System.Drawing.Point(8, 73);
            this.lblChooseDate.Name = "lblChooseDate";
            this.lblChooseDate.Size = new System.Drawing.Size(130, 24);
            this.lblChooseDate.TabIndex = 8;
            this.lblChooseDate.Text = "ChooseDate:";
            // 
            // frmPracticeMensCrossCountry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 450);
            this.Controls.Add(this.lblPracticeHours);
            this.Controls.Add(this.cmbChooseDate);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAddDelete);
            this.Controls.Add(this.dgvPracticeInfo);
            this.Controls.Add(this.lblChooseDate);
            this.Name = "frmPracticeMensCrossCountry";
            this.Text = "frmPracticeMensCrossCountry";
            ((System.ComponentModel.ISupportInitialize)(this.dgvPracticeInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPracticeHours;
        private System.Windows.Forms.ComboBox cmbChooseDate;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAddDelete;
        private System.Windows.Forms.DataGridView dgvPracticeInfo;
        private System.Windows.Forms.Label lblChooseDate;
    }
}