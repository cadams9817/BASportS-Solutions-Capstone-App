﻿namespace BASportSAthletics
{
    partial class frmScholarshipBaseball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmScholarshipBaseball));
            this.lblScholarshipInfo = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scholarshipAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GraduationYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerInformationBaseballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bASportSDBDataSet = new BASportSAthletics.BASportSDBDataSet();
            this.grpBoxScholarship = new System.Windows.Forms.GroupBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtScholarshipAmount = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.lblScholarshipAmount = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnConfirmUpdate = new System.Windows.Forms.Button();
            this.player_Information_BaseballTableAdapter = new BASportSAthletics.BASportSDBDataSetTableAdapters.Player_Information_BaseballTableAdapter();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationBaseballBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).BeginInit();
            this.grpBoxScholarship.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblScholarshipInfo
            // 
            this.lblScholarshipInfo.AutoSize = true;
            this.lblScholarshipInfo.BackColor = System.Drawing.Color.Transparent;
            this.lblScholarshipInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScholarshipInfo.ForeColor = System.Drawing.Color.White;
            this.lblScholarshipInfo.Location = new System.Drawing.Point(9, 14);
            this.lblScholarshipInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblScholarshipInfo.Name = "lblScholarshipInfo";
            this.lblScholarshipInfo.Size = new System.Drawing.Size(278, 39);
            this.lblScholarshipInfo.TabIndex = 0;
            this.lblScholarshipInfo.Text = "Scholarship Info";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.scholarshipAmountDataGridViewTextBoxColumn,
            this.GraduationYear});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView1.DataSource = this.playerInformationBaseballBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(17, 58);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.Size = new System.Drawing.Size(588, 527);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 74;
            // 
            // scholarshipAmountDataGridViewTextBoxColumn
            // 
            this.scholarshipAmountDataGridViewTextBoxColumn.DataPropertyName = "ScholarshipAmount";
            this.scholarshipAmountDataGridViewTextBoxColumn.HeaderText = "Scholarship Amount";
            this.scholarshipAmountDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.scholarshipAmountDataGridViewTextBoxColumn.Name = "scholarshipAmountDataGridViewTextBoxColumn";
            this.scholarshipAmountDataGridViewTextBoxColumn.ReadOnly = true;
            this.scholarshipAmountDataGridViewTextBoxColumn.Width = 149;
            // 
            // GraduationYear
            // 
            this.GraduationYear.DataPropertyName = "GraduationYear";
            this.GraduationYear.HeaderText = "Graduation Year";
            this.GraduationYear.MinimumWidth = 10;
            this.GraduationYear.Name = "GraduationYear";
            this.GraduationYear.ReadOnly = true;
            this.GraduationYear.Width = 130;
            // 
            // playerInformationBaseballBindingSource
            // 
            this.playerInformationBaseballBindingSource.DataMember = "Player_Information_Baseball";
            this.playerInformationBaseballBindingSource.DataSource = this.bASportSDBDataSet;
            // 
            // bASportSDBDataSet
            // 
            this.bASportSDBDataSet.DataSetName = "BASportSDBDataSet";
            this.bASportSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // grpBoxScholarship
            // 
            this.grpBoxScholarship.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.grpBoxScholarship.Controls.Add(this.txtName);
            this.grpBoxScholarship.Controls.Add(this.txtScholarshipAmount);
            this.grpBoxScholarship.Controls.Add(this.txtYear);
            this.grpBoxScholarship.Controls.Add(this.lblScholarshipAmount);
            this.grpBoxScholarship.Controls.Add(this.lblYear);
            this.grpBoxScholarship.Controls.Add(this.lblName);
            this.grpBoxScholarship.Location = new System.Drawing.Point(624, 57);
            this.grpBoxScholarship.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpBoxScholarship.Name = "grpBoxScholarship";
            this.grpBoxScholarship.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpBoxScholarship.Size = new System.Drawing.Size(399, 527);
            this.grpBoxScholarship.TabIndex = 18;
            this.grpBoxScholarship.TabStop = false;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(165, 104);
            this.txtName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(217, 22);
            this.txtName.TabIndex = 12;
            // 
            // txtScholarshipAmount
            // 
            this.txtScholarshipAmount.Location = new System.Drawing.Point(165, 217);
            this.txtScholarshipAmount.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtScholarshipAmount.Name = "txtScholarshipAmount";
            this.txtScholarshipAmount.Size = new System.Drawing.Size(217, 22);
            this.txtScholarshipAmount.TabIndex = 11;
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(165, 161);
            this.txtYear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(217, 22);
            this.txtYear.TabIndex = 10;
            // 
            // lblScholarshipAmount
            // 
            this.lblScholarshipAmount.AutoSize = true;
            this.lblScholarshipAmount.BackColor = System.Drawing.Color.Transparent;
            this.lblScholarshipAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScholarshipAmount.ForeColor = System.Drawing.Color.White;
            this.lblScholarshipAmount.Location = new System.Drawing.Point(17, 217);
            this.lblScholarshipAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblScholarshipAmount.Name = "lblScholarshipAmount";
            this.lblScholarshipAmount.Size = new System.Drawing.Size(138, 17);
            this.lblScholarshipAmount.TabIndex = 9;
            this.lblScholarshipAmount.Text = "Scholarship Amount:";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.BackColor = System.Drawing.Color.Transparent;
            this.lblYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYear.ForeColor = System.Drawing.Color.White;
            this.lblYear.Location = new System.Drawing.Point(40, 164);
            this.lblYear.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(117, 17);
            this.lblYear.TabIndex = 8;
            this.lblYear.Text = "Graduation Year:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.White;
            this.lblName.Location = new System.Drawing.Point(108, 104);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(49, 17);
            this.lblName.TabIndex = 7;
            this.lblName.Text = "Name:";
            // 
            // btnClear
            // 
            this.btnClear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClear.BackgroundImage")));
            this.btnClear.Location = new System.Drawing.Point(875, 590);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(148, 48);
            this.btnClear.TabIndex = 14;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // btnConfirmUpdate
            // 
            this.btnConfirmUpdate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConfirmUpdate.BackgroundImage")));
            this.btnConfirmUpdate.Location = new System.Drawing.Point(719, 590);
            this.btnConfirmUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnConfirmUpdate.Name = "btnConfirmUpdate";
            this.btnConfirmUpdate.Size = new System.Drawing.Size(148, 48);
            this.btnConfirmUpdate.TabIndex = 13;
            this.btnConfirmUpdate.Text = "Confirm Scholarship Update";
            this.btnConfirmUpdate.UseVisualStyleBackColor = true;
            this.btnConfirmUpdate.Click += new System.EventHandler(this.btnConfirmUpdate_Click);
            // 
            // player_Information_BaseballTableAdapter
            // 
            this.player_Information_BaseballTableAdapter.ClearBeforeFill = true;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Transparent;
            this.btnLogout.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnLogout.Location = new System.Drawing.Point(871, 14);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(152, 38);
            this.btnLogout.TabIndex = 23;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnReturn.Location = new System.Drawing.Point(715, 14);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(152, 38);
            this.btnReturn.TabIndex = 24;
            this.btnReturn.Text = "Back";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // frmScholarshipBaseball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.ClientSize = new System.Drawing.Size(1036, 662);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.grpBoxScholarship);
            this.Controls.Add(this.btnConfirmUpdate);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblScholarshipInfo);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmScholarshipBaseball";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmScholarshipBaseball";
            this.Load += new System.EventHandler(this.frmScholarshipBaseball_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationBaseballBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).EndInit();
            this.grpBoxScholarship.ResumeLayout(false);
            this.grpBoxScholarship.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblScholarshipInfo;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox grpBoxScholarship;
        private System.Windows.Forms.TextBox txtScholarshipAmount;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.Label lblScholarshipAmount;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnConfirmUpdate;
        private System.Windows.Forms.TextBox txtName;
        private BASportSDBDataSet bASportSDBDataSet;
        private System.Windows.Forms.BindingSource playerInformationBaseballBindingSource;
        private BASportSDBDataSetTableAdapters.Player_Information_BaseballTableAdapter player_Information_BaseballTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn scholarshipAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn GraduationYear;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnReturn;
    }
}