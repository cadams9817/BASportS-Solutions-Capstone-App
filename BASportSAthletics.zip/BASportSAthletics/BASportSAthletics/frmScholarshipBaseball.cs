﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security;

namespace BASportSAthletics
{
    public partial class frmScholarshipBaseball : Form
    {

        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;" +
                "AttachDbFilename=|DataDirectory|\\BASportSDB.mdf;" +
                  "Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter adapt;


        public frmScholarshipBaseball()
        {
            InitializeComponent();
            DisplayData();
        }

        private void frmScholarshipBaseball_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Player_Information_Baseball' table. You can move, or remove it, as needed.
            this.player_Information_BaseballTableAdapter.Fill(this.bASportSDBDataSet.Player_Information_Baseball);
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Player_Information_Baseball' table. You can move, or remove it, as needed.
            this.player_Information_BaseballTableAdapter.Fill(this.bASportSDBDataSet.Player_Information_Baseball);


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //gets a collection that contains all the rows
            DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

            //populate the textbox from specific value of the coordinates of column and row.
            txtName.Text = row.Cells[0].Value.ToString();
            txtScholarshipAmount.Text = row.Cells[1].Value.ToString();
            txtYear.Text = row.Cells[2].Value.ToString();

        }

        private void btnConfirmUpdate_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "")
            {
                cmd = new SqlCommand("UPDATE Player_Information_Baseball SET ScholarshipAmount = @ScholarshipAmount, GraduationYear = @GraduationYear WHERE Name = @Name", con);
                con.Open();
                cmd.Parameters.AddWithValue("Name", txtName.Text);
                cmd.Parameters.AddWithValue("ScholarshipAmount", txtScholarshipAmount.Text);
                cmd.Parameters.AddWithValue("GraduationYear", txtYear.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Scholarship information updated successfully");
                con.Close();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please select player to edit.");
            }
        }

        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("Select * from Player_Information_Baseball", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void ClearData()
        {
            dataGridView1.ClearSelection();

            txtName.ResetText();
            txtScholarshipAmount.ResetText();
            txtYear.ResetText();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to Log Out?", "Confirm", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                frmLogin FormLogin = new frmLogin();
                FormLogin.Show();
                this.Close();
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            frmTeamPageBaseball FormTeamBaseball = new frmTeamPageBaseball();
            FormTeamBaseball.Show();
            this.Close();
        }
    }
}
