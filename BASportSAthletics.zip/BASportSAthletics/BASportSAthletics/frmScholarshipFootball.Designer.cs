﻿namespace BASportSAthletics
{
    partial class frmScholarshipFootball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblScholarshipInfo = new System.Windows.Forms.Label();
            this.lblToolTip = new System.Windows.Forms.Label();
            this.playerInformationFootballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scholarshipAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationFootballBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(72, 1062);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(206, 79);
            this.btnUpdate.TabIndex = 21;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(332, 1062);
            this.btnBack.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(206, 79);
            this.btnBack.TabIndex = 20;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.scholarshipAmountDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.playerInformationFootballBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(68, 181);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.Size = new System.Drawing.Size(1204, 823);
            this.dataGridView1.TabIndex = 18;
            // 
            // lblScholarshipInfo
            // 
            this.lblScholarshipInfo.AutoSize = true;
            this.lblScholarshipInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScholarshipInfo.Location = new System.Drawing.Point(56, 71);
            this.lblScholarshipInfo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblScholarshipInfo.Name = "lblScholarshipInfo";
            this.lblScholarshipInfo.Size = new System.Drawing.Size(431, 63);
            this.lblScholarshipInfo.TabIndex = 17;
            this.lblScholarshipInfo.Text = "Scholarship Info";
            // 
            // lblToolTip
            // 
            this.lblToolTip.AutoSize = true;
            this.lblToolTip.Location = new System.Drawing.Point(66, 1190);
            this.lblToolTip.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblToolTip.Name = "lblToolTip";
            this.lblToolTip.Size = new System.Drawing.Size(1218, 25);
            this.lblToolTip.TabIndex = 22;
            this.lblToolTip.Text = "To Add or Delete a players scholarship information go to the Player Information p" +
    "age and either click on Add/Delete or Update.";
            // 
            // bASportSDBDataSetUpdated
            // 
            // playerInformationFootballBindingSource
            // 
            this.playerInformationFootballBindingSource.DataMember = "Player_Information_Football";
            // 
            // player_Information_FootballTableAdapter
            // 
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 200;
            // 
            // scholarshipAmountDataGridViewTextBoxColumn
            // 
            this.scholarshipAmountDataGridViewTextBoxColumn.DataPropertyName = "Scholarship Amount";
            this.scholarshipAmountDataGridViewTextBoxColumn.HeaderText = "Scholarship Amount";
            this.scholarshipAmountDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.scholarshipAmountDataGridViewTextBoxColumn.Name = "scholarshipAmountDataGridViewTextBoxColumn";
            this.scholarshipAmountDataGridViewTextBoxColumn.Width = 200;
            // 
            // frmScholarshipFootball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 1233);
            this.Controls.Add(this.lblToolTip);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblScholarshipInfo);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frmScholarshipFootball";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmScholarshipFootball";
            this.Load += new System.EventHandler(this.frmScholarshipFootball_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationFootballBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblScholarshipInfo;
        private System.Windows.Forms.Label lblToolTip;
        private System.Windows.Forms.BindingSource playerInformationFootballBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn scholarshipAmountDataGridViewTextBoxColumn;
    }
}