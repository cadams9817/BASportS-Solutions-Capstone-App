﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmScholarshipMensCrossCountry : Form
    {
        public frmScholarshipMensCrossCountry()
        {
            InitializeComponent();
        }

        private void frmScholarshipMensCrossCountry_Load(object sender, EventArgs e)
        {
          

        }
    }
}
