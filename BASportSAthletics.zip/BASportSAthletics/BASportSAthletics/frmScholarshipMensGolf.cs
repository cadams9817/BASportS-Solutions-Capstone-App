﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmScholarshipMensGolf : Form
    {
        public frmScholarshipMensGolf()
        {
            InitializeComponent();
        }

        private void frmScholarshipMensGolf_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSetUpdated._Player_Information_Men_s_Golf' table. You can move, or remove it, as needed.

        }
    }
}
