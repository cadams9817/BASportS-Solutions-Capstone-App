﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmScholarshipTennis : Form
    {
        public frmScholarshipTennis()
        {
            InitializeComponent();
        }

        private void frmScholarshipTennis_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSetUpdated.Player_Information_Tennis' table. You can move, or remove it, as needed.

        }
    }
}
