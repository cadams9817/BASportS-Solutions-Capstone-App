﻿namespace BASportSAthletics
{
    partial class frmTeamInfoBaseball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblList = new System.Windows.Forms.Label();
            this.dgvTeamInfo = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerInformationBaseballBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bASportSDBDataSet = new BASportSAthletics.BASportSDBDataSet();
            this.playerInformationBaseballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnPracticeHours = new System.Windows.Forms.Button();
            this.btnBudget = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.player_Information_BaseballTableAdapter = new BASportSAthletics.BASportSDBDataSetTableAdapters.Player_Information_BaseballTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeamInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationBaseballBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationBaseballBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lblList
            // 
            this.lblList.AutoSize = true;
            this.lblList.BackColor = System.Drawing.Color.Transparent;
            this.lblList.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblList.ForeColor = System.Drawing.Color.White;
            this.lblList.Location = new System.Drawing.Point(16, 23);
            this.lblList.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblList.Name = "lblList";
            this.lblList.Size = new System.Drawing.Size(267, 42);
            this.lblList.TabIndex = 0;
            this.lblList.Text = "List of Players";
            // 
            // dgvTeamInfo
            // 
            this.dgvTeamInfo.AutoGenerateColumns = false;
            this.dgvTeamInfo.BackgroundColor = System.Drawing.Color.White;
            this.dgvTeamInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTeamInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.dgvTeamInfo.DataSource = this.playerInformationBaseballBindingSource1;
            this.dgvTeamInfo.Location = new System.Drawing.Point(24, 98);
            this.dgvTeamInfo.Margin = new System.Windows.Forms.Padding(4);
            this.dgvTeamInfo.Name = "dgvTeamInfo";
            this.dgvTeamInfo.RowHeadersWidth = 82;
            this.dgvTeamInfo.Size = new System.Drawing.Size(768, 270);
            this.dgvTeamInfo.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn1.HeaderText = "Name";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "GraduationYear";
            this.dataGridViewTextBoxColumn2.HeaderText = "GraduationYear";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Number";
            this.dataGridViewTextBoxColumn3.HeaderText = "Number";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Height";
            this.dataGridViewTextBoxColumn4.HeaderText = "Height";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Weight";
            this.dataGridViewTextBoxColumn5.HeaderText = "Weight";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Position";
            this.dataGridViewTextBoxColumn6.HeaderText = "Position";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Eligible";
            this.dataGridViewTextBoxColumn7.HeaderText = "Eligible";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // playerInformationBaseballBindingSource1
            // 
            this.playerInformationBaseballBindingSource1.DataMember = "Player_Information_Baseball";
            this.playerInformationBaseballBindingSource1.DataSource = this.bASportSDBDataSet;
            // 
            // bASportSDBDataSet
            // 
            this.bASportSDBDataSet.DataSetName = "BASportSDBDataSet";
            this.bASportSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // playerInformationBaseballBindingSource
            // 
            this.playerInformationBaseballBindingSource.DataMember = "Player_Information_Baseball";
            // 
            // btnPracticeHours
            // 
            this.btnPracticeHours.BackgroundImage = global::BASportSAthletics.Properties.Resources.yellow_background;
            this.btnPracticeHours.Location = new System.Drawing.Point(199, 404);
            this.btnPracticeHours.Margin = new System.Windows.Forms.Padding(4);
            this.btnPracticeHours.Name = "btnPracticeHours";
            this.btnPracticeHours.Size = new System.Drawing.Size(137, 50);
            this.btnPracticeHours.TabIndex = 2;
            this.btnPracticeHours.Text = "Practice Hours";
            this.btnPracticeHours.UseVisualStyleBackColor = true;
            this.btnPracticeHours.Click += new System.EventHandler(this.btnPracticeHours_Click);
            // 
            // btnBudget
            // 
            this.btnBudget.BackgroundImage = global::BASportSAthletics.Properties.Resources.yellow_background;
            this.btnBudget.Location = new System.Drawing.Point(24, 404);
            this.btnBudget.Margin = new System.Windows.Forms.Padding(4);
            this.btnBudget.Name = "btnBudget";
            this.btnBudget.Size = new System.Drawing.Size(137, 50);
            this.btnBudget.TabIndex = 3;
            this.btnBudget.Text = "Budget";
            this.btnBudget.UseVisualStyleBackColor = true;
            this.btnBudget.Click += new System.EventHandler(this.btnBudget_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnBack.Location = new System.Drawing.Point(505, 31);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(131, 40);
            this.btnBack.TabIndex = 4;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackgroundImage = global::BASportSAthletics.Properties.Resources.teal_background;
            this.btnLogout.Location = new System.Drawing.Point(661, 31);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(131, 41);
            this.btnLogout.TabIndex = 5;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // player_Information_BaseballTableAdapter
            // 
            this.player_Information_BaseballTableAdapter.ClearBeforeFill = true;
            // 
            // frmTeamInfoBaseball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BASportSAthletics.Properties.Resources.purple_background;
            this.ClientSize = new System.Drawing.Size(828, 485);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnBudget);
            this.Controls.Add(this.btnPracticeHours);
            this.Controls.Add(this.dgvTeamInfo);
            this.Controls.Add(this.lblList);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmTeamInfoBaseball";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTeamInfoBaseball";
            this.Load += new System.EventHandler(this.frmTeamInfoBaseball_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeamInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationBaseballBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bASportSDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationBaseballBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblList;
        private System.Windows.Forms.DataGridView dgvTeamInfo;
        private System.Windows.Forms.Button btnPracticeHours;
        private System.Windows.Forms.Button btnBudget;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.BindingSource playerInformationBaseballBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn graduationYearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn heightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eligibleDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnLogout;
        private BASportSDBDataSet bASportSDBDataSet;
        private System.Windows.Forms.BindingSource playerInformationBaseballBindingSource1;
        private BASportSDBDataSetTableAdapters.Player_Information_BaseballTableAdapter player_Information_BaseballTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}