﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Security;

namespace BASportSAthletics
{
    public partial class frmTeamInfoBaseball : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;" +
                "AttachDbFilename=|DataDirectory|\\BASportSDB.mdf;" +
                  "Integrated Security=True");
        SqlDataAdapter adapt;

        public frmTeamInfoBaseball()
        {
            InitializeComponent();
            DisplayData();
        }

        private void btnBudget_Click(object sender, EventArgs e)
        {
            frmBudgetBaseball FormBudgetBaseball = new frmBudgetBaseball();
            FormBudgetBaseball.Show();
            this.Close();
        }

        private void btnPracticeHours_Click(object sender, EventArgs e)
        {
            frmPracticeBaseball FormPracticeBaseball = new frmPracticeBaseball();
            FormPracticeBaseball.Show();
            this.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmTeamPageBaseball FormTeamPageBaseball = new frmTeamPageBaseball();
            FormTeamPageBaseball.Show();
            this.Close();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to Log Out?", "Confirm", MessageBoxButtons.YesNo);
            if(dialogResult == DialogResult.Yes)
            {
                frmLogin FormLogin = new frmLogin();
                FormLogin.Show();
                this.Close();
            }
        }

        private void frmTeamInfoBaseball_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSet.Player_Information_Baseball' table. You can move, or remove it, as needed.
            this.player_Information_BaseballTableAdapter.Fill(this.bASportSDBDataSet.Player_Information_Baseball);

        }

        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("Select Name, GraduationYear, Number, Height, Weight, Position, Eligible from Player_Information_Baseball", con);
            adapt.Fill(dt);
            dgvTeamInfo.DataSource = dt;
            con.Close();
        }
    }
}
