﻿namespace BASportSAthletics
{
    partial class frmTeamInfoFootball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnBudget = new System.Windows.Forms.Button();
            this.btnPracticeHours = new System.Windows.Forms.Button();
            this.dgvTeamInfo = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.graduationYearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.heightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eligibleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerInformationFootballBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lblList = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeamInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationFootballBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(274, 328);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(103, 41);
            this.btnBack.TabIndex = 9;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // btnBudget
            // 
            this.btnBudget.Location = new System.Drawing.Point(18, 328);
            this.btnBudget.Name = "btnBudget";
            this.btnBudget.Size = new System.Drawing.Size(103, 41);
            this.btnBudget.TabIndex = 8;
            this.btnBudget.Text = "Budget";
            this.btnBudget.UseVisualStyleBackColor = true;
            this.btnBudget.Click += new System.EventHandler(this.btnBudget_Click);
            // 
            // btnPracticeHours
            // 
            this.btnPracticeHours.Location = new System.Drawing.Point(149, 328);
            this.btnPracticeHours.Name = "btnPracticeHours";
            this.btnPracticeHours.Size = new System.Drawing.Size(103, 41);
            this.btnPracticeHours.TabIndex = 7;
            this.btnPracticeHours.Text = "Practice Hours";
            this.btnPracticeHours.UseVisualStyleBackColor = true;
            this.btnPracticeHours.Click += new System.EventHandler(this.btnPracticeHours_Click);
            // 
            // dgvTeamInfo
            // 
            this.dgvTeamInfo.AutoGenerateColumns = false;
            this.dgvTeamInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTeamInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.graduationYearDataGridViewTextBoxColumn,
            this.numberDataGridViewTextBoxColumn,
            this.heightDataGridViewTextBoxColumn,
            this.weightDataGridViewTextBoxColumn,
            this.positionDataGridViewTextBoxColumn,
            this.eligibleDataGridViewTextBoxColumn});
            this.dgvTeamInfo.DataSource = this.playerInformationFootballBindingSource;
            this.dgvTeamInfo.Location = new System.Drawing.Point(18, 78);
            this.dgvTeamInfo.Name = "dgvTeamInfo";
            this.dgvTeamInfo.RowHeadersWidth = 82;
            this.dgvTeamInfo.Size = new System.Drawing.Size(576, 219);
            this.dgvTeamInfo.TabIndex = 6;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 200;
            // 
            // graduationYearDataGridViewTextBoxColumn
            // 
            this.graduationYearDataGridViewTextBoxColumn.DataPropertyName = "Graduation Year";
            this.graduationYearDataGridViewTextBoxColumn.HeaderText = "Graduation Year";
            this.graduationYearDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.graduationYearDataGridViewTextBoxColumn.Name = "graduationYearDataGridViewTextBoxColumn";
            this.graduationYearDataGridViewTextBoxColumn.Width = 200;
            // 
            // numberDataGridViewTextBoxColumn
            // 
            this.numberDataGridViewTextBoxColumn.DataPropertyName = "Number";
            this.numberDataGridViewTextBoxColumn.HeaderText = "Number";
            this.numberDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.numberDataGridViewTextBoxColumn.Name = "numberDataGridViewTextBoxColumn";
            this.numberDataGridViewTextBoxColumn.Width = 200;
            // 
            // heightDataGridViewTextBoxColumn
            // 
            this.heightDataGridViewTextBoxColumn.DataPropertyName = "Height";
            this.heightDataGridViewTextBoxColumn.HeaderText = "Height";
            this.heightDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.heightDataGridViewTextBoxColumn.Name = "heightDataGridViewTextBoxColumn";
            this.heightDataGridViewTextBoxColumn.Width = 200;
            // 
            // weightDataGridViewTextBoxColumn
            // 
            this.weightDataGridViewTextBoxColumn.DataPropertyName = "Weight";
            this.weightDataGridViewTextBoxColumn.HeaderText = "Weight";
            this.weightDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.weightDataGridViewTextBoxColumn.Name = "weightDataGridViewTextBoxColumn";
            this.weightDataGridViewTextBoxColumn.Width = 200;
            // 
            // positionDataGridViewTextBoxColumn
            // 
            this.positionDataGridViewTextBoxColumn.DataPropertyName = "Position";
            this.positionDataGridViewTextBoxColumn.HeaderText = "Position";
            this.positionDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.positionDataGridViewTextBoxColumn.Name = "positionDataGridViewTextBoxColumn";
            this.positionDataGridViewTextBoxColumn.Width = 200;
            // 
            // eligibleDataGridViewTextBoxColumn
            // 
            this.eligibleDataGridViewTextBoxColumn.DataPropertyName = "Eligible";
            this.eligibleDataGridViewTextBoxColumn.HeaderText = "Eligible";
            this.eligibleDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.eligibleDataGridViewTextBoxColumn.Name = "eligibleDataGridViewTextBoxColumn";
            this.eligibleDataGridViewTextBoxColumn.Width = 200;
            // 
            // playerInformationFootballBindingSource
            // 
            this.playerInformationFootballBindingSource.DataMember = "Player_Information_Football";
            // 
            // bASportSDBDataSetUpdated
            // 
            // 
            // lblList
            // 
            this.lblList.AutoSize = true;
            this.lblList.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblList.Location = new System.Drawing.Point(12, 19);
            this.lblList.Name = "lblList";
            this.lblList.Size = new System.Drawing.Size(214, 33);
            this.lblList.TabIndex = 5;
            this.lblList.Text = "List of Players";
            // 
            // player_Information_FootballTableAdapter
            // 
            // 
            // frmTeamInfoFootball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 394);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnBudget);
            this.Controls.Add(this.btnPracticeHours);
            this.Controls.Add(this.dgvTeamInfo);
            this.Controls.Add(this.lblList);
            this.Name = "frmTeamInfoFootball";
            this.Text = "frmTeamInfoFootball";
            this.Load += new System.EventHandler(this.frmTeamInfoFootball_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeamInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerInformationFootballBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnBudget;
        private System.Windows.Forms.Button btnPracticeHours;
        private System.Windows.Forms.DataGridView dgvTeamInfo;
        private System.Windows.Forms.Label lblList;
        private System.Windows.Forms.BindingSource playerInformationFootballBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn graduationYearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn heightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eligibleDataGridViewTextBoxColumn;
    }
}