﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamInfoFootball : Form
    {
        public frmTeamInfoFootball()
        {
            InitializeComponent();
        }

        private void frmTeamInfoFootball_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSetUpdated.Player_Information_Football' table. You can move, or remove it, as needed.

        }

        private void btnBudget_Click(object sender, EventArgs e)
        {
            frmBudgetFootball FormBudgetFootball = new frmBudgetFootball();
            FormBudgetFootball.Show();
        }

        private void btnPracticeHours_Click(object sender, EventArgs e)
        {
            frmPracticeFootball FormPracticeFootball = new frmPracticeFootball();
            FormPracticeFootball.Show();
        }
    }
}
