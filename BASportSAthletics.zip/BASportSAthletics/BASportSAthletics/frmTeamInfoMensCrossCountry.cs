﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamInfoMensCrossCountry : Form
    {
        public frmTeamInfoMensCrossCountry()
        {
            InitializeComponent();
        }

        private void frmTeamInfoMensCrossCountry_Load(object sender, EventArgs e)
        {
            

        }

        private void btnBudget_Click(object sender, EventArgs e)
        {
            frmBudgetMensCrossCountry FormBudgetMensCrossCountry = new frmBudgetMensCrossCountry();
            FormBudgetMensCrossCountry.Show();
        }

        private void btnPracticeHours_Click(object sender, EventArgs e)
        {
            frmPracticeMensCrossCountry FormPracticeMensCrossCountry = new frmPracticeMensCrossCountry();
            FormPracticeMensCrossCountry.Show();
        }
    }
}
