﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamInfoMensGolf : Form
    {
        public frmTeamInfoMensGolf()
        {
            InitializeComponent();
        }

        private void frmTeamInfoMensGolf_Load(object sender, EventArgs e)
        {
            

        }

        private void btnBudget_Click(object sender, EventArgs e)
        {
            frmBudgetMensGolf FormBudgetMensGolf = new frmBudgetMensGolf();
            FormBudgetMensGolf.Show();
        }

        private void btnPracticeHours_Click(object sender, EventArgs e)
        {
            frmPracticeMensGolf FormPracticeMensGolf = new frmPracticeMensGolf();
            FormPracticeMensGolf.Show();
        }
    }
}
