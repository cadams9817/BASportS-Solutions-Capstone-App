﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamInfoSoccer : Form
    {
        public frmTeamInfoSoccer()
        {
            InitializeComponent();
        }

        private void frmTeamInfoSoccer_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSetUpdated.Player_Information_Soccer' table. You can move, or remove it, as needed.

        }

        private void btnBudget_Click(object sender, EventArgs e)
        {
            frmBudgetSoccer FormBudgetSoccer = new frmBudgetSoccer();
            FormBudgetSoccer.Show();
        }

        private void btnPracticeHours_Click(object sender, EventArgs e)
        {
            frmPracticeSoccer FormPracticeSoccer = new frmPracticeSoccer();
            FormPracticeSoccer.Show();
        }
    }
}
