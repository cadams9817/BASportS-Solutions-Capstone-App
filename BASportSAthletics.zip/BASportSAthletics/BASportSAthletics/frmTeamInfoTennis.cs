﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamInfoTennis : Form
    {
        public frmTeamInfoTennis()
        {
            InitializeComponent();
        }

        private void frmTeamInfoTennis_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSetUpdated.Player_Information_Tennis' table. You can move, or remove it, as needed.

        }

        private void btnBudget_Click(object sender, EventArgs e)
        {
            frmBudgetTennis FormBudgetTennis = new frmBudgetTennis();
            FormBudgetTennis.Show();
        }

        private void btnPracticeHours_Click(object sender, EventArgs e)
        {
            frmPracticeTennis FormPracticeTennis = new frmPracticeTennis();
            FormPracticeTennis.Show();
        }
    }
}
