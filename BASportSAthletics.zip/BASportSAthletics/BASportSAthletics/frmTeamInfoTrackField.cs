﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamInfoTrackField : Form
    {
        public frmTeamInfoTrackField()
        {
            InitializeComponent();
        }

        private void frmTeamInfoTrackField_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSetUpdated.Player_Information_TrackField' table. You can move, or remove it, as needed.

        }

        private void btnBudget_Click(object sender, EventArgs e)
        {
            frmBudgetTrackField FormBudgetTrackField = new frmBudgetTrackField();
            FormBudgetTrackField.Show();
        }

        private void btnPracticeHours_Click(object sender, EventArgs e)
        {
            frmPracticeTrackField FormPracticeTrackField = new frmPracticeTrackField();
            FormPracticeTrackField.Show();
        }
    }
}
