﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamInfoWomensCrossCountry : Form
    {
        public frmTeamInfoWomensCrossCountry()
        {
            InitializeComponent();
        }

        private void frmTeamInfoWomensCrossCountry_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bASportSDBDataSetUpdated._Player_Information_Women_s_CrossCountry' table. You can move, or remove it, as needed.

        }

        private void btnBudget_Click(object sender, EventArgs e)
        {
            frmBudgetWomensCrossCountry FormBudgetWomensCrossCountry = new frmBudgetWomensCrossCountry();
            FormBudgetWomensCrossCountry.Show();
        }

        private void btnPracticeHours_Click(object sender, EventArgs e)
        {
            frmPracticeWomensCrossCountry FormPracticeWomensCrossCountry = new frmPracticeWomensCrossCountry();
            FormPracticeWomensCrossCountry.Show();
        }
    }
}
