﻿namespace BASportSAthletics
{
    partial class frmTeamPageBaseball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBaseball = new System.Windows.Forms.Label();
            this.btnTeamInfo = new System.Windows.Forms.Button();
            this.btnAcademicInfo = new System.Windows.Forms.Button();
            this.btnScholarships = new System.Windows.Forms.Button();
            this.btnPlayerInfo = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBaseball
            // 
            this.lblBaseball.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaseball.Location = new System.Drawing.Point(184, 26);
            this.lblBaseball.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBaseball.Name = "lblBaseball";
            this.lblBaseball.Size = new System.Drawing.Size(211, 52);
            this.lblBaseball.TabIndex = 0;
            this.lblBaseball.Text = "Baseball";
            this.lblBaseball.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnTeamInfo
            // 
            this.btnTeamInfo.Location = new System.Drawing.Point(117, 90);
            this.btnTeamInfo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTeamInfo.Name = "btnTeamInfo";
            this.btnTeamInfo.Size = new System.Drawing.Size(145, 123);
            this.btnTeamInfo.TabIndex = 1;
            this.btnTeamInfo.Text = "Team Information";
            this.btnTeamInfo.UseVisualStyleBackColor = true;
            this.btnTeamInfo.Click += new System.EventHandler(this.BtnTeamInfo_Click);
            // 
            // btnAcademicInfo
            // 
            this.btnAcademicInfo.Location = new System.Drawing.Point(117, 231);
            this.btnAcademicInfo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAcademicInfo.Name = "btnAcademicInfo";
            this.btnAcademicInfo.Size = new System.Drawing.Size(145, 123);
            this.btnAcademicInfo.TabIndex = 2;
            this.btnAcademicInfo.Text = "Academic Information";
            this.btnAcademicInfo.UseVisualStyleBackColor = true;
            this.btnAcademicInfo.Click += new System.EventHandler(this.BtnAcademicInfo_Click);
            // 
            // btnScholarships
            // 
            this.btnScholarships.Location = new System.Drawing.Point(316, 231);
            this.btnScholarships.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnScholarships.Name = "btnScholarships";
            this.btnScholarships.Size = new System.Drawing.Size(145, 123);
            this.btnScholarships.TabIndex = 3;
            this.btnScholarships.Text = "Scholarships";
            this.btnScholarships.UseVisualStyleBackColor = true;
            this.btnScholarships.Click += new System.EventHandler(this.BtnScholarships_Click);
            // 
            // btnPlayerInfo
            // 
            this.btnPlayerInfo.Location = new System.Drawing.Point(316, 90);
            this.btnPlayerInfo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPlayerInfo.Name = "btnPlayerInfo";
            this.btnPlayerInfo.Size = new System.Drawing.Size(145, 123);
            this.btnPlayerInfo.TabIndex = 4;
            this.btnPlayerInfo.Text = "Player Information";
            this.btnPlayerInfo.UseVisualStyleBackColor = true;
            this.btnPlayerInfo.Click += new System.EventHandler(this.btnPlayerInfo_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(472, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(95, 37);
            this.btnLogout.TabIndex = 6;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // frmTeamPageBaseball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 444);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnPlayerInfo);
            this.Controls.Add(this.btnScholarships);
            this.Controls.Add(this.btnAcademicInfo);
            this.Controls.Add(this.btnTeamInfo);
            this.Controls.Add(this.lblBaseball);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmTeamPageBaseball";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTeamPage";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblBaseball;
        private System.Windows.Forms.Button btnTeamInfo;
        private System.Windows.Forms.Button btnAcademicInfo;
        private System.Windows.Forms.Button btnScholarships;
        private System.Windows.Forms.Button btnPlayerInfo;
        private System.Windows.Forms.Button btnLogout;
    }
}