﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPage : Form
    {
        public frmTeamPage()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoFootball FormTeamInfoFootball = new frmTeamInfoFootball();
            FormTeamInfoFootball.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoFootball FormAcademicInfoFootball = new frmAcademicInfoFootball();
            FormAcademicInfoFootball.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipFootball FormScholarshipFootball = new frmScholarshipFootball();
            FormScholarshipFootball.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoFootball FormPlayerInfoFootball = new frmPlayerInfoFootball();
            FormPlayerInfoFootball.Show();
        }
    }
}
