﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageMensBasketball : Form
    {
        public frmTeamPageMensBasketball()
        {
            InitializeComponent();
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoMensBasketball FormTeamInfoMensBasketball = new frmTeamInfoMensBasketball();
            FormTeamInfoMensBasketball.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoMensBasketball FormAcademicInfoMensBasketball = new frmAcademicInfoMensBasketball();
            FormAcademicInfoMensBasketball.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipMensBasketball FormScholarshipMensBasketball = new frmScholarshipMensBasketball();
            FormScholarshipMensBasketball.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoMensBasketball FormPlayerInfoMensBasketball = new frmPlayerInfoMensBasketball();
            FormPlayerInfoMensBasketball.Show();
        }
    }
}
