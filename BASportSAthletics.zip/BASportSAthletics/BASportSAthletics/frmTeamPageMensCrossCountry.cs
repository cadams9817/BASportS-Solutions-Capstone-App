﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageMensCrossCountry : Form
    {
        public frmTeamPageMensCrossCountry()
        {
            InitializeComponent();
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoMensCrossCountry FormTeamInfoMensCrossCountry = new frmTeamInfoMensCrossCountry();
            FormTeamInfoMensCrossCountry.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoMensCrossCountry FormAcademicInfoMensCrossCountry = new frmAcademicInfoMensCrossCountry();
            FormAcademicInfoMensCrossCountry.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipMensCrossCountry FormScholarshipMensCrossCountry = new frmScholarshipMensCrossCountry();
            FormScholarshipMensCrossCountry.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoMensCrossCountry FormPlayerInfoMensCrossCountry = new frmPlayerInfoMensCrossCountry();
            FormPlayerInfoMensCrossCountry.Show();
        }
    }
}
