﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageMensGolf : Form
    {
        public frmTeamPageMensGolf()
        {
            InitializeComponent();
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoMensGolf FormTeamInfoMensGolf = new frmTeamInfoMensGolf();
            FormTeamInfoMensGolf.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoMensGolf FormAcademicInfoMensGolf = new frmAcademicInfoMensGolf();
            FormAcademicInfoMensGolf.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipMensGolf FormScholarshipMensGolf = new frmScholarshipMensGolf();
            FormScholarshipMensGolf.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoMensGolf FormPlayerInfoMensGolf = new frmPlayerInfoMensGolf();
            FormPlayerInfoMensGolf.Show();
        }
    }
}
