﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageSoccer : Form
    {
        public frmTeamPageSoccer()
        {
            InitializeComponent();
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoSoccer FormTeamInfoSoccer = new frmTeamInfoSoccer();
            FormTeamInfoSoccer.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoSoccer FormAcademicInfoSoccer = new frmAcademicInfoSoccer();
            FormAcademicInfoSoccer.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipSoccer FormScholarshipSoccer = new frmScholarshipSoccer();
            FormScholarshipSoccer.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoSoccer FormPlayerInfoSoccer = new frmPlayerInfoSoccer();
            FormPlayerInfoSoccer.Show();
        }
    }
}
