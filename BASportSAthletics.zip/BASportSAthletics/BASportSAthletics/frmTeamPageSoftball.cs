﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageSoftball : Form
    {
        public frmTeamPageSoftball()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.btnPlayerInfo = new System.Windows.Forms.Button();
            this.btnScholarships = new System.Windows.Forms.Button();
            this.btnAcademicInfo = new System.Windows.Forms.Button();
            this.btnTeamInfo = new System.Windows.Forms.Button();
            this.lblSoftball = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnPlayerInfo
            // 
            this.btnPlayerInfo.Location = new System.Drawing.Point(237, 73);
            this.btnPlayerInfo.Name = "btnPlayerInfo";
            this.btnPlayerInfo.Size = new System.Drawing.Size(109, 100);
            this.btnPlayerInfo.TabIndex = 14;
            this.btnPlayerInfo.Text = "Player Information";
            this.btnPlayerInfo.UseVisualStyleBackColor = true;
            this.btnPlayerInfo.Click += new System.EventHandler(this.btnPlayerInfo_Click);
            // 
            // btnScholarships
            // 
            this.btnScholarships.Location = new System.Drawing.Point(237, 188);
            this.btnScholarships.Name = "btnScholarships";
            this.btnScholarships.Size = new System.Drawing.Size(109, 100);
            this.btnScholarships.TabIndex = 13;
            this.btnScholarships.Text = "Scholarships";
            this.btnScholarships.UseVisualStyleBackColor = true;
            this.btnScholarships.Click += new System.EventHandler(this.BtnScholarships_Click);
            // 
            // btnAcademicInfo
            // 
            this.btnAcademicInfo.Location = new System.Drawing.Point(88, 188);
            this.btnAcademicInfo.Name = "btnAcademicInfo";
            this.btnAcademicInfo.Size = new System.Drawing.Size(109, 100);
            this.btnAcademicInfo.TabIndex = 12;
            this.btnAcademicInfo.Text = "Academic Information";
            this.btnAcademicInfo.UseVisualStyleBackColor = true;
            this.btnAcademicInfo.Click += new System.EventHandler(this.BtnAcademicInfo_Click);
            // 
            // btnTeamInfo
            // 
            this.btnTeamInfo.Location = new System.Drawing.Point(88, 73);
            this.btnTeamInfo.Name = "btnTeamInfo";
            this.btnTeamInfo.Size = new System.Drawing.Size(109, 100);
            this.btnTeamInfo.TabIndex = 11;
            this.btnTeamInfo.Text = "Team Information";
            this.btnTeamInfo.UseVisualStyleBackColor = true;
            this.btnTeamInfo.Click += new System.EventHandler(this.BtnTeamInfo_Click);
            // 
            // lblSoftball
            // 
            this.lblSoftball.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoftball.Location = new System.Drawing.Point(146, 9);
            this.lblSoftball.Name = "lblSoftball";
            this.lblSoftball.Size = new System.Drawing.Size(143, 42);
            this.lblSoftball.TabIndex = 10;
            this.lblSoftball.Text = "Softball";
            this.lblSoftball.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // frmTeamPageSoftball
            // 
            this.ClientSize = new System.Drawing.Size(434, 361);
            this.Controls.Add(this.btnPlayerInfo);
            this.Controls.Add(this.btnScholarships);
            this.Controls.Add(this.btnAcademicInfo);
            this.Controls.Add(this.btnTeamInfo);
            this.Controls.Add(this.lblSoftball);
            this.Name = "frmTeamPageSoftball";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);

        }

        private Button btnPlayerInfo;
        private Button btnScholarships;
        private Button btnAcademicInfo;
        private Button btnTeamInfo;
        private Label lblSoftball;

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoSoftball FormTeamInfoSoftball = new frmTeamInfoSoftball();
            FormTeamInfoSoftball.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoSoftball FormAcademicInfoSoftball = new frmAcademicInfoSoftball();
            FormAcademicInfoSoftball.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipSoftball FormScholarshipSoftball = new frmScholarshipSoftball();
            FormScholarshipSoftball.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoSoftball FormPlayerInfoSoftball = new frmPlayerInfoSoftball();
            FormPlayerInfoSoftball.Show();
        }
    }
}
