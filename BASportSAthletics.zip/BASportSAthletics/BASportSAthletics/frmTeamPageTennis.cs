﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageTennis : Form
    {
        public frmTeamPageTennis()
        {
            InitializeComponent();
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoTennis FormTeamInfoTennis = new frmTeamInfoTennis();
            FormTeamInfoTennis.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoTennis FormAcademicInfoTennis = new frmAcademicInfoTennis();
            FormAcademicInfoTennis.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipTennis FormScholarshipTennis = new frmScholarshipTennis();
            FormScholarshipTennis.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoTennis FormPlayerInfoTennis = new frmPlayerInfoTennis();
            FormPlayerInfoTennis.Show();
        }
    }
}
