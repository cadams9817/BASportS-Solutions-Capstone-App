﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageTrackField : Form
    {
        public frmTeamPageTrackField()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoTrackField FormTeamInfoTrackField = new frmTeamInfoTrackField();
            FormTeamInfoTrackField.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoTrackField FormAcademicInfoTrackField = new frmAcademicInfoTrackField();
            FormAcademicInfoTrackField.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipTrackField FormScholarshipTrackField = new frmScholarshipTrackField();
            FormScholarshipTrackField.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoTrackField FormPlayerInfoTrackField = new frmPlayerInfoTrackField();
            FormPlayerInfoTrackField.Show();
        }
    }
}
