﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageVolleyball : Form
    {
        public frmTeamPageVolleyball()
        {
            InitializeComponent();
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoVolleyball FormTeamInfoVolleyball = new frmTeamInfoVolleyball();
            FormTeamInfoVolleyball.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoVolleyball FormAcademicInfoVolleyball = new frmAcademicInfoVolleyball();
            FormAcademicInfoVolleyball.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipVolleyball FormScholarshipVolleyball = new frmScholarshipVolleyball();
            FormScholarshipVolleyball.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoVolleyball FormPlayerInfoVolleyball = new frmPlayerInfoVolleyball();
            FormPlayerInfoVolleyball.Show();
        }
    }
}
