﻿namespace BASportSAthletics
{
    partial class frmTeamPageWomensBasketball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPlayerInfo = new System.Windows.Forms.Button();
            this.btnScholarships = new System.Windows.Forms.Button();
            this.btnAcademicInfo = new System.Windows.Forms.Button();
            this.btnTeamInfo = new System.Windows.Forms.Button();
            this.lblWomensBasketball = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnPlayerInfo
            // 
            this.btnPlayerInfo.Location = new System.Drawing.Point(237, 73);
            this.btnPlayerInfo.Name = "btnPlayerInfo";
            this.btnPlayerInfo.Size = new System.Drawing.Size(109, 100);
            this.btnPlayerInfo.TabIndex = 9;
            this.btnPlayerInfo.Text = "Player Information";
            this.btnPlayerInfo.UseVisualStyleBackColor = true;
            this.btnPlayerInfo.Click += new System.EventHandler(this.btnPlayerInfo_Click);
            // 
            // btnScholarships
            // 
            this.btnScholarships.Location = new System.Drawing.Point(237, 188);
            this.btnScholarships.Name = "btnScholarships";
            this.btnScholarships.Size = new System.Drawing.Size(109, 100);
            this.btnScholarships.TabIndex = 8;
            this.btnScholarships.Text = "Scholarships";
            this.btnScholarships.UseVisualStyleBackColor = true;
            this.btnScholarships.Click += new System.EventHandler(this.BtnScholarships_Click);
            // 
            // btnAcademicInfo
            // 
            this.btnAcademicInfo.Location = new System.Drawing.Point(88, 188);
            this.btnAcademicInfo.Name = "btnAcademicInfo";
            this.btnAcademicInfo.Size = new System.Drawing.Size(109, 100);
            this.btnAcademicInfo.TabIndex = 7;
            this.btnAcademicInfo.Text = "Academic Information";
            this.btnAcademicInfo.UseVisualStyleBackColor = true;
            this.btnAcademicInfo.Click += new System.EventHandler(this.BtnAcademicInfo_Click);
            // 
            // btnTeamInfo
            // 
            this.btnTeamInfo.Location = new System.Drawing.Point(88, 73);
            this.btnTeamInfo.Name = "btnTeamInfo";
            this.btnTeamInfo.Size = new System.Drawing.Size(109, 100);
            this.btnTeamInfo.TabIndex = 6;
            this.btnTeamInfo.Text = "Team Information";
            this.btnTeamInfo.UseVisualStyleBackColor = true;
            this.btnTeamInfo.Click += new System.EventHandler(this.BtnTeamInfo_Click);
            // 
            // lblWomensBasketball
            // 
            this.lblWomensBasketball.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWomensBasketball.Location = new System.Drawing.Point(37, 9);
            this.lblWomensBasketball.Name = "lblWomensBasketball";
            this.lblWomensBasketball.Size = new System.Drawing.Size(361, 42);
            this.lblWomensBasketball.TabIndex = 5;
            this.lblWomensBasketball.Text = "Women\'s Basketball";
            // 
            // frmTeamPageWomensBasketball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 361);
            this.Controls.Add(this.btnPlayerInfo);
            this.Controls.Add(this.btnScholarships);
            this.Controls.Add(this.btnAcademicInfo);
            this.Controls.Add(this.btnTeamInfo);
            this.Controls.Add(this.lblWomensBasketball);
            this.Name = "frmTeamPageWomensBasketball";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTeamPageWomensBasketball";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPlayerInfo;
        private System.Windows.Forms.Button btnScholarships;
        private System.Windows.Forms.Button btnAcademicInfo;
        private System.Windows.Forms.Button btnTeamInfo;
        private System.Windows.Forms.Label lblWomensBasketball;
    }
}