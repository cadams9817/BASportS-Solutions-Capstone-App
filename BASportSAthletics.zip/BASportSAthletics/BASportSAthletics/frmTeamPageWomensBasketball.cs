﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageWomensBasketball : Form
    {
        public frmTeamPageWomensBasketball()
        {
            InitializeComponent();
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoWomensBasketball FormTeamInfoWomensBasketball = new frmTeamInfoWomensBasketball();
            FormTeamInfoWomensBasketball.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoWomensBasketball FormAcademicInfoWomensBasketball = new frmAcademicInfoWomensBasketball();
            FormAcademicInfoWomensBasketball.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipWomensBasketball FormScholarshipWomensBasketball = new frmScholarshipWomensBasketball();
            FormScholarshipWomensBasketball.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoWomensBasketball FormPlayerInfoWomensBasketball = new frmPlayerInfoWomensBasketball();
            FormPlayerInfoWomensBasketball.Show();
        }
    }
}
