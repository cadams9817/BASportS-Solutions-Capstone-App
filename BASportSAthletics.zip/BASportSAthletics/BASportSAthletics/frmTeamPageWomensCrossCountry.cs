﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageWomensCrossCountry : Form
    {
        public frmTeamPageWomensCrossCountry()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.btnPlayerInfo = new System.Windows.Forms.Button();
            this.btnScholarships = new System.Windows.Forms.Button();
            this.btnAcademicInfo = new System.Windows.Forms.Button();
            this.btnTeamInfo = new System.Windows.Forms.Button();
            this.lblWomensCrossCountry = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnPlayerInfo
            // 
            this.btnPlayerInfo.Location = new System.Drawing.Point(237, 73);
            this.btnPlayerInfo.Name = "btnPlayerInfo";
            this.btnPlayerInfo.Size = new System.Drawing.Size(109, 100);
            this.btnPlayerInfo.TabIndex = 17;
            this.btnPlayerInfo.Text = "Player Information";
            this.btnPlayerInfo.UseVisualStyleBackColor = true;
            this.btnPlayerInfo.Click += new System.EventHandler(this.btnPlayerInfo_Click);
            // 
            // btnScholarships
            // 
            this.btnScholarships.Location = new System.Drawing.Point(237, 188);
            this.btnScholarships.Name = "btnScholarships";
            this.btnScholarships.Size = new System.Drawing.Size(109, 100);
            this.btnScholarships.TabIndex = 16;
            this.btnScholarships.Text = "Scholarships";
            this.btnScholarships.UseVisualStyleBackColor = true;
            this.btnScholarships.Click += new System.EventHandler(this.BtnScholarships_Click);
            // 
            // btnAcademicInfo
            // 
            this.btnAcademicInfo.Location = new System.Drawing.Point(88, 188);
            this.btnAcademicInfo.Name = "btnAcademicInfo";
            this.btnAcademicInfo.Size = new System.Drawing.Size(109, 100);
            this.btnAcademicInfo.TabIndex = 15;
            this.btnAcademicInfo.Text = "Academic Information";
            this.btnAcademicInfo.UseVisualStyleBackColor = true;
            this.btnAcademicInfo.Click += new System.EventHandler(this.BtnAcademicInfo_Click);
            // 
            // btnTeamInfo
            // 
            this.btnTeamInfo.Location = new System.Drawing.Point(88, 73);
            this.btnTeamInfo.Name = "btnTeamInfo";
            this.btnTeamInfo.Size = new System.Drawing.Size(109, 100);
            this.btnTeamInfo.TabIndex = 14;
            this.btnTeamInfo.Text = "Team Information";
            this.btnTeamInfo.UseVisualStyleBackColor = true;
            this.btnTeamInfo.Click += new System.EventHandler(this.BtnTeamInfo_Click);
            // 
            // lblWomensCrossCountry
            // 
            this.lblWomensCrossCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWomensCrossCountry.Location = new System.Drawing.Point(10, 9);
            this.lblWomensCrossCountry.Name = "lblWomensCrossCountry";
            this.lblWomensCrossCountry.Size = new System.Drawing.Size(415, 42);
            this.lblWomensCrossCountry.TabIndex = 13;
            this.lblWomensCrossCountry.Text = "Women\'s Cross Country";
            // 
            // frmTeamPageWomensCrossCountry
            // 
            this.ClientSize = new System.Drawing.Size(434, 361);
            this.Controls.Add(this.btnPlayerInfo);
            this.Controls.Add(this.btnScholarships);
            this.Controls.Add(this.btnAcademicInfo);
            this.Controls.Add(this.btnTeamInfo);
            this.Controls.Add(this.lblWomensCrossCountry);
            this.Name = "frmTeamPageWomensCrossCountry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);

        }
        private Button btnPlayerInfo;
        private Button btnScholarships;
        private Button btnAcademicInfo;
        private Button btnTeamInfo;
        private Label lblWomensCrossCountry;

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoWomensCrossCountry FormTeamInfoWomensCrossCountry = new frmTeamInfoWomensCrossCountry();
            FormTeamInfoWomensCrossCountry.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoWomensCrossCountry FormAcademicInfoWomensCrossCountry = new frmAcademicInfoWomensCrossCountry();
            FormAcademicInfoWomensCrossCountry.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipWomensCrossCountry FormScholarshipWomensCrossCountry = new frmScholarshipWomensCrossCountry();
            FormScholarshipWomensCrossCountry.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoWomensCrossCountry FormPlayerInfoWomensCrossCountry = new frmPlayerInfoWomensCrossCountry();
            FormPlayerInfoWomensCrossCountry.Show();
        }
    }
}
