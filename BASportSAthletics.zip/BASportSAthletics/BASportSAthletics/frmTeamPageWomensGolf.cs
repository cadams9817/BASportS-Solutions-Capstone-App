﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BASportSAthletics
{
    public partial class frmTeamPageWomensGolf : Form
    {
        public frmTeamPageWomensGolf()
        {
            InitializeComponent();
        }

        private void BtnTeamInfo_Click(object sender, EventArgs e)
        {
            frmTeamInfoWomensGolf FormTeamInfoWomensGolf = new frmTeamInfoWomensGolf();
            FormTeamInfoWomensGolf.Show();
        }

        private void BtnAcademicInfo_Click(object sender, EventArgs e)
        {
            frmAcademicInfoWomensGolf FormAcademicInfoWomensGolf = new frmAcademicInfoWomensGolf();
            FormAcademicInfoWomensGolf.Show();
        }

        private void BtnScholarships_Click(object sender, EventArgs e)
        {
            frmScholarshipWomensGolf FormScholarshipWomensGolf = new frmScholarshipWomensGolf();
            FormScholarshipWomensGolf.Show();
        }

        private void btnPlayerInfo_Click(object sender, EventArgs e)
        {
            frmPlayerInfoWomensGolf FormPlayerInfoWomensGolf = new frmPlayerInfoWomensGolf();
            FormPlayerInfoWomensGolf.Show();
        }
    }
}
